#!/usr/bin/env python3
"""[v12] Compare rebuilt pseudobulk (from raw h5ad) with 02_data/processed. Usage: compare_pseudobulk.py <processed> <rebuilt> <out.csv>"""
import sys, os, glob, hashlib, numpy as np, pandas as pd
P, N, OUT = sys.argv[1:4]; rows = []
md5 = lambda p: hashlib.md5(open(p, "rb").read()).hexdigest()
for ds in ["GSE290367_pseudobulk", "SCP3342_pseudobulk"]:
    for po in sorted(glob.glob(f"{P}/{ds}/*")):
        pn = f"{N}/{ds}/{os.path.basename(po)}"; r = dict(file=f"{ds}/{os.path.basename(po)}")
        if not os.path.exists(pn): r["status"] = "missing_rebuild"; rows.append(r); continue
        r["identical_bytes"] = md5(po) == md5(pn)
        if po.endswith(".npy"):
            a, b = np.load(po, mmap_mode="r"), np.load(pn, mmap_mode="r"); r["shape"] = str(a.shape)
            r["max_abs_delta"] = float(np.max(np.abs(np.asarray(a, np.float64) - np.asarray(b, np.float64)))) if a.shape == b.shape else np.nan
        else:
            a, b = pd.read_csv(po, low_memory=False), pd.read_csv(pn, low_memory=False); r["shape"] = str(a.shape)
            r["frame_equal"] = a.shape == b.shape and a.equals(b)
        r["status"] = "identical" if r["identical_bytes"] else ("within_tol" if (r.get("max_abs_delta", 1) < 1e-6 or r.get("frame_equal")) else "differs")
        rows.append(r)
pd.DataFrame(rows).to_csv(OUT, index=False); print(pd.DataFrame(rows).to_string())
