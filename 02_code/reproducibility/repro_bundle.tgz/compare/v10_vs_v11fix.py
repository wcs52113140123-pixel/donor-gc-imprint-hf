#!/usr/bin/env python3
"""[v12 reproducibility] Old (archived v1.0) vs new (v1.0 code + v1.1 fixes B1 HC2-on-singletons, B6 competitive sampling
without replacement excluding module genes, B2 unified thresholds myeloid >=20 nuclei & >=5k UMI) for every endpoint row
of fig2_normative_coupling, hfpef_scp3342 and fig4_disease_specificity. Two 'new' variants: all records, and one record per
individual (plan v1.2 de-duplication). Usage: v10_vs_v11fix.py <orig 04_results> <fix 04_results> <fix_dedup 04_results> <out.csv>"""
import sys, numpy as np, pandas as pd
O, F, FD, OUT = sys.argv[1:5]
SPEC = {  # file: (key columns, metric columns)
 "fig2_normative_coupling/age_effects.csv": (["compartment", "module", "model"], ["n", "beta_per_decade", "se", "p", "z", "null_mean", "null_sd", "fdr_familyB"]),
 "fig2_normative_coupling/coupling_mismatch.csv": (["target_comp", "target", "effector_comp", "effector"], ["n", "spearman_TE", "p_spearman", "coupling_beta", "coupling_p", "mismatch_beta_per_decade", "mismatch_se", "mismatch_p", "coupling_x_age_beta", "coupling_x_age_p"]),
 "fig2_normative_coupling/within_study_meta_HKSJ.csv": (["compartment", "module"], ["k_studies", "beta_re", "se_hksj", "p_hksj", "I2", "tau2"]),
 "fig2_normative_coupling/leave_one_study_out.csv": (["compartment", "module", "left_out"], ["n", "beta", "p"]),
 "fig2_normative_coupling/module_coverage.csv": (["compartment", "module"], ["n_genes", "n_measured", "n_donors"]),
 "hfpef_scp3342/hfpef_module_effects.csv": (["spec", "compartment", "module"], ["n_hfpef", "n_ctrl", "n_genes", "beta", "se", "p", "healthy_age_beta", "expected_age_contrib", "decade_equiv", "beta_obs", "null_mean", "null_sd", "z_comp", "p_comp"]),
 "hfpef_scp3342/hfpef_extra_tests.csv": (["test"], ["beta", "se", "p", "n", "same_sign_frac", "mean_hfpef", "mean_ctrl"]),
 "fig4_disease_specificity/disease_effects.csv": (["normalisation", "compartment", "module", "disease"], ["n_disease", "n_ND", "n_genes", "beta", "se", "p", "healthy_age_beta", "healthy_age_p", "age_equiv_years", "age_equiv_lo", "age_equiv_hi", "mean_normative_dev", "beta_obs", "null_mean", "null_sd", "z_comp", "p_comp"]),
 "fig4_disease_specificity/myeloid_composition_by_disease.csv": (["disease", "outcome"], ["beta", "se", "p", "mean_dis", "mean_ND"]),
}
STOCH = {"z", "null_mean", "null_sd", "beta_obs", "z_comp", "p_comp", "age_equiv_lo", "age_equiv_hi"}   # depend on seeded RNG draws
rows = []
for f, (keys, mets) in SPEC.items():
    tabs = {}
    for lab, base in [("v10", O), ("v11fix", F), ("v11fix_dedup", FD)]:
        try: t = pd.read_csv(f"{base}/{f}")
        except FileNotFoundError: t = pd.DataFrame(columns=keys)
        k = [c for c in keys if c in t.columns]; t["_key"] = t[k].astype(str).agg(" | ".join, axis=1)
        t = t.drop_duplicates("_key").set_index("_key"); tabs[lab] = t
    allk = list(dict.fromkeys(list(tabs["v10"].index) + list(tabs["v11fix"].index) + list(tabs["v11fix_dedup"].index)))
    for key in allk:
        for m in mets:
            v = {lab: (float(tabs[lab].at[key, m]) if (key in tabs[lab].index and m in tabs[lab].columns and pd.notna(pd.to_numeric(tabs[lab].at[key, m], errors="coerce"))) else np.nan) for lab in tabs}
            if all(np.isnan(x) for x in v.values()): continue
            rows.append(dict(file=f, key=key, metric=m, v10=v["v10"], v11fix=v["v11fix"], v11fix_dedup=v["v11fix_dedup"],
                             delta_fix=v["v11fix"] - v["v10"], delta_fix_dedup=v["v11fix_dedup"] - v["v10"],
                             stochastic_metric=m in STOCH, key_in_v10=key in tabs["v10"].index, key_in_v11fix=key in tabs["v11fix"].index))
T = pd.DataFrame(rows)
is_p = T.metric.str.fullmatch(r"p|coupling_p|mismatch_p|p_hksj|p_comp|healthy_age_p|p_spearman|coupling_x_age_p")
T["sig_flip_fix"] = np.where(is_p, (T.v10 < .05) != (T.v11fix < .05), False) & T.v10.notna() & T.v11fix.notna()
T["sig_flip_fix_dedup"] = np.where(is_p, (T.v10 < .05) != (T.v11fix_dedup < .05), False) & T.v10.notna() & T.v11fix_dedup.notna()
is_b = T.metric.str.contains("beta") & ~T.metric.str.contains("null")
T["sign_flip_fix"] = is_b & (np.sign(T.v10) != np.sign(T.v11fix)) & T.v10.notna() & T.v11fix.notna()
T["class_fix"] = np.select([T.v10.isna() & T.v11fix.notna(), T.v10.notna() & T.v11fix.isna(), T.delta_fix.abs() < 1e-6],
                           ["new_only (was NaN/absent in v1.0)", "v10_only (absent after fix)", "unchanged(|d|<1e-6)"], "changed")
T.to_csv(OUT, index=False)
print(T.groupby(["file", "class_fix"]).size().to_string()); print("sig flips (fix):", int(T.sig_flip_fix.sum()), " (fix+dedup):", int(T.sig_flip_fix_dedup.sum()))
