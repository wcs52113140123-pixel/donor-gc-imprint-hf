#!/usr/bin/env python3
"""[v12 reproducibility] Add a verdict and a rule-based reason to rerun_diff_table.csv (in place).
verdict: reproduced_bit_identical | reproduced_within_tol | display_only_differs | not_reproduced | not_regenerated | frozen_input | new_intermediate"""
import sys, pandas as pd
P = sys.argv[1]; T = pd.read_csv(P)
def why(r):
    f, s = r.file, r.status
    if r.get("frozen_input", False) is True or str(r.get("frozen_input")) == "True": return "frozen_input", "frozen upstream input copied into the shadow root (see FROZEN_INPUTS.tsv); identical by construction"
    if s == "identical": return "reproduced_bit_identical", "byte-identical"
    if s == "within_tol": return "reproduced_within_tol", "all numeric cells |delta| < 1e-6 and text equal; bytes differ (gzip header, float repr or floating-point summation order)"
    if s == "binary_differs": return "display_only_differs", "rendered PDF/PNG not byte-stable (timestamps/font subsetting); numbers verified through SourceData_*.xlsx"
    if s == "differs" and ("umap" in f.lower() or "SourceData_Fig3" in f):
        return "display_only_differs", "SCP3342 UMAP coordinates not bit-reproducible (harmonypy 0.0.10 + UMAP under multithreading); annotation, donor fractions and all statistics identical; in SourceData_Fig3 only sheet e_SCP3342_umap_nuclei differs"
    if s == "differs" and f.endswith("synthesis_run_log.json"): return "reproduced_within_tol", "only a logged traceback string differs (contains the shadow-root path); all numeric entries identical"
    if s == "missing_original": return "new_intermediate", "intermediate written by the script but never archived in 04_results"
    if s == "missing_rerun":
        if f.endswith((".md", ".png")): return "not_regenerated", "narrative summary / preview written in the analysis sandbox; no generating script (not a numeric result table)"
        return "not_regenerated", "table produced in the analysis sandbox; generating code not wrapped (lineage available in artifact store)"
    return "not_reproduced", "numeric differences beyond tolerance — investigate"
T[["verdict", "reason"]] = T.apply(lambda r: pd.Series(why(r)), axis=1)
T.to_csv(P, index=False); print(T.verdict.value_counts().to_string())
