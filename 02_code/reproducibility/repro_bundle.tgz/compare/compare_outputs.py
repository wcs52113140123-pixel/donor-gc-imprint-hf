#!/usr/bin/env python3
"""[v12 reproducibility] Compare every file regenerated under the rerun tree with the archived file at the same relative
path in 04_results/. Classes: identical (byte-identical) | within_tol (all numeric |delta| < 1e-6, all text equal) |
differs (numeric or text cells differ; max |delta| reported) | structure_differs (shape/columns) | binary_differs
(PNG/PDF: rendering is not expected to be byte-stable) | missing_original | missing_rerun.
Usage: compare_outputs.py <archived 04_results> <rerun 04_results> <out.csv>"""
import os, sys, glob, json, hashlib, numpy as np, pandas as pd
ORIG, NEW, OUT = sys.argv[1:4]; TOL = 1e-6
SCOPE = ["fig2_normative_coupling", "drift_diagnosis", "fig4_disease_specificity", "hfpef_scp3342", "audit_2026-10-03",
         "validation_v1.1", "synthesis_v1.1"]
FROZEN = {"validation_v1.1/donor_overlap/gse290367_duplicate_individuals.csv", "validation_v1.1/donor_overlap/magnet_overlap_flags.csv",
          "validation_v1.1/donor_overlap/MAGNet_phenoData.csv", "validation_v1.1/protein_spatial/proteomics/prot_grep.txt"}
md5 = lambda p: hashlib.md5(open(p, "rb").read()).hexdigest()
def flat(o, pre=""):
    if isinstance(o, dict):
        for k, v in o.items(): yield from flat(v, f"{pre}/{k}")
    elif isinstance(o, list):
        for i, v in enumerate(o): yield from flat(v, f"{pre}[{i}]")
    else: yield pre, o
def cmp_frames(a, b):
    if a.shape != b.shape or list(a.columns) != list(b.columns):
        return "structure_differs", np.nan, np.nan, f"shape {a.shape} vs {b.shape}; cols_only_orig={sorted(map(str, set(a.columns)-set(b.columns)))[:5]} cols_only_new={sorted(map(str, set(b.columns)-set(a.columns)))[:5]}"
    mx, rel, ntext, nnum, worst = 0.0, 0.0, 0, 0, ""
    for c in a.columns:
        x, y = a[c], b[c]
        xn, yn = pd.to_numeric(x, errors="coerce"), pd.to_numeric(y, errors="coerce")
        if xn.dtype == bool or yn.dtype == bool: xn, yn = xn.astype(float), yn.astype(float)
        if x.notna().sum() > 0 and (x.notna() == xn.notna()).all() and (y.notna() == yn.notna()).all():
            nan_mis = int((xn.isna() != yn.isna()).sum()); d = (xn - yn).abs()
            if nan_mis: ntext += nan_mis; worst = worst or f"{c}: NaN pattern differs"
            dm = d.max(skipna=True)
            if np.isfinite(dm) and dm > mx: mx = float(dm); worst = f"{c}"
            rr = (d / xn.abs().clip(lower=1e-12)).max(skipna=True)
            if np.isfinite(rr): rel = max(rel, float(rr))
            nnum += int((d > TOL).sum())
        else:
            m = int((x.astype(str) != y.astype(str)).sum()); ntext += m
            if m and not worst: worst = f"{c} (text)"
    cls = "within_tol" if (mx < TOL and ntext == 0) else "differs"
    return cls, mx, rel, f"n_numeric_cells>tol={nnum}; n_text_cells_differ={ntext}; worst_col={worst}"
def read_any(p):
    if p.endswith((".csv", ".csv.gz")): return {"": pd.read_csv(p, low_memory=False)}
    if p.endswith(".xlsx"): return pd.read_excel(p, sheet_name=None)
    if p.endswith(".json"):
        d = dict(flat(json.load(open(p)))); return {"": pd.DataFrame({"key": list(d), "value": [d[k] for k in d]})}
    if p.endswith((".txt", ".tsv")): return {"": pd.DataFrame({"line": open(p, errors="replace").read().splitlines()})}
    return None
rows = []
lst = lambda base: {os.path.relpath(p, base) for s in SCOPE for p in glob.glob(f"{base}/{s}/**/*", recursive=True) if os.path.isfile(p)}
orig_files, new_files = lst(ORIG), lst(NEW)
RANK = {"within_tol": 0, "differs": 1, "structure_differs": 2}
for rel in sorted(orig_files | new_files):
    po, pn = f"{ORIG}/{rel}", f"{NEW}/{rel}"; r = dict(file=rel, frozen_input=rel in FROZEN)
    if rel not in new_files: r.update(status="missing_rerun"); rows.append(r); continue
    if rel not in orig_files: r.update(status="missing_original"); rows.append(r); continue
    r["md5_orig"], r["md5_rerun"] = md5(po), md5(pn)
    if r["md5_orig"] == r["md5_rerun"]: r.update(status="identical", max_abs_delta=0.0); rows.append(r); continue
    if rel.endswith((".png", ".pdf")): r.update(status="binary_differs"); rows.append(r); continue
    if rel.endswith(".md"): r.update(status="text_differs"); rows.append(r); continue
    try:
        A, B = read_any(po), read_any(pn)
        if A is None: r.update(status="binary_differs"); rows.append(r); continue
        worst = ("within_tol", 0.0, 0.0, ""); notes = []
        for sh in sorted(set(A) | set(B)):
            if sh not in A or sh not in B: worst = ("structure_differs", np.nan, np.nan, f"sheet {sh} missing"); notes.append(worst[3]); continue
            res = cmp_frames(A[sh].reset_index(drop=True), B[sh].reset_index(drop=True)); notes.append(f"[{sh}] {res[3]}" if sh else res[3])
            if RANK[res[0]] > RANK[worst[0]] or (res[0] == worst[0] and np.nan_to_num(res[1]) > np.nan_to_num(worst[1])): worst = res
        r.update(status=worst[0], max_abs_delta=worst[1], max_rel_delta=worst[2], detail=" | ".join(notes)[:900])
    except Exception as e:
        r.update(status="compare_error", detail=repr(e)[:300])
    rows.append(r)
T = pd.DataFrame(rows); T.to_csv(OUT, index=False)
print(T.status.value_counts().to_string())
