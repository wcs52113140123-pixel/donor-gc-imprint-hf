#!/usr/bin/env python3
"""[v12-wrap] Server-side runner for the UNMODIFIED synthesis figure scripts (03_code/06_synthesis/figures/fig*.py).
The originals were executed in the analysis sandbox, where (i) `apply_figure_style` came from the figure-style helper,
(ii) `host.artifact_path(<uuid>)` resolved four artifact inputs, and (iii) inputs were staged as data/<relpath with '/'->'__'>
(04_results/**) and data_syn/ (04_results/synthesis_v1.1/). This shim recreates exactly that environment from a rerun
results tree and then exec()s the original script text; nothing in fig*.py / figlib.py is edited.
Usage: figrun.py <fig_script> <results_root(04_results of rerun)> <config_root(01_config)> <workdir>
"""
import os, sys, glob, shutil, matplotlib
matplotlib.use("Agg")
fig_script, RES, CFG, WD = [os.path.abspath(x) for x in sys.argv[1:5]]
HERE = os.path.dirname(os.path.abspath(__file__))
os.makedirs(WD, exist_ok=True); os.chdir(WD)
if not os.path.isdir("data"):
    os.makedirs("data")
    for p in glob.glob(f"{RES}/**/*", recursive=True):
        if os.path.isfile(p) and "/synthesis_v1.1/" not in p:
            rel = os.path.relpath(p, RES).replace("/", "__"); os.symlink(p, f"data/{rel}")
    os.symlink(f"{RES}/synthesis_v1.1", "data_syn")
shutil.copy(os.path.join(os.path.dirname(fig_script), "figlib.py"), "figlib.py")
ART = {  # artifact UUIDs referenced by the original figure scripts -> rerun / frozen server files
    "447777e0-47fd-412f-b240-fed8d90ebc64": f"{RES}/validation_v1.1/donor_overlap/gse290367_duplicate_individuals.csv",
    "9255051c-3aea-444e-91ee-afb6dbdb4dd6": f"{CFG}/modules/modules_v1.1.tsv",
    "67f29f49-27d5-4bec-b865-d5d6a4d91af2": f"{RES}/audit_2026-10-03/audit_controls_results.json",
    "55f7b0e3-b6b1-4305-b8e0-7bdccab2f242": f"{RES}/validation_v1.1/gc_discovery/gc_discovery_results.json"}
class _Host:
    @staticmethod
    def artifact_path(vid): return ART[vid]
G = {"__name__": "__main__", "host": _Host()}
exec(open(os.path.join(HERE, "figure_style_kernel.py")).read(), G)
exec(compile(open(fig_script).read(), fig_script, "exec"), G)
print("figrun ok", os.path.basename(fig_script), sorted(os.listdir("figures")))
