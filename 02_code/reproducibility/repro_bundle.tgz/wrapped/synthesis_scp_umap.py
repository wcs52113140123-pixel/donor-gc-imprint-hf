#!/usr/bin/env python3
"""SCP3342 query-only UMAP re-embedding (part of synthesis_reanalysis.py; split out because harmonypy is not in system python). Synthesis v1.1 re-analyses (2026-10-03). Frozen modules v1.1 (sha256 checked). Unit = donor/sample. HC3 (pbtools_v11; HC2 on singleton leverage).
A1  H2 de-duplication in GSE290367: one record per individual (gse290367_duplicate_individuals.csv; 147 ND records -> 139 people).
    ND ageing slopes (study FE + HC3; HKSJ within-study meta; TOST +/-0.1 SD/decade) for pooled L2 myeloid, Resident, Monocyte_derived;
    RES_EFF_core, MHCII_core, EFF_MHCII_index (+ secondary modules). v1.0 primary E (GO apoptotic-cell clearance, L1 myeloid) and T (SenMayo,
    vascular-stromal) slopes/coupling/mismatch with random-pair nulls (CPM, DESeq2), all records vs dedup. DCM/HCM/ICM vs ND re-run dedup.
A2  Decade-equivalent contrast: |disease effect| / |ageing slope|, joint donor bootstrap (strata = study x group, B=2000), conservative minimum
    decades (disease CI bound nearest 0 / largest |slope 95% CI bound|) and decades at the TOST bound (|effect|/0.1). GSE290367 DCM/HCM; MAGNet DCM/HCM vs NF slope.
A3  GC-adjusted within-subset disease effects (GC_response = FKBP5 TSC22D3 ZBTB16 PER1 KLF9 DDIT4 KLF15 MT2A; post hoc, literature list) + GC-low controls.
Figure exports: bulk per-sample GC/module scores (Hahn, MAGNet), gene-level effects (discovery + bulk), SCP3342 query-only UMAP (same procedure as
scp_substates.py) with per-nucleus RES_EFF/MHCII scores, GC separability.
Does not modify any v1.0/v1.1 file. Writes only to 04_results/synthesis_v1.1/."""
import os, sys, json, hashlib, io, gzip, tarfile, time, numpy as np, pandas as pd
from scipy import stats
ROOT = os.environ["PROJ_ROOT"]  # [v12-wrap] was hard-coded "/home/weichangsheng/projects/cardiac_ageing_target_clearance"; os.chdir(ROOT)
sys.path.insert(0, f"{ROOT}/03_code/04_models"); import pbtools_v11 as pb
OUT = "04_results/synthesis_v1.1"; os.makedirs(OUT, exist_ok=True)
MODF = "01_config/modules/modules_v1.1.tsv"
assert hashlib.sha256(open(MODF, "rb").read()).hexdigest() == "3a2abdad2b609002752b4d4833d8219114fd305b2339c7ddf406da86448591be"
mods = pd.read_csv(MODF, sep="\t"); MODS = {k: sorted(set(v)) for k, v in mods.groupby("module")["gene"]}
GC = ["FKBP5", "TSC22D3", "ZBTB16", "PER1", "KLF9", "DDIT4", "KLF15", "MT2A"]; MODS["GC_response"] = GC
MLIST = ["RES_EFF_core", "MHCII_core", "RES_EFF_lit", "ISG_IFN", "MAC_PAN_ID", "GC_response"]
HEAT = sorted(set(MODS["RES_EFF_lit"]) | set(MODS["MHCII_core"]) | set(GC) | set(MODS["MAC_PAN_ID"]))
rng = np.random.default_rng(20261003); LOG = {}; T0 = time.time()
def tick(msg): print(f"[{time.time() - T0:7.1f}s] {msg}", flush=True)
dup = pd.read_csv("04_results/validation_v1.1/donor_overlap/gse290367_duplicate_individuals.csv"); DROP = set(dup.record_drop)
tq = lambda d_, a: stats.t.ppf(1 - a / 2, d_)

def fitD(df, ycol, term, covs, cats=("study",)):
    d = df.dropna(subset=[ycol, term] + list(covs)); D = pb.design(d, [term] + list(covs), cats)
    b, se, p, kind = pb.ols_hc3(D.values, d[ycol].values, j=1, return_kind=True); dfree = len(d) - D.shape[1]
    return dict(beta=b, se=se, ci_lo=b - tq(dfree, .05) * se, ci_hi=b + tq(dfree, .05) * se, p=p, df_resid=dfree, se_kind=kind, n=len(d)), d
def tost(b, se, dfree, bound=0.1):
    pl = stats.t.sf((b + bound) / se, dfree); pu = stats.t.cdf((b - bound) / se, dfree)
    return dict(ci90_lo=b - tq(dfree, .10) * se, ci90_hi=b + tq(dfree, .10) * se, p_tost=max(pl, pu), equivalent=bool(max(pl, pu) < .05))
def hksj(df, ycol, min_n=8):
    rows = []
    for st, d in df.dropna(subset=[ycol]).groupby("study"):
        if len(d) < min_n or d.age.std() < 5: continue
        cov = ["female"] if d.female.std() > 0 else []
        D = pb.design(d, ["age10"] + cov); b, se, p = pb.ols_hc3(D.values, d[ycol].values, 1); rows.append((st, len(d), b, se))
    if len(rows) < 2: return None, rows
    yb = np.array([r[2] for r in rows]); v = np.array([r[3] for r in rows]) ** 2; w = 1 / v; k = len(yb)
    mu_f = (w * yb).sum() / w.sum(); Q = (w * (yb - mu_f) ** 2).sum(); C = w.sum() - (w ** 2).sum() / w.sum(); tau2 = max(0, (Q - (k - 1)) / C)
    ws = 1 / (v + tau2); mu = (ws * yb).sum() / ws.sum(); q = (ws * (yb - mu) ** 2).sum() / (k - 1); se = np.sqrt(q / ws.sum())
    out = dict(beta=mu, se=se, ci_lo=mu - tq(k - 1, .05) * se, ci_hi=mu + tq(k - 1, .05) * se, p=2 * stats.t.sf(abs(mu / se), k - 1),
               df_resid=k - 1, n=int(sum(r[1] for r in rows)), k_studies=k, tau2=tau2, I2=max(0, (Q - (k - 1)) / Q) if Q > 0 else 0.0)
    out.update(tost(mu, se, k - 1)); return out, rows
def auc(x_case, x_ctrl):
    u = stats.mannwhitneyu(x_case, x_ctrl, alternative="two-sided"); return u.statistic / (len(x_case) * len(x_ctrl)), u.pvalue
def sep(x_case, x_ctrl):
    a, p = auc(np.asarray(x_case), np.asarray(x_ctrl))
    return dict(n_case=len(x_case), n_ctrl=len(x_ctrl), auc_case_gt_ctrl=a, mw_p=p, n_case_ge_min_ctrl=int((np.asarray(x_case) >= np.min(x_ctrl)).sum()),
                n_ctrl_le_max_case=int((np.asarray(x_ctrl) <= np.max(x_case)).sum()), max_case=float(np.max(x_case)), min_ctrl=float(np.min(x_ctrl)))

try:
    import h5py, scipy.sparse as sp, scanpy as sc, harmonypy as hm
    SCP = f"{ROOT}/02_data/raw/SCP3342/HFpEF_snRNAseq_single_cell_portal_withRawCounts_09.24.2026.h5ad"
    def dec(a): return np.array([x.decode() if isinstance(x, bytes) else x for x in a])
    def obs_col(gr, k):
        o = gr[k]
        if isinstance(o, h5py.Group): cats = dec(o["categories"][:]); codes = o["codes"][:]; return np.where(codes >= 0, cats[np.clip(codes, 0, None)], None)
        return dec(o[:])
    def read_rows(grp, rows, ncol):
        ip = grp["indptr"][:]; rows = np.sort(np.asarray(rows)); D, I, P = [], [], [0]
        for r in np.split(rows, np.flatnonzero(np.diff(rows) != 1) + 1):
            a, b = ip[r[0]], ip[r[-1] + 1]; D.append(grp["data"][a:b]); I.append(grp["indices"][a:b]); P.extend((ip[r[0] + 1:r[-1] + 2] - a + P[-1]).tolist())
        return sp.csr_matrix((np.concatenate(D), np.concatenate(I), np.array(P)), shape=(len(rows), ncol)), rows
    f = h5py.File(SCP, "r"); o = f["obs"]; oi = obs_col(o, "_index"); oc = obs_col(o, "original_cell_type")
    var = dec(f["var"]["_index"][:]); sel = np.flatnonzero(np.isin(oc, ["Macrophage", "Proliferating_macrophage"]))
    Xq, sel = read_rows(f["layers/raw_count_cellbender"], sel, len(var)); f.close()
    ann = pd.read_csv("04_results/validation_v1.1/substates/SCP3342_macrophage_nuclei_annotation.csv", index_col=0, dtype={"donor_id": str})
    q = sc.AnnData(Xq.astype(np.float32)); q.obs_names = oi[sel]; q.var_names = var; q.var_names_make_unique()
    assert set(q.obs_names) == set(ann.index), "nuclei mismatch"; q.obs = ann.loc[q.obs_names].copy()
    bad = lambda x: x.startswith("MT-") or x.startswith("RPL") or x.startswith("RPS"); EXCp = set(MODS["RES_EFF_core"]) | set(MODS["MHCII_core"])
    qn = q.copy(); sc.pp.normalize_total(qn, 1e4); sc.pp.log1p(qn); Ln = qn.X.copy()
    sc.pp.highly_variable_genes(qn, n_top_genes=2000, flavor="seurat", batch_key="pool")
    qn.var.loc[[x for x in qn.var_names if x in EXCp or bad(x)], "highly_variable"] = False
    qh = qn[:, qn.var.highly_variable].copy(); sc.pp.scale(qh, max_value=10); sc.tl.pca(qh, n_comps=30, random_state=0)
    Hq = hm.run_harmony(qh.obsm["X_pca"], qh.obs[["pool"]], ["pool"], random_state=0).Z_corr; Hq = Hq.T if Hq.shape[0] != qh.n_obs else Hq
    qn.obsm["X_harmony"] = Hq; sc.pp.neighbors(qn, use_rep="X_harmony", n_neighbors=15, random_state=0); sc.tl.umap(qn, random_state=0)
    U = q.obs[["donor_id", "pool", "hfpef", "female", "state_primary", "coarse_primary", "coarse_sens_excl_lit", "cluster"]].copy()
    U["UMAP1"], U["UMAP2"] = qn.obsm["X_umap"][:, 0], qn.obsm["X_umap"][:, 1]
    L = sp.csr_matrix(Ln); HF = []
    for k in ["Resident", "MonoDerived"]:
        msk = (q.obs.coarse_primary == k).values; ctl = msk & (q.obs.hfpef == 0).values
        for m in ["RES_EFF_core", "MHCII_core"]:
            gg = [x for x in MODS[m] if x in q.var_names]; G = L[:, q.var_names.get_indexer(gg)].toarray()
            mu, sd = G[ctl].mean(0), G[ctl].std(0); sd[sd == 0] = 1; s = ((G - mu) / sd).mean(1); thr = np.quantile(s[ctl], .75)
            U.loc[msk, f"cellscore_{m}"] = s[msk]; U.loc[msk, f"high_{m}"] = (s[msk] > thr).astype(float)
            t2 = pd.DataFrame({"donor_id": q.obs.donor_id.values[msk], "hi": s[msk] > thr}).groupby("donor_id").hi.agg(["sum", "size"]).reset_index()
            t2["substate"] = k; t2["module"] = m; t2["threshold_ctrl_Q75"] = thr; HF.append(t2)
    # all-nuclei module means for colouring
    for m in ["RES_EFF_core", "MHCII_core"]:
        gg = [x for x in MODS[m] if x in q.var_names]; U[f"meanlog_{m}"] = np.asarray(L[:, q.var_names.get_indexer(gg)].mean(1)).ravel()
    U.to_csv(f"{OUT}/SCP3342_umap_nuclei.csv")
    HFd = pd.concat(HF).merge(q.obs.groupby("donor_id")[["hfpef", "pool"]].first().reset_index(), on="donor_id"); HFd["frac_high"] = HFd["sum"] / HFd["size"]
    HFd.to_csv(f"{OUT}/SCP3342_highfrac_by_donor.csv", index=False); LOG["scp_umap"] = "ok"
except Exception as ex:
    import traceback; LOG["scp_umap_error"] = traceback.format_exc()

json.dump(LOG, open(f"{OUT}/scp_umap_run_log.json", "w"), indent=1, default=str)
tick("SCP UMAP done")
