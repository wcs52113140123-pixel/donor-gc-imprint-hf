#!/usr/bin/env python3
"""Track Substates (v1.1 validation) - SCP3342 (HFpEF vs control septal snRNA-seq) macrophage substates.
Macrophage + Proliferating_macrophage nuclei (cellbender counts). Label transfer from HCA heart v2 ventricular myeloid cell_state
(harmony-joint PCA -> logistic regression). Endpoint genes (RES_EFF_core, MHCII_core) EXCLUDED from all annotation features
(sensitivity: also exclude RES_EFF_lit). Per donor: substate fractions, within-substate pseudobulk scores, per-cell RES_EFF-high / MHCII-high
fractions in Resident nuclei. Model: y ~ HFpEF + female + C(pool), HC3 (HC2 fallback). No per-donor ages -> no ageing test here.
NOTE: SCP3342 is a DISCOVERY dataset for RES_EFF_core/MHCII_core; within-substate decomposition is new structure, not independent validation."""
import os, sys, json, hashlib, numpy as np, pandas as pd, h5py, scipy.sparse as sp
ROOT = os.environ["PROJ_ROOT"]  # [v12-wrap] was hard-coded "/home/weichangsheng/projects/cardiac_ageing_target_clearance"
sys.path.insert(0, f"{ROOT}/03_code/04_models"); import pbtools_v11 as pb
import scanpy as sc, harmonypy as hm
from sklearn.linear_model import LogisticRegression
from sklearn.cluster import KMeans
from scipy import stats
rng = np.random.default_rng(20261003); sc.settings.n_jobs = 16
OUT = f"{ROOT}/04_results/validation_v1.1/substates"; os.makedirs(OUT, exist_ok=True)
MODF = f"{ROOT}/01_config/modules/modules_v1.1.tsv"
assert hashlib.sha256(open(MODF, "rb").read()).hexdigest() == "3a2abdad2b609002752b4d4833d8219114fd305b2339c7ddf406da86448591be"
mods = pd.read_csv(MODF, sep="\t"); MODS = {k: sorted(set(v)) for k, v in mods.groupby("module")["gene"]}
SCP = f"{ROOT}/02_data/raw/SCP3342/HFpEF_snRNAseq_single_cell_portal_withRawCounts_09.24.2026.h5ad"
HCA = f"{ROOT}/02_data/raw/HCA_heart_v2/1e1e07c3-bfcb-4a0d-91de-c2614a891409.h5ad"
LOG = {}

def dec(a): return np.array([x.decode() if isinstance(x, bytes) else x for x in a])
def obs_col(g, k):
    o = g[k]
    if isinstance(o, h5py.Group): cats = dec(o["categories"][:]); codes = o["codes"][:]; return np.where(codes >= 0, cats[np.clip(codes, 0, None)], None)
    return dec(o[:])
def read_rows(grp, rows, ncol):
    """CSR row subset from an h5 group (data/indices/indptr) by contiguous runs."""
    ip = grp["indptr"][:]; rows = np.sort(np.asarray(rows)); D, I, P = [], [], [0]
    runs = np.split(rows, np.flatnonzero(np.diff(rows) != 1) + 1)
    for r in runs:
        a, b = ip[r[0]], ip[r[-1] + 1]; d = grp["data"][a:b]; ix = grp["indices"][a:b]; D.append(d); I.append(ix)
        P.extend((ip[r[0] + 1:r[-1] + 2] - a + P[-1]).tolist())
    return sp.csr_matrix((np.concatenate(D), np.concatenate(I), np.array(P)), shape=(len(rows), ncol)), rows

# ---------------- query: SCP3342 macrophages ----------------
f = h5py.File(SCP, "r"); o = f["obs"]
obs = pd.DataFrame({k: obs_col(o, k) for k in ["_index", "original_cell_type", "original_disease", "donor_id", "biosample_id", "sex", "ncount", "percent_mito"]})
var = pd.DataFrame({k: dec(f["var"][k][:]) for k in ["_index", "gene_ids"]})
sel = np.flatnonzero(obs.original_cell_type.isin(["Macrophage", "Proliferating_macrophage"]).values)
Xq, sel = read_rows(f["layers/raw_count_cellbender"], sel, len(var)); f.close()
q = sc.AnnData(Xq.astype(np.float32), obs=obs.iloc[sel].set_index("_index"), var=var.set_index("_index")); q.var_names_make_unique()
q.obs["donor_id"] = q.obs.donor_id.astype(str); q.obs["pool"] = q.obs.biosample_id.astype(str); q.obs["hfpef"] = (q.obs.original_disease == "hfpef").astype(float)
q.obs["female"] = (q.obs.sex == "female").astype(float); q.obs["umi"] = np.asarray(q.X.sum(1)).ravel()
LOG["query_nuclei"] = int(q.n_obs); LOG["query_by_type"] = q.obs.original_cell_type.value_counts().to_dict()
dp = q.obs.groupby("donor_id").pool.nunique(); LOG["donors_in_multiple_pools"] = int((dp > 1).sum())
# ---------------- reference: HCA heart v2 ventricular myeloid ----------------
MYS = ["CD14+Mo", "CD16+Mo", "MoMP", "LYVE1+IGF1+MP", "LYVE1+TIMD4+MP", "LYVE1+MP_cycling", "DC", "Neut"]
f = h5py.File(HCA, "r"); o = f["obs"]
ro = pd.DataFrame({k: obs_col(o, k) for k in ["cell_state", "region", "donor_id", "suspension_type"]})
rsel = np.flatnonzero(ro.cell_state.isin(MYS).values & ro.region.isin(["LV", "RV", "SP", "AX"]).values)
LOG["ref_myeloid_ventricular_by_suspension"] = ro.iloc[rsel].suspension_type.value_counts().to_dict()
nuc = rsel[ro.iloc[rsel].suspension_type.values == "nucleus"]
if len(nuc) >= 5000: rsel = nuc; LOG["ref_suspension_used"] = "nucleus"
else: LOG["ref_suspension_used"] = "cell+nucleus"
lab = ro.cell_state.values[rsel]; keep = []
for s in MYS:                                   # cap 3000 per state for training balance
    ii = np.flatnonzero(lab == s); keep.extend(rng.choice(ii, min(len(ii), 3000), replace=False) if len(ii) else [])
rsel = np.sort(rsel[np.array(keep)])
rvar = dec(f["raw/var"]["_index"][:]) if "_index" in f["raw/var"] else dec(f["var"]["_index"][:])
Xr, rsel = read_rows(f["raw/X"], rsel, len(rvar)); f.close()
r = sc.AnnData(Xr.astype(np.float32), obs=ro.iloc[rsel].reset_index(drop=True)); r.var_names = rvar
LOG["ref_cells_by_state"] = r.obs.cell_state.value_counts().to_dict()
# gene matching by Ensembl id
ens2sym = dict(zip(q.var.gene_ids, q.var_names)); shared = [g for g in r.var_names if g in ens2sym]
r = r[:, shared].copy(); r.var_names = [ens2sym[g] for g in shared]; r.var_names_make_unique()
qs = q[:, [ens2sym[g] for g in shared]].copy(); LOG["shared_genes"] = len(shared)
for a in (r, qs): sc.pp.normalize_total(a, 1e4); sc.pp.log1p(a)
sc.pp.highly_variable_genes(r, n_top_genes=2500, flavor="seurat", batch_key="donor_id")
hv = r.var_names[r.var.highly_variable].tolist()
bad = lambda g: g.startswith("MT-") or g.startswith("RPL") or g.startswith("RPS")
EXC = {"primary": set(MODS["RES_EFF_core"]) | set(MODS["MHCII_core"]),
       "sens_excl_lit": set(MODS["RES_EFF_core"]) | set(MODS["MHCII_core"]) | set(MODS["RES_EFF_lit"])}
def zs(M): M = np.asarray(M.todense() if sp.issparse(M) else M); mu = M.mean(0); sd = M.std(0); sd[sd == 0] = 1; return np.clip((M - mu) / sd, -10, 10)
PRED = {}
for tag, exc in EXC.items():
    feats = [g for g in hv if g not in exc and not bad(g) and g in qs.var_names]; LOG[f"features_{tag}"] = len(feats)
    Zr = zs(r[:, feats].X); Zq = zs(qs[:, feats].X)
    U, S, Vt = np.linalg.svd(Zr - Zr.mean(0), full_matrices=False); W = Vt[:30].T
    P = np.vstack([Zr @ W, Zq @ W]); meta = pd.DataFrame({"ds": ["ref"] * len(Zr) + ["q"] * len(Zq),
                                                         "b": list(r.obs.donor_id.astype(str)) + list("q_" + qs.obs.pool.values)})
    H = hm.run_harmony(P, meta, ["ds", "b"], max_iter_harmony=20, random_state=0).Z_corr; H = H.T if H.shape[0] != P.shape[0] else H
    clf = LogisticRegression(max_iter=3000, C=0.5, class_weight="balanced").fit(H[:len(Zr)], r.obs.cell_state.values)
    pr = clf.predict_proba(H[len(Zr):]); PRED[tag] = (clf.classes_[pr.argmax(1)], pr.max(1))
    # internal check: 5-fold-ish holdout accuracy on ref
    idx = rng.permutation(len(Zr)); ho = idx[:len(idx) // 5]; tr = idx[len(idx) // 5:]
    acc = (LogisticRegression(max_iter=3000, C=0.5, class_weight="balanced").fit(H[tr], r.obs.cell_state.values[tr]).predict(H[ho]) == r.obs.cell_state.values[ho]).mean()
    LOG[f"ref_holdout_accuracy_{tag}"] = float(acc)
COLL = {"LYVE1+IGF1+MP": "Resident", "LYVE1+TIMD4+MP": "Resident", "LYVE1+MP_cycling": "Resident", "MoMP": "MonoDerived", "CD14+Mo": "MonoDerived", "CD16+Mo": "MonoDerived", "DC": "DC", "Neut": "Neut"}
for tag, (lb, pm) in PRED.items():
    lb = np.where(pm >= 0.5, lb, "uncertain"); q.obs[f"state_{tag}"] = lb; q.obs[f"pmax_{tag}"] = pm
    q.obs[f"coarse_{tag}"] = [COLL.get(x, "uncertain") for x in lb]
LOG["label_counts_primary"] = q.obs.state_primary.value_counts().to_dict(); LOG["label_counts_sens"] = q.obs.state_sens_excl_lit.value_counts().to_dict()
LOG["coarse_agreement_primary_vs_sens"] = float((q.obs.coarse_primary == q.obs.coarse_sens_excl_lit).mean())
# ---------------- query-only embedding + clusters (features also exclude endpoint genes) ----------------
qn = q.copy(); sc.pp.normalize_total(qn, 1e4); sc.pp.log1p(qn); q.layers["lognorm"] = qn.X.copy()
sc.pp.highly_variable_genes(qn, n_top_genes=2000, flavor="seurat", batch_key="pool")
qn.var.loc[[g for g in qn.var_names if g in EXC["primary"] or bad(g)], "highly_variable"] = False
qh = qn[:, qn.var.highly_variable].copy(); sc.pp.scale(qh, max_value=10); sc.tl.pca(qh, n_comps=30, random_state=0)
Hq = hm.run_harmony(qh.obsm["X_pca"], qh.obs[["pool"]], ["pool"], random_state=0).Z_corr; Hq = Hq.T if Hq.shape[0] != qh.n_obs else Hq
qn.obsm["X_harmony"] = Hq; sc.pp.neighbors(qn, use_rep="X_harmony", n_neighbors=15, random_state=0); sc.tl.umap(qn, random_state=0)
q.obs["cluster"] = KMeans(8, n_init=20, random_state=0).fit_predict(Hq).astype(str); q.obsm["X_umap"] = qn.obsm["X_umap"]
MK = ["LYVE1", "FOLR2", "TIMD4", "IGF1", "SIGLEC1", "MRC1", "CD163", "F13A1", "C1QA", "MERTK", "CCR2", "FCN1", "VCAN", "S100A8", "S100A9", "LYZ", "CD14", "FCGR3A",
      "HLA-DRA", "HLA-DQA1", "CD74", "CD1C", "CLEC10A", "SPP1", "TREM2", "APOE", "MKI67", "TOP2A", "IL1B", "CXCL8", "NR4A1"]
MK = [g for g in MK if g in qn.var_names]
cm = pd.DataFrame(qn[:, MK].X.toarray(), columns=MK, index=q.obs_names).groupby(q.obs.cluster.values).mean()
ct = pd.crosstab(q.obs.cluster, q.obs.state_primary); cm = cm.join(ct.div(ct.sum(1), axis=0).add_prefix("frac_")).join(q.obs.cluster.value_counts().rename("n_nuclei"))
cm.to_csv(f"{OUT}/SCP3342_cluster_markers_vs_transfer.csv")
q.obs.to_csv(f"{OUT}/SCP3342_macrophage_nuclei_annotation.csv")
# UMAP preview
import matplotlib; matplotlib.use("Agg"); import matplotlib.pyplot as plt
fig, ax = plt.subplots(1, 4, figsize=(20, 4.6))
for a, col in zip(ax[:2], ["state_primary", "cluster"]):
    for k, v in q.obs.groupby(col).groups.items():
        ii = q.obs_names.get_indexer(v); a.scatter(q.obsm["X_umap"][ii, 0], q.obsm["X_umap"][ii, 1], s=3, label=f"{k} ({len(ii)})")
    a.legend(fontsize=6, markerscale=3, frameon=False); a.set_title(col); a.set_xticks([]); a.set_yticks([])
for a, gl, ttl in [(ax[2], MODS["RES_EFF_core"], "RES_EFF_core (mean lognorm)"), (ax[3], MODS["MHCII_core"], "MHCII_core (mean lognorm)")]:
    gg = [g for g in gl if g in qn.var_names]; v = np.asarray(qn[:, gg].X.mean(1)).ravel()
    s_ = a.scatter(q.obsm["X_umap"][:, 0], q.obsm["X_umap"][:, 1], c=v, s=3, cmap="viridis"); fig.colorbar(s_, ax=a); a.set_title(ttl); a.set_xticks([]); a.set_yticks([])
fig.suptitle("SCP3342 macrophage nuclei (n=%d; endpoint genes excluded from embedding/label-transfer features)" % q.n_obs, fontsize=9)
fig.tight_layout(); fig.savefig(f"{OUT}/SCP3342_substates_umap.png", dpi=130)

# ---------------- donor-level statistics ----------------
DON = q.obs.groupby("donor_id").agg(hfpef=("hfpef", "first"), female=("female", "first"), pool=("pool", "first"), n_mac=("umi", "size"))
LOG["donors_total"] = int(len(DON)); LOG["donors_by_group"] = DON.hfpef.map({1.0: "hfpef", 0.0: "control"}).value_counts().to_dict()
def fit(df, y, covs=("female",), term="hfpef"):
    d = df.assign(_y=y).dropna(subset=["_y"]); D = pb.design(d, [term] + list(covs), ["pool"])
    b, se, p, kind = pb.ols_hc3(D.values, d._y.values, 1, return_kind=True); dfree = len(d) - D.shape[1]; t = stats.t.ppf(.975, dfree)
    return dict(beta=b, se=se, ci_lo=b - t * se, ci_hi=b + t * se, p=p, df_resid=dfree, se_kind=kind, n=len(d), n_disease=int(d[term].sum()), n_ref=int((d[term] == 0).sum()))
EFF = []
MINMAC = 30
for tag in ["primary", "sens_excl_lit"]:
    for level in ["state", "coarse"]:
        cnt = pd.crosstab(q.obs.donor_id, q.obs[f"{level}_{tag}"]); D2 = DON.join(cnt).fillna(0); D2 = D2[D2.n_mac >= MINMAC]
        for k in cnt.columns:
            fr = D2[k] / D2.n_mac; lg = np.log((D2[k] + .5) / (D2.n_mac - D2[k] + .5))
            rr = fit(D2, lg.values); EFF.append(dict(dataset="SCP3342", analysis="composition", annotation=tag, level=level, substate=k, module="logit_fraction", model="primary",
                                                    mean_frac_hfpef=fr[D2.hfpef == 1].mean(), mean_frac_control=fr[D2.hfpef == 0].mean(), **rr))
# within-substate pseudobulk scores
Xc = q.X.tocsr()
def pseudobulk(mask_cells, minc=20, minu=5000):
    s = q.obs[mask_cells]; g = s.groupby("donor_id").indices; rows, M = [], []
    for dn, ii in g.items():
        ix = q.obs_names.get_indexer(s.index[ii]); m = np.asarray(Xc[ix].sum(0)).ravel()
        if len(ix) >= minc and m.sum() >= minu: rows.append(dn); M.append(m)
    return DON.loc[rows].assign(n_cells=[len(g[d]) for d in rows]), np.vstack(M) if M else None
SC = []
VARIANTS = [("primary", 20, 5000, "pool"), ("sens_global_centre", 20, 5000, "global"), ("sens_thr10_2k", 10, 2000, "pool"), ("sens_thr10_2k_global", 10, 2000, "global")]
for tag in ["primary", "sens_excl_lit"]:
    groups = {"AllMacrophage": np.ones(q.n_obs, bool)}
    for k in ["Resident", "MonoDerived"]: groups[k] = (q.obs[f"coarse_{tag}"] == k).values
    for k in ["LYVE1+IGF1+MP", "LYVE1+TIMD4+MP", "MoMP"]: groups[k] = (q.obs[f"state_{tag}"] == k).values
    for k, msk in groups.items():
        if tag != "primary" and k == "AllMacrophage": continue
        for vname, minc, minu, centre in VARIANTS:
            if tag != "primary" and vname != "primary": continue
            df, M = pseudobulk(msk, minc, minu)
            if M is None or df.hfpef.sum() < 3 or (df.hfpef == 0).sum() < 3:
                EFF.append(dict(dataset="SCP3342", analysis="within_substate_state", annotation=tag, level="pseudobulk", substate=k, module="ALL", model=vname, estimable=False,
                                n_disease=0 if M is None else int(df.hfpef.sum()), n_ref=0 if M is None else int((df.hfpef == 0).sum()))); continue
            isref = (df.hfpef == 0).values; grp = df.pool.values if centre == "pool" else np.zeros(len(df))
            lc, gk = pb.lognorm(M, q.var_names.values, "CPM"); Z = pb.ref_z(lc, grp, isref)   # pool centring: pools w/o control -> NaN rows (dropped)
            S = {}
            for m in ["RES_EFF_core", "MHCII_core", "RES_EFF_lit", "ISG_IFN", "MAC_PAN_ID"]: S[m], _ = pb.module_score(Z, gk, MODS[m], isref)
            S["EFF_MHCII_index"] = S["RES_EFF_core"] - S["MHCII_core"]
            for m, v in S.items(): df[m] = v
            df["substate"] = k; df["annotation"] = tag; df["variant"] = vname; SC.append(df.reset_index())
            for m in S:
                for mdl, cov in [("", ("female",)), ("+adj_MAC_PAN_ID", ("female", "MAC_PAN_ID"))]:
                    if mdl and (m == "MAC_PAN_ID" or vname != "primary"): continue
                    rr = fit(df, df[m].values, cov)
                    est = bool(rr["n_disease"] >= 3 and rr["n_ref"] >= 3 and rr["df_resid"] >= 3)
                    EFF.append(dict(dataset="SCP3342", analysis="within_substate_state", annotation=tag, level="pseudobulk", substate=k, module=m, model=vname + mdl, estimable=est,
                                    min_nuclei=minc, min_umi=minu, centring=centre, **rr))
pd.concat(SC).to_csv(f"{OUT}/SCP3342_substate_donor_scores.csv", index=False)
# per-cell RES_EFF-high / MHCII-high fractions within Resident (and MonoDerived)
L = q.layers["lognorm"].tocsr()
for tag in ["primary", "sens_excl_lit"]:
    for k in ["Resident", "MonoDerived"]:
        msk = (q.obs[f"coarse_{tag}"] == k).values; ctl = msk & (q.obs.hfpef == 0).values
        for m in ["RES_EFF_core", "MHCII_core"]:
            gg = [g for g in MODS[m] if g in q.var_names]; G = L[:, q.var_names.get_indexer(gg)].toarray()
            mu, sd = G[ctl].mean(0), G[ctl].std(0); sd[sd == 0] = 1; s = ((G - mu) / sd).mean(1)
            thr = np.quantile(s[ctl], .75); hi = s > thr
            t_ = pd.DataFrame({"donor_id": q.obs.donor_id.values[msk], "hi": hi[msk]}).groupby("donor_id").hi.agg(["sum", "size"])
            D2 = DON.join(t_, how="inner"); D2 = D2[D2["size"] >= 10]
            lg = np.log((D2["sum"] + .5) / (D2["size"] - D2["sum"] + .5)); rr = fit(D2, lg.values)
            EFF.append(dict(dataset="SCP3342", analysis="percell_high_fraction", annotation=tag, level="cell", substate=k, module=f"{m}_high(>ctrl Q75)", model="primary",
                            mean_frac_hfpef=(D2["sum"] / D2["size"])[D2.hfpef == 1].mean(), mean_frac_control=(D2["sum"] / D2["size"])[D2.hfpef == 0].mean(), **rr))
            q.obs[f"cellscore_{m}_{tag}"] = np.where(msk, s, np.nan)
E = pd.DataFrame(EFF)
if "estimable" not in E: E["estimable"] = True
E["estimable"] = E["estimable"].fillna(True).astype(bool)
pd.crosstab(q.obs.cluster, q.obs.original_disease).join(pd.crosstab(q.obs.cluster, q.obs.coarse_primary)).to_csv(f"{OUT}/SCP3342_cluster_by_disease_coarse.csv")
fl = pd.crosstab([q.obs.donor_id, q.obs.original_disease], q.obs.state_primary); fl.to_csv(f"{OUT}/SCP3342_donor_by_finelabel_counts.csv")
LOG["cluster_by_disease"] = pd.crosstab(q.obs.cluster, q.obs.original_disease).to_dict()
LOG["finelabel_by_disease_nuclei"] = pd.crosstab(q.obs.state_primary, q.obs.original_disease).to_dict()
def bh(p):
    p = np.asarray(p, float); ok = ~np.isnan(p); out = np.full_like(p, np.nan); pp = p[ok]; o = np.argsort(pp); qv = pp[o] * len(pp) / np.arange(1, len(pp) + 1)
    qv = np.minimum.accumulate(qv[::-1])[::-1]; tmp = np.empty_like(pp); tmp[o] = np.minimum(qv, 1); out[ok] = tmp; return out
def fam(r):
    if r.analysis == "within_substate_state": return "H3_state_primary" if (r.annotation == "primary" and r.substate in ("Resident", "MonoDerived") and r.module in ("RES_EFF_core", "MHCII_core") and r.model == "primary") else "H3_state_secondary"
    if r.analysis == "composition": return "H3_composition_primary" if (r.annotation == "primary") else "H3_composition_sens"
    return "H3_percell_" + r.annotation
E["family"] = E.apply(fam, axis=1); E["q_BH_family"] = np.nan
for (fm, mdl), idx in E[E.estimable].groupby(["family", "model"]).groups.items(): E.loc[idx, "q_BH_family"] = bh(E.loc[idx, "p"].values)
E["circularity_note"] = np.where(E.substate.eq("AllMacrophage") & E.module.isin(["RES_EFF_core", "MHCII_core", "EFF_MHCII_index"]), "DISCOVERY (circular)",
                                 "SCP3342 is a discovery dataset: within-substate decomposition is new structure, not independent validation")
E.to_csv(f"{OUT}/substates_SCP3342_effects.csv", index=False)
json.dump(LOG, open(f"{OUT}/SCP3342_run_log.json", "w"), indent=1, default=str)
print(json.dumps(LOG, default=str))
pd.set_option("display.width", 250)
print(E[E.module.isin(["RES_EFF_core", "MHCII_core", "EFF_MHCII_index"]) & E.analysis.eq("within_substate_state")][["annotation", "substate", "module", "model", "estimable", "n_disease", "n_ref", "beta", "ci_lo", "ci_hi", "p", "se_kind"]].round(3).to_string())

