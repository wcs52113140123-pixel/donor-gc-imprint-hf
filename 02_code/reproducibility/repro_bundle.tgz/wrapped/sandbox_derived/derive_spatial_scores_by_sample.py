#!/usr/bin/env python3
# [v12-wrap] Post-processing step originally executed in the analysis sandbox (not on the server); code recovered from
# artifact lineage of spatial_scores_by_sample.csv (version 38a4cd8c-b209-4fcd-805b-0aa8aecc391c). Only input/output paths were parameterised:
#   inputs  -> files under $IN_DIR (rerun copies of the upstream server outputs), outputs -> cwd ($OUT_DIR).
import os; IN = os.environ["IN_DIR"].rstrip("/") + "/"; os.chdir(os.environ["OUT_DIR"])
import re
import numpy as np
import pandas as pd
from scipy import stats

S = pd.read_csv(IN + 'spatial_scores_by_section_raw.csv')

def kgroup(s):
    if s.startswith('control'): return 'control'
    if 'FZ' in s: return 'fibrotic(FZ)'
    if 'IZ' in s: return 'ischaemic(IZ)'
    return 'remote/border(RZ/BZ)'

S['patient'] = S.apply(lambda r: r['donor'] if r['dataset'] == 'E-MTAB-12975' else re.search(r'(P\d+)', r['section']).group(1), axis=1)
S['group'] = S.apply(lambda r: 'HCA_nonfailing' if r['dataset'] == 'E-MTAB-12975' else kgroup(r['section']), axis=1)
S['zone_label_file'] = S.apply(lambda r: 'HCA_' + str(r.get('region', '')) if r['dataset'] == 'E-MTAB-12975' else r['section'].rsplit('_P', 1)[0], axis=1)

for d in ['macrich', 'macrich_deconv']:
    S[f'RES_per_MAC__{d}'] = (S[f'RES_EFF_core__{d}'] - S['RES_EFF_core__all']) / (S[f'MAC_PAN_ID__{d}'] - S['MAC_PAN_ID__all'])
    S[f'MHCII_per_MAC__{d}'] = (S[f'MHCII_core__{d}'] - S['MHCII_core__all']) / (S[f'MAC_PAN_ID__{d}'] - S['MAC_PAN_ID__all'])

for d in ['macrich', 'macrich_deconv']:
    S[f'EFF_MHCII_index__{d}'] = np.nan
    for ds, ref in [('Kuppe2022', 'control'), ('E-MTAB-12975', 'HCA_nonfailing')]:
        m = S.dataset == ds
        r = m & (S.group == ref)
        z = lambda c: (S.loc[m, c] - S.loc[r, c].mean()) / S.loc[r, c].std(ddof=1)
        S.loc[m, f'EFF_MHCII_index__{d}'] = z(f'RES_EFF_core__{d}') - z(f'MHCII_core__{d}')

S.to_csv('spatial_scores_by_sample.csv', index=False)