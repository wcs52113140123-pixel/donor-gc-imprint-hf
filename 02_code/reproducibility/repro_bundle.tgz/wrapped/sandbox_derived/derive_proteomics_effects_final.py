#!/usr/bin/env python3
# [v12-wrap] Post-processing step originally executed in the analysis sandbox (not on the server); code recovered from
# artifact lineage of proteomics_effects.csv (version 2f20694c-e1df-470f-9398-c950eda53019). Only input/output paths were parameterised:
#   inputs  -> files under $IN_DIR (rerun copies of the upstream server outputs), outputs -> cwd ($OUT_DIR).
import os; IN = os.environ["IN_DIR"].rstrip("/") + "/"; os.chdir(os.environ["OUT_DIR"])
import numpy as np
import pandas as pd
import json
import re
from scipy import stats

# Load proteomics effects from checkpoint
E = pd.read_csv(IN + 'proteomics_effects.csv')

# Load proteomics detection (computed inline from E)
# Reconstruct detection info from E
det_cols = ['feature', 'num_NAs_processed_of20']
# num_NAs_processed_of20 comes from proteomics_detection.csv via det.set_index('gene')['num_NAs_processed']
# We need to reconstruct it from the effects table where it was mapped
# Since we don't have proteomics_detection.csv as artifact, reconstruct from E
# [v12-wrap] the lineage-recovered line read this column from E (where it does not exist); the comment above states the
# original mapping: det.set_index('gene')['num_NAs_processed'] from proteomics_detection.csv
nna = pd.read_csv(IN + 'proteomics_detection.csv').set_index('gene')['num_NAs_processed']

E['num_NAs_processed_of20'] = E['feature'].map(nna)
E['imputation_dominated'] = np.where(
    E.layer.eq('A_processed_imputed') & E.level.eq('protein'),
    E['num_NAs_processed_of20'].astype(float) > 8,
    False
)
E.loc[E.level.eq('module'), 'imputation_dominated'] = np.nan

G = pd.read_csv(IN + 'prot_grep.txt', sep='\t')

drows = []
for _, r in G.iterrows():
    for case, nc in [('HFpEF', r.n_HFpEF), ('HFrEF', r.n_HFreduced)]:
        tab = [[nc, 10 - nc], [r.n_Control, 10 - r.n_Control]]
        orr, p = stats.fisher_exact(tab)
        drows.append(dict(level='detection_rate', feature=r['Gene.names'],
                          modules='immune_proxy_posthoc(not frozen)',
                          layer='B_rawIntensity_noImpute',
                          contrast=f'{case}_vs_Control', covariates='none',
                          n_case=10, n_ctrl=10,
                          detected_case=nc, detected_ctrl=r.n_Control,
                          p_fisher=p,
                          note='presence/absence across runs; exploratory'))

for g in ['ITGAM', 'PTPRC']:
    dd = E[(E.feature == g) & (E.layer == 'B_rawIntensity_noImpute') & (E.covariates == 'group')]
    for _, r in dd.iterrows():
        nc, n0 = int(r.n_case), int(r.n_ctrl)
        tab = [[nc, 10 - nc], [n0, 10 - n0]]
        drows.append(dict(level='detection_rate', feature=g,
                          modules='extra_marker',
                          layer='B_rawIntensity_noImpute',
                          contrast=r.contrast, covariates='none',
                          n_case=10, n_ctrl=10,
                          detected_case=nc, detected_ctrl=n0,
                          p_fisher=stats.fisher_exact(tab)[1],
                          note='presence/absence across runs; exploratory'))

DET = pd.DataFrame(drows)
PE = pd.concat([E, DET], ignore_index=True, sort=False)
PE.insert(0, 'dataset', 'PXD060431 (DDA-LFQ, JHU biobank; RV septal EMB)')
PE.to_csv('proteomics_effects.csv', index=False)