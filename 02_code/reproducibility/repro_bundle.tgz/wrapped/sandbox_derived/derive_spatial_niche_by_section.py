#!/usr/bin/env python3
# [v12-wrap] Post-processing step originally executed in the analysis sandbox (not on the server); code recovered from
# artifact lineage of spatial_niche_by_section.csv (version 0cb1dc5b-ec64-4312-864b-95c5175fb1b1). Only input/output paths were parameterised:
#   inputs  -> files under $IN_DIR (rerun copies of the upstream server outputs), outputs -> cwd ($OUT_DIR).
import os; IN = os.environ["IN_DIR"].rstrip("/") + "/"; os.chdir(os.environ["OUT_DIR"])
import pandas as pd
import numpy as np
from scipy import stats
import re

J2 = IN + 'spatial_niche_by_section_raw.csv'
N = pd.read_csv(J2)

# Load spatial scores by section (needed for group/patient mapping)
# Reconstruct S from the visium job outputs
# We need the section->group and section->patient mappings

def kgroup(s):
    if s.startswith('control'): return 'control'
    if 'FZ' in s: return 'fibrotic(FZ)'
    if 'IZ' in s: return 'ischaemic(IZ)'
    return 'remote/border(RZ/BZ)'

# Rebuild S from N (spatial_niche has dataset and section columns)
# We need group and patient for each section
sections = N[['dataset','section']].drop_duplicates()
# [v12-wrap] the lineage-recovered code set patient=NaN for HCA sections; the archived file carries the HCA donor id
# (as in derive_spatial_niche.py), so take it from spatial_scores_by_section_raw.csv:
_S = pd.read_csv(IN + 'spatial_scores_by_section_raw.csv').drop_duplicates('section').set_index('section')
sections['patient'] = sections.apply(
    lambda r: re.search(r'(P\d+)', r['section']).group(1) if r['dataset'] == 'Kuppe2022' else _S.at[r['section'], 'donor'],
    axis=1
)
sections['group'] = sections.apply(
    lambda r: 'HCA_nonfailing' if r['dataset'] == 'E-MTAB-12975' else kgroup(r['section']),
    axis=1
)

N = N.merge(sections[['section','group','patient']], on='section', how='left')

N['std_diff'] = N.diff_high_minus_low / N.sd_macrich

def agg(g):
    x = g.std_diff.dropna(); r = g.spearman_within_macrich.dropna()
    p = stats.wilcoxon(x).pvalue if len(x) >= 5 and (x != 0).any() else np.nan
    pr = stats.wilcoxon(r).pvalue if len(r) >= 5 and (r != 0).any() else np.nan
    return pd.Series(dict(n_sections=len(x), n_patients=g.patient.nunique(), median_std_diff=x.median(), mean_std_diff=x.mean(), n_pos=int((x > 0).sum()),
                          wilcoxon_p_std_diff=p, median_spearman=r.median(), wilcoxon_p_spearman=pr))

N['strata'] = np.where(N.dataset == 'E-MTAB-12975', 'HCA_nonfailing', np.where(N.group == 'control', 'Kuppe_control', 'Kuppe_MI'))
NA = N.groupby(['strata', 'macrich_def', 'ranking', 'feature']).apply(agg).reset_index()
NA2 = N[N.dataset == 'Kuppe2022'].groupby(['macrich_def', 'ranking', 'feature']).apply(agg).reset_index()
NA2.insert(0, 'strata', 'Kuppe_all')
NA = pd.concat([NA, NA2])

def bh(p):
    p = np.asarray(p, float); q = np.full(len(p), np.nan); ok = np.isfinite(p); n = ok.sum()
    if n == 0: return q
    o = np.argsort(p[ok]); r = p[ok][o] * n / np.arange(1, n + 1); r = np.minimum.accumulate(r[::-1])[::-1]; t = np.empty(n); t[o] = np.minimum(r, 1); q[ok] = t; return q

NA['fdr_bh'] = NA.groupby(['strata', 'macrich_def', 'ranking']).wilcoxon_p_std_diff.transform(lambda s: pd.Series(bh(s.values), index=s.index))

N.to_csv('spatial_niche_by_section.csv', index=False)