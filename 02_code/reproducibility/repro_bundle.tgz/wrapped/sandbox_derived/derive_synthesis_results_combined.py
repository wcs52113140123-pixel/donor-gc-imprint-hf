#!/usr/bin/env python3
# [v12-wrap] Post-processing step originally executed in the analysis sandbox (not on the server); code recovered (raw producing cell; plotting lines dropped) from
# artifact lineage of synthesis_reanalysis_results.csv (version 3677045e-3240-40b4-b764-4e3b17e46bce). Only input/output paths were parameterised:
#   inputs  -> files under $IN_DIR (rerun copies of the upstream server outputs), outputs -> cwd ($OUT_DIR).
import os; IN = os.environ["IN_DIR"].rstrip("/") + "/"; os.chdir(os.environ["OUT_DIR"])
import pandas as pd
S = IN
allr = pd.read_csv(S + "synthesis_reanalysis_results.csv")
if "A3_GC_by_study_posthoc" in set(allr.track):   # idempotent: already combined
    raise SystemExit("already combined")
PS=pd.read_csv(S+"A3_GSE290367_DCM_by_study_GC.csv").assign(track="A3_GC_by_study_posthoc",dataset="GSE290367",version="dedup_individuals",contrast=lambda x:"DCM_vs_ND_within_"+x.study,model="within_study_age+sex_HC3",n_disease=lambda x:x.n_dcm,n_ref=lambda x:x.n_nd).drop(columns=["n_dcm","n_nd","study"])
comb=pd.concat([allr,PS],ignore_index=True); comb.to_csv("synthesis_reanalysis_results.csv",index=False); print(comb.shape)
