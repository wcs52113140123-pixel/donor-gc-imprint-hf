#!/usr/bin/env python3
# [v12-wrap] Post-processing step originally executed in the analysis sandbox (not on the server); code recovered from
# artifact lineage of A3_GSE290367_DCM_by_study_GC.csv (version 98375f46-c3dc-4724-b732-eac11f8681d4). Only input/output paths were parameterised:
#   inputs  -> files under $IN_DIR (rerun copies of the upstream server outputs), outputs -> cwd ($OUT_DIR).
import os; IN = os.environ["IN_DIR"].rstrip("/") + "/"; os.chdir(os.environ["OUT_DIR"])
import numpy as np
import pandas as pd
import statsmodels.api as sm

S = IN

out = []
for subset in ["Myeloid_pooled", "Resident", "Monocyte_derived"]:
    if subset == "Myeloid_pooled":
        df = pd.read_csv(S + "A1_GSE290367_L2_donor_scores_Myeloid_pooled_dedup.csv")
    else:
        # These files are read from S (data_syn/) in the trace
        df = pd.read_csv(S + f"A1_GSE290367_L2_donor_scores_{subset}_dedup.csv")
    for st in ["Chaffin 2022", "Koenig 2022", "Reichart 2022"]:
        d = df[(df.study == st) & df.disease.isin(["ND", "DCM"])].copy()
        d["isD"] = (d.disease == "DCM").astype(float)
        for m in ["GC_response", "RES_EFF_core", "MHCII_core"]:
            X = sm.add_constant(d[["isD", "age10", "female"]].astype(float))
            f = sm.OLS(d[m], X).fit(cov_type="HC3")
            out.append(dict(subset=subset, study=st, module=m, n_dcm=int(d.isD.sum()), n_nd=int((d.isD == 0).sum()),
                            beta=f.params.isD, ci_lo=f.conf_int().loc["isD", 0], ci_hi=f.conf_int().loc["isD", 1], p=f.pvalues.isD))

PS = pd.DataFrame(out)
PS.to_csv("A3_GSE290367_DCM_by_study_GC.csv", index=False)