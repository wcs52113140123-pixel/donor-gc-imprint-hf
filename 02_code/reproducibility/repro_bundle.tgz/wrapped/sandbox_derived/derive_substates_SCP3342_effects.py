#!/usr/bin/env python3
# [v12-wrap] Post-processing step originally executed in the analysis sandbox (not on the server); code recovered from
# artifact lineage of substates_SCP3342_effects.csv (version 1aca9004-358f-4d60-85ba-2af4e68bdf78). Only input/output paths were parameterised:
#   inputs  -> files under $IN_DIR (rerun copies of the upstream server outputs), outputs -> cwd ($OUT_DIR).
import os; IN = os.environ["IN_DIR"].rstrip("/") + "/"; os.chdir(os.environ["OUT_DIR"])
import pandas as pd, json, numpy as np

S = pd.read_csv('' + IN + 'substates_SCP3342_effects.csv')

def bh(p):
    p = np.asarray(p, float); ok = ~np.isnan(p); out = np.full_like(p, np.nan); pp = p[ok]
    if len(pp) == 0: return out
    o = np.argsort(pp); q = pp[o] * len(pp) / np.arange(1, len(pp) + 1); q = np.minimum.accumulate(q[::-1])[::-1]; t = np.empty_like(pp); t[o] = np.minimum(q, 1); out[ok] = t; return out

RULE = 'n_disease>=5 & n_ref>=8 & df_resid>=5 & finite CI (disease/composition); ageing: n>=15'
S['estimable'] = S.apply(lambda r: False if r.module == 'ALL' else bool(r.n_disease >= 5 and r.n_ref >= 8 and r.df_resid >= 5 and np.isfinite(r.ci_lo) and np.isfinite(r.ci_hi) and r.se > 0), axis=1)
S['estimability_rule'] = RULE
S['q_BH_family'] = np.nan
for (f, m), idx in S[S.estimable].groupby(['family', 'model']).groups.items():
    S.loc[idx, 'q_BH_family'] = bh(S.loc[idx, 'p'])
S['fine_label_note'] = np.where(S.substate.isin(['LYVE1+IGF1+MP', 'LYVE1+TIMD4+MP', 'MoMP', 'CD14+Mo', 'CD16+Mo', 'LYVE1+MP_cycling']), 'fine HCA label: exploratory; resident fine labels split by disease (see cluster table)', '')

S.to_csv('substates_SCP3342_effects.csv', index=False)