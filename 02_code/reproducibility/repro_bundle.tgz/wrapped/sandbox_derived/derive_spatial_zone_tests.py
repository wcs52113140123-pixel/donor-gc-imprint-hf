#!/usr/bin/env python3
# [v12-wrap] Post-processing step originally executed in the analysis sandbox (not on the server); code recovered from
# artifact lineage of spatial_zone_tests.csv (version 8391299f-596d-4ed2-8189-cd6b5733efd4). Only input/output paths were parameterised:
#   inputs  -> files under $IN_DIR (rerun copies of the upstream server outputs), outputs -> cwd ($OUT_DIR).
import os; IN = os.environ["IN_DIR"].rstrip("/") + "/"; os.chdir(os.environ["OUT_DIR"])
import numpy as np
import pandas as pd
from scipy import stats
import re

S = pd.read_csv(IN + 'spatial_scores_by_section_raw.csv')

def kgroup(s):
    if s.startswith('control'): return 'control'
    if 'FZ' in s: return 'fibrotic(FZ)'
    if 'IZ' in s: return 'ischaemic(IZ)'
    return 'remote/border(RZ/BZ)'

S['patient'] = S.apply(lambda r: r['donor'] if r['dataset'] == 'E-MTAB-12975' else re.search(r'(P\d+)', r['section']).group(1), axis=1)
S['group'] = S.apply(lambda r: 'HCA_nonfailing' if r['dataset'] == 'E-MTAB-12975' else kgroup(r['section']), axis=1)
S['zone_label_file'] = S.apply(lambda r: 'HCA_' + str(r.get('region', '')) if r['dataset'] == 'E-MTAB-12975' else r['section'].rsplit('_P', 1)[0], axis=1)

for d in ['macrich', 'macrich_deconv']:
    S[f'RES_per_MAC__{d}'] = (S[f'RES_EFF_core__{d}'] - S['RES_EFF_core__all']) / (S[f'MAC_PAN_ID__{d}'] - S['MAC_PAN_ID__all'])
    S[f'MHCII_per_MAC__{d}'] = (S[f'MHCII_core__{d}'] - S['MHCII_core__all']) / (S[f'MAC_PAN_ID__{d}'] - S['MAC_PAN_ID__all'])

for d in ['macrich', 'macrich_deconv']:
    S[f'EFF_MHCII_index__{d}'] = np.nan
    for ds, ref in [('Kuppe2022', 'control'), ('E-MTAB-12975', 'HCA_nonfailing')]:
        m = S.dataset == ds; r = m & (S.group == ref)
        z = lambda c: (S.loc[m, c] - S.loc[r, c].mean()) / S.loc[r, c].std(ddof=1)
        S.loc[m, f'EFF_MHCII_index__{d}'] = z(f'RES_EFF_core__{d}') - z(f'MHCII_core__{d}')

K = S[S.dataset == 'Kuppe2022'].copy()

def ols_hc3(X, y):
    XtXi = np.linalg.pinv(X.T @ X); b = XtXi @ X.T @ y; e = y - X @ b; h = np.einsum('ij,jk,ik->i', X, XtXi, X)
    w = (e / np.clip(1 - h, 1e-6, None)) ** 2; V = XtXi @ (X.T * w) @ X @ XtXi; return b, np.sqrt(np.diag(V)), len(y) - X.shape[1]

outs = ['RES_EFF_core', 'MHCII_core', 'EFF_MHCII_index', 'RES_per_MAC', 'MHCII_per_MAC', 'RES_EFF_core_noLYVE1', 'RES_EFF_lit', 'ISG_IFN']
recs = []
for d in ['macrich', 'macrich_deconv']:
    U = K.groupby(['patient', 'group'], as_index=False).mean(numeric_only=True)
    for unit, DF in [('section', K), ('patient_x_group_mean', U)]:
        for o in outs:
            col = f'{o}__{d}'
            for adj in ['none', 'MAC_PAN_ID__' + d]:
                if o in ('RES_per_MAC', 'MHCII_per_MAC', 'EFF_MHCII_index') and adj != 'none': continue
                for contrast in ['remote/border(RZ/BZ)', 'ischaemic(IZ)', 'fibrotic(FZ)', 'any_MI']:
                    sub = DF if contrast == 'any_MI' else DF[DF.group.isin(['control', contrast])]
                    y = sub[col].values.astype(float); x = (sub.group != 'control').astype(float).values
                    X = np.column_stack([np.ones(len(y)), x] + ([sub[adj].values] if adj != 'none' else []))
                    ok = np.isfinite(y) & np.isfinite(X).all(1)
                    b, se, df = ols_hc3(X[ok], y[ok]); p = 2 * stats.t.sf(abs(b[1] / se[1]), df); tq = stats.t.ppf(.975, df)
                    sdc = np.std(y[(x == 0) & ok], ddof=1)
                    mw = stats.mannwhitneyu(y[(x == 1) & ok], y[(x == 0) & ok]).pvalue
                    recs.append(dict(dataset='Kuppe2022', macrich_def=d, unit=unit, outcome=o, adjusted_for=adj, contrast=f'{contrast}_vs_control',
                                     n_case=int((x[ok] == 1).sum()), n_ctrl=int((x[ok] == 0).sum()), beta=b[1], ci_lo=b[1] - tq * se[1], ci_hi=b[1] + tq * se[1],
                                     beta_ctrlSD=b[1] / sdc, p_hc3=p, p_mannwhitney_unadj=mw, mean_case=np.mean(y[(x == 1) & ok]), mean_ctrl=np.mean(y[(x == 0) & ok])))

Z = pd.DataFrame(recs)

Z = Z[~((Z.unit == 'patient_x_group_mean') & (Z.contrast == 'any_MI_vs_control'))]
recs = []
for d in ['macrich', 'macrich_deconv']:
    K2 = K.copy(); K2['isMI'] = (K2.group != 'control')
    U = K2.groupby(['patient', 'isMI'], as_index=False).mean(numeric_only=True)
    for o in outs:
        col = f'{o}__{d}'
        for adj in ['none', 'MAC_PAN_ID__' + d]:
            if o in ('RES_per_MAC', 'MHCII_per_MAC', 'EFF_MHCII_index') and adj != 'none': continue
            y = U[col].values.astype(float); x = U.isMI.astype(float).values
            X = np.column_stack([np.ones(len(y)), x] + ([U[adj].values] if adj != 'none' else []))
            b, se, df = ols_hc3(X, y); p = 2 * stats.t.sf(abs(b[1] / se[1]), df); tq = stats.t.ppf(.975, df); sdc = np.std(y[x == 0], ddof=1)
            recs.append(dict(dataset='Kuppe2022', macrich_def=d, unit='patient_x_MIstatus_mean', outcome=o, adjusted_for=adj, contrast='any_MI_vs_control',
                             n_case=int(x.sum()), n_ctrl=int((1 - x).sum()), beta=b[1], ci_lo=b[1] - tq * se[1], ci_hi=b[1] + tq * se[1], beta_ctrlSD=b[1] / sdc, p_hc3=p,
                             p_mannwhitney_unadj=stats.mannwhitneyu(y[x == 1], y[x == 0]).pvalue, mean_case=y[x == 1].mean(), mean_ctrl=y[x == 0].mean()))

Z = pd.concat([Z, pd.DataFrame(recs)], ignore_index=True)
Z.to_csv('spatial_zone_tests.csv', index=False)