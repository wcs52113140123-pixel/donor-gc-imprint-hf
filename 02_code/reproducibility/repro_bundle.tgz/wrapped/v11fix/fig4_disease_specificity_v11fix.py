#!/usr/bin/env python3
"""Fig 4 — disease specificity in GSE290367 (adult LV). Healthy (ND) donors define the normative reference:
genes are centred on the ND mean within each study and scaled by pooled ND SD; module scores are expressed in ND-SD units.
(1) Disease effect: score ~ disease + age/10 + female + study, restricted to studies that contain that disease (HC3).
(2) Normative deviation: healthy model score ~ age/10 + female + study; each patient's deviation from the age/sex/study-expected value.
(3) Age-equivalent: disease effect / healthy age slope (years of normative ageing), donor bootstrap CI.
(4) Competitive test vs 1,000 expression-matched random sets.  (5) Myeloid composition and composition-adjusted clearance.
Run for CPM and TMM normalisation."""
import os, sys, numpy as np, pandas as pd
sys.path.insert(0, os.path.join(os.environ["PROJ_ROOT"], "03_code/04_models")); import pbtools_v11 as pb   # [v12-v11fix B1,B6] was: import pbtools as pb
rng = np.random.default_rng(20261003)
ROOT = os.environ["PROJ_ROOT"]; os.chdir(ROOT)
PB = "02_data/processed/GSE290367_pseudobulk"; OUT = os.environ.get("V12_OUT", "04_results/fig4_disease_specificity"); os.makedirs(OUT, exist_ok=True)
genes = pd.read_csv(f"{PB}/genes.csv").gene.astype(str).values

# [v12-v11fix] optional plan-v1.2 de-duplication (one record per individual) when V12_DEDUP=1
_V12_DROP = set(pd.read_csv(os.environ["V12_DUPFILE"]).record_drop) if os.environ.get("V12_DEDUP") == "1" else set()
mods = pd.read_csv("01_config/modules/modules_v1.0.tsv", sep="\t"); MODS = {k: sorted(set(v)) for k, v in mods.groupby("module")["gene"]}
def load(level):
    m = pd.read_csv(f"{PB}/pseudobulk_{level}_meta.csv"); m["age"] = pd.to_numeric(m.age, errors="coerce"); m["row"] = np.arange(len(m))
    m = m[~m.donor_id.isin(_V12_DROP)]   # [v12-v11fix] dedup (no-op unless V12_DEDUP=1)
    return m, np.load(f"{PB}/pseudobulk_{level}_counts.npy", mmap_mode="r")
L1, X1 = load("L1"); L2, X2 = load("L2")
DISEASES = ["DCM", "HCM", "ICM", "ARVC", "AMI"]
COMP = {"VascStromal": ["Endothelial", "Fibroblast", "Pericyte", "vSMC"], "Myeloid": ["Myeloid"]}
MODSET = {"VascStromal": ["T_senescence_SenMayo", "T_senescence_Fridman", "V_dont_eat_me_evasion", "I_immune_visibility", "ADJ_inflammation_hallmark", "ADJ_IFNG_hallmark"],
          "Myeloid": ["E_apoptotic_cell_clearance", "E_phagocytosis_engulfment", "E_lysosome", "E_efferocytosis_receptors", "E_myeloid_inhibitory_checkpoint",
                      "ADJ_inflammation_hallmark", "ADJ_IFNG_hallmark"]}
def compartment(cts):
    s = L1[(L1.region == "LV") & (L1.age_status == "postnatal") & (L1.age >= 20) & L1.cell_type.isin(cts) & L1.disease.isin(DISEASES + ["ND"])]
    thr = (20, 5000) if list(cts) == ["Myeloid"] else (50, 10000)   # [v12-v11fix B2] unified thresholds
    s = s[(s.n_cells >= thr[0]) & (s.total_umi >= thr[1])]; rows = s.groupby("donor_id").row.apply(list)
    M = np.stack([np.asarray(X1[r]).sum(0) for r in rows.values]).astype(float)
    d = s.groupby("donor_id").agg(age=("age", "first"), sex=("sex", "first"), study=("study", "first"), disease=("disease", "first"), n_cells=("n_cells", "sum")).loc[rows.index]
    d["female"] = (d.sex == "female").astype(float); d["age10"] = d.age / 10; d["ND"] = d.disease == "ND"
    keep_st = d[d.ND].groupby("study").size(); d = d[d.study.isin(keep_st[keep_st >= 3].index)]
    return d, M[[list(rows.index).index(i) for i in d.index]]
# myeloid subtype fractions (L2)
s2 = L2[(L2.region == "LV") & L2.cell_type.str.startswith("Myeloid:")].pivot_table(index="donor_id", columns="cell_type", values="n_cells", aggfunc="sum", fill_value=0)
frac = s2.div(s2.sum(1), axis=0)[["Myeloid:Resident", "Myeloid:Monocyte_derived"]].rename(columns={"Myeloid:Resident": "res", "Myeloid:Monocyte_derived": "mono"})
eff, dev, comp_rows, scores_all = [], [], [], {}
for norm in ["CPM", "TMM"]:
    for cname, cts in COMP.items():
        d, M = compartment(cts); lc, gk = pb.lognorm(M, genes, norm); Z = pb.ref_z(lc, d.study.values, d.ND.values)
        ok = ~np.isnan(Z).any(0); Z, gk, lcm = Z[:, ok], gk[ok], lc[:, ok].mean(0)
        for m in MODSET[cname]:
            y, ng = pb.module_score(Z, gk, MODS[m], d.ND.values); d["y"] = y; scores_all[(norm, cname, m)] = pd.Series(y, index=d.index)
            nd = d[d.ND]; Dn = pb.design(nd, ["age10", "female"], ["study"]); bA, sA, pA = pb.ols_hc3(Dn.values, nd.y.values)
            # normative deviation (LOO for ND donors)
            Dall = pb.design(d, ["age10", "female"], ["study"]).reindex(columns=Dn.columns, fill_value=0.0)
            Xn = Dn.values; XtXi = np.linalg.pinv(Xn.T @ Xn); bn = XtXi @ Xn.T @ nd.y.values; res = nd.y.values - Xn @ bn
            h = np.einsum("ij,jk,ik->i", Xn, XtXi, Xn); sig = np.sqrt(np.sum(res ** 2) / (len(nd) - Xn.shape[1]))
            dv = (d.y.values - Dall.values @ bn) / sig; dv[d.ND.values] = (res / (1 - h)) / sig
            for i, dn in enumerate(d.index): dev.append(dict(normalisation=norm, compartment=cname, module=m, donor_id=dn, disease=d.disease.iat[i], study=d.study.iat[i],
                                                             age=d.age.iat[i], sex=d.sex.iat[i], score=d.y.iat[i], normative_deviation=dv[i]))
            for dis in DISEASES:
                sub = d[d.study.isin(d[d.disease == dis].study.unique()) & d.disease.isin([dis, "ND"])].copy()
                if (sub.disease == dis).sum() < 4: continue
                sub["is_dis"] = (sub.disease == dis).astype(float); D = pb.design(sub, ["is_dis", "age10", "female"], ["study"])
                b, se, p = pb.ols_hc3(D.values, sub.y.values)
                boots = []
                for _ in range(500):
                    bi = np.concatenate([rng.choice(np.flatnonzero((sub.study == st).values & (sub.disease == g).values), ((sub.study == st) & (sub.disease == g)).sum())
                                         for st in sub.study.unique() for g in [dis, "ND"] if ((sub.study == st) & (sub.disease == g)).sum() > 0])
                    sb = sub.iloc[bi]; Db = pb.design(sb, ["is_dis", "age10", "female"], ["study"])
                    ndb = nd.iloc[rng.integers(0, len(nd), len(nd))]; Dnb = pb.design(ndb, ["age10", "female"], ["study"])
                    bb = np.linalg.lstsq(Db.values, sb.y.values, rcond=None)[0][1]; ab = np.linalg.lstsq(Dnb.values, ndb.y.values, rcond=None)[0][1]
                    boots.append(10 * bb / ab if abs(ab) > 1e-6 else np.nan)
                rows_sub = np.array([list(d.index).index(i) for i in sub.index])
                cp = pb.competitive(Z[rows_sub], gk, MODS[m], lcm, D.values, j=1, n=1000, rng=rng, is_ref=(sub.disease == "ND").values)
                eff.append(dict(normalisation=norm, compartment=cname, module=m, disease=dis, n_disease=int(sub.is_dis.sum()), n_ND=int((sub.disease == "ND").sum()),
                                studies=";".join(sorted(sub.study.unique())), n_genes=ng, beta=b, se=se, p=p, healthy_age_beta=bA, healthy_age_p=pA,
                                age_equiv_years=10 * b / bA, age_equiv_lo=np.nanpercentile(boots, 2.5), age_equiv_hi=np.nanpercentile(boots, 97.5),
                                mean_normative_dev=np.mean(dv[(d.disease == dis).values]), **cp))
        if cname == "Myeloid" and norm == "CPM":
            dd = d.join(frac, how="left")
            for dis in DISEASES:
                sub = dd[dd.study.isin(dd[dd.disease == dis].study.unique()) & dd.disease.isin([dis, "ND"])].dropna(subset=["res"]).copy()
                if (sub.disease == dis).sum() < 4: continue
                sub["is_dis"] = (sub.disease == dis).astype(float)
                for col in ["res", "mono"]:
                    sub["lg"] = np.log((sub[col] + 1e-3) / (1 - sub[col] + 1e-3)); D = pb.design(sub, ["is_dis", "age10", "female"], ["study"])
                    b, se, p = pb.ols_hc3(D.values, sub.lg.values); comp_rows.append(dict(disease=dis, outcome=f"logit_frac_{col}", beta=b, se=se, p=p,
                                                                                         mean_dis=sub.loc[sub.is_dis == 1, col].mean(), mean_ND=sub.loc[sub.is_dis == 0, col].mean()))
                sub["y"] = scores_all[("CPM", "Myeloid", "E_apoptotic_cell_clearance")].reindex(sub.index)
                D = pb.design(sub, ["is_dis", "age10", "female", "res", "mono"], ["study"]); b, se, p = pb.ols_hc3(D.values, sub.y.values)
                comp_rows.append(dict(disease=dis, outcome="clearance_adj_composition", beta=b, se=se, p=p))
        print(norm, cname, "done", flush=True)
# mismatch: T (VascStromal SenMayo) - E (Myeloid clearance), each in ND-SD units
for norm in ["CPM", "TMM"]:
    T = scores_all[(norm, "VascStromal", "T_senescence_SenMayo")]; E = scores_all[(norm, "Myeloid", "E_apoptotic_cell_clearance")]
    j = pd.concat([T.rename("T"), E.rename("E")], axis=1, join="inner")
    info = pd.DataFrame(dev).query("normalisation==@norm and compartment=='Myeloid' and module=='E_apoptotic_cell_clearance'").set_index("donor_id")[["disease", "study", "age", "sex"]]
    j = j.join(info); j["female"] = (j.sex == "female").astype(float); j["age10"] = j.age / 10; j["MM"] = j["T"] - j["E"]
    nd = j[j.disease == "ND"]; j["MM"] = (j.MM - nd.MM.mean()) / nd.MM.std(); nd = j[j.disease == "ND"]
    bA, sA, pA = pb.ols_hc3(pb.design(nd, ["age10", "female"], ["study"]).values, nd.MM.values)
    for dis in DISEASES:
        sub = j[j.study.isin(j[j.disease == dis].study.unique()) & j.disease.isin([dis, "ND"])].copy()
        if (sub.disease == dis).sum() < 4: continue
        sub["is_dis"] = (sub.disease == dis).astype(float); b, se, p = pb.ols_hc3(pb.design(sub, ["is_dis", "age10", "female"], ["study"]).values, sub.MM.values)
        eff.append(dict(normalisation=norm, compartment="VascStromal-Myeloid", module="MISMATCH_SenMayo_minus_clearance", disease=dis, n_disease=int(sub.is_dis.sum()),
                        n_ND=int((sub.disease == "ND").sum()), studies=";".join(sorted(sub.study.unique())), beta=b, se=se, p=p, healthy_age_beta=bA, healthy_age_p=pA,
                        age_equiv_years=10 * b / bA))
    j.to_csv(f"{OUT}/TE_mismatch_per_donor_{norm}.csv")
E_ = pd.DataFrame(eff); E_.to_csv(f"{OUT}/disease_effects.csv", index=False)
pd.DataFrame(dev).to_csv(f"{OUT}/normative_deviations_per_donor.csv.gz", index=False); pd.DataFrame(comp_rows).to_csv(f"{OUT}/myeloid_composition_by_disease.csv", index=False)
pd.set_option("display.width", 250)
print(E_[E_.module.isin(["E_apoptotic_cell_clearance", "T_senescence_SenMayo", "MISMATCH_SenMayo_minus_clearance", "E_lysosome"])]
      [["normalisation", "module", "disease", "n_disease", "n_ND", "beta", "p", "age_equiv_years", "z_comp", "p_comp"]].round(3).to_string())
print(pd.DataFrame(comp_rows).round(3).to_string())
