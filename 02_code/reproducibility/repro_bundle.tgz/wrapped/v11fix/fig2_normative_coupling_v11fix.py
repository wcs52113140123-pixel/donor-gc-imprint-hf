#!/usr/bin/env python3
"""Fig 2 — normative adult cardiac ageing in GSE290367 (healthy LV, age>=20; donor-level pseudobulk).
Primary (frozen v1.0): Target = SenMayo in vascular-stromal cells; Effector = GO apoptotic-cell clearance in myeloid;
Mismatch = z(T) - z(E). Statistical unit = donor. Study handled by within-study gene centring + study fixed effects,
plus within-study slope random-effects meta-analysis (HKSJ) and leave-one-study-out. Competitive test vs 1,000
expression/size-matched random gene sets with the identical design."""
import os, sys, json, numpy as np, pandas as pd, statsmodels.formula.api as smf
import statsmodels.formula.api as _smf_orig
from scipy import stats
from statsmodels.stats.multitest import multipletests
rng = np.random.default_rng(20261001)
ROOT = os.environ["PROJ_ROOT"]; os.chdir(ROOT)
PB = "02_data/processed/GSE290367_pseudobulk"; OUT = os.environ.get("V12_OUT", "04_results/fig2_normative_coupling"); os.makedirs(OUT, exist_ok=True)
genes = pd.read_csv(f"{PB}/genes.csv").gene.values
mods = pd.read_csv("01_config/modules/modules_v1.0.tsv", sep="\t")
MODS = {k: sorted(set(v)) for k, v in mods.groupby("module")["gene"]}
THR = {"major": (50, 10000), "rare": (20, 5000)}
# [v12-v11fix] optional plan-v1.2 de-duplication (one record per individual) when V12_DEDUP=1
_V12_DROP = set(pd.read_csv(os.environ["V12_DUPFILE"]).record_drop) if os.environ.get("V12_DEDUP") == "1" else set()

# [v12-v11fix B1] HC3 with HC2 fallback on singleton leverage (h>=0.999), mirroring pbtools_v11.ols_hc3.
class _HCFit:
    def __init__(self, formula, data):
        m = _smf_orig.ols(formula, data); r = m.fit(); X = m.exog; e = r.resid.values; XtXi = np.linalg.pinv(X.T @ X)
        h = np.einsum("ij,jk,ik->i", X, XtXi, X); self.nobs = r.nobs; self.params = r.params
        if (h >= 0.999).any():
            w = e ** 2 / np.clip(1 - h, 1e-12, None); w[h >= 0.999] = 0.0; self.se_kind = "HC2_singleton"
            V = XtXi @ (X.T * w) @ X @ XtXi; self.bse = pd.Series(np.sqrt(np.diag(V)), index=r.params.index)
            self.pvalues = pd.Series(2 * stats.norm.sf(np.abs(r.params.values / self.bse.values)), index=r.params.index)   # normal ref, as statsmodels robust default
        else:
            rr = m.fit(cov_type="HC3"); self.bse, self.pvalues, self.se_kind = rr.bse, rr.pvalues, "HC3"
class _SMF:
    @staticmethod
    def ols(formula, data): 
        class _M:
            def fit(self_, cov_type=None): return _HCFit(formula, data)
        return _M()
smf = _SMF()

def load(level):
    meta = pd.read_csv(f"{PB}/pseudobulk_{level}_meta.csv")
    X = np.load(f"{PB}/pseudobulk_{level}_counts.npy", mmap_mode="r")
    meta["age"] = pd.to_numeric(meta.age, errors="coerce"); meta["row"] = np.arange(len(meta))
    meta = meta[~meta.donor_id.isin(_V12_DROP)]   # [v12-v11fix] dedup (no-op unless V12_DEDUP=1); rows keep original index into X
    return meta, X
def eligible(meta, cts, thr):
    s = meta[(meta.region == "LV") & (meta.age_status == "postnatal") & (meta.disease == "ND") & (meta.age >= 20) & meta.cell_type.isin(cts)]
    return s[(s.n_cells >= thr[0]) & (s.total_umi >= thr[1])]
def compartment(meta, X, cts, thr, name):
    s = eligible(meta, cts, thr)
    rows = s.groupby("donor_id").row.apply(list)
    M = np.stack([np.asarray(X[r]).sum(0) for r in rows.values])            # donors x genes (pooled over listed cell types)
    d = s.groupby("donor_id").agg(age=("age", "first"), sex=("sex", "first"), study=("study", "first"),
                                  technology=("technology", "first"), n_cells=("n_cells", "sum")).loc[rows.index]
    d["compartment"] = name
    return d, M
def prep(M, d):
    lib = M.sum(1, keepdims=True); cpm = M / lib * 1e6
    keep = (cpm > 1).mean(0) >= 0.2
    lc = pd.DataFrame(np.log2(cpm[:, keep] + 1), index=d.index, columns=genes[keep])
    lcc = lc - lc.groupby(d.study.values).transform("mean")               # within-study centring
    Z = (lcc - lcc.mean()) / lcc.std().replace(0, np.nan)
    return Z.dropna(axis=1), lc                                            # FIX 2026-10-01: return UNcentred logCPM for expression matching
def modscore(Z, gl):
    g = [x for x in gl if x in Z.columns]; return Z[g].mean(1), len(g)
def design(d, extra=None):
    D = pd.concat([pd.Series(1.0, index=d.index, name="const"), (d.age / 10).rename("age10"),
                   (d.sex == "female").astype(float).rename("female"),
                   pd.get_dummies(d.study, prefix="st", drop_first=True, dtype=float)], axis=1)
    if extra is not None: D = pd.concat([D, extra], axis=1)
    return D
def competitive(Z, lc, d, gl, D):
    g = [x for x in gl if x in Z.columns]; mu = lc[Z.columns].mean() if False else None
    expr = lc[Z.columns].mean()                                           # mean uncentred logCPM for matching
    bins = pd.qcut(expr.rank(method="first"), 20, labels=False); inmod = Z.columns.isin(g)
    pool = {b: np.flatnonzero((bins.values == b) & ~inmod) for b in range(20)}   # [v12-v11fix B6] exclude module genes
    gb = bins.loc[g].values; Zv = Z.values; need = pd.Series(gb).value_counts().to_dict()
    def _draw(): return np.concatenate([rng.choice(pool[b], m, replace=False) for b, m in need.items()])   # [B6] without replacement within bin
    nul = np.stack([Zv[:, _draw()].mean(1) for _ in range(1000)], 1)
    Y = np.column_stack([Z[g].mean(1).values, nul]); Y = (Y - Y.mean(0)) / Y.std(0)
    B = np.linalg.lstsq(D.values, Y, rcond=None)[0][1]
    b0, bn = B[0], B[1:]
    return (b0 - bn.mean()) / bn.std(), (np.sum(np.abs(bn - bn.mean()) >= abs(b0 - bn.mean())) + 1) / 1001, b0, bn.mean(), bn.std()
def hksj(b, se):
    w = 1 / se**2; k = len(b); bf = np.sum(w * b) / w.sum(); Q = np.sum(w * (b - bf)**2)
    tau2 = max(0, (Q - (k - 1)) / (w.sum() - (w**2).sum() / w.sum())); ws = 1 / (se**2 + tau2)
    mu = np.sum(ws * b) / ws.sum(); q = np.sum(ws * (b - mu)**2) / (k - 1); seh = np.sqrt(max(q, 1) / ws.sum()) if False else np.sqrt(q / ws.sum())
    p = 2 * stats.t.sf(abs(mu / seh), k - 1); I2 = max(0, (Q - (k - 1)) / Q) if Q > 0 else 0
    return mu, seh, p, I2, tau2, k

L1, X1 = load("L1"); L2, X2 = load("L2")
COMP = {"VascStromal": (L1, X1, ["Endothelial", "Fibroblast", "Pericyte", "vSMC"], THR["major"]),
        "Endothelial": (L1, X1, ["Endothelial"], THR["major"]), "Fibroblast": (L1, X1, ["Fibroblast"], THR["major"]),
        "Pericyte": (L1, X1, ["Pericyte"], THR["major"]), "vSMC": (L1, X1, ["vSMC"], THR["major"]),
        "Myeloid": (L1, X1, ["Myeloid"], THR["rare"]),   # [v12-v11fix B2] myeloid >=20 nuclei & >=5k UMI
        "Myeloid_Resident": (L2, X2, ["Myeloid:Resident"], THR["rare"]),   # [B2]
        "Myeloid_MonoDerived": (L2, X2, ["Myeloid:Monocyte_derived"], THR["rare"]),   # [B2]
        "Lymphoid": (L1, X1, ["Lymphoid"], THR["rare"])}
ROLE = {"T_senescence_SenMayo": "T", "T_senescence_Fridman": "T", "V_dont_eat_me_evasion": "T", "I_immune_visibility": "T",
        "E_apoptotic_cell_clearance": "E", "E_phagocytosis_engulfment": "E", "E_lysosome": "E", "E_efferocytosis_receptors": "E",
        "E_myeloid_inhibitory_checkpoint": "E", "C_cytotoxic_NK_CD8": "C", "ADJ_inflammation_hallmark": "A", "ADJ_IFNG_hallmark": "A"}
TARGET_C = ["VascStromal", "Endothelial", "Fibroblast", "Pericyte", "vSMC"]; EFF_C = ["Myeloid", "Myeloid_Resident", "Myeloid_MonoDerived"]
scores, age_rows, meta_rows, loso_rows, cov = {}, [], [], [], []
for cname, (meta, X, cts, thr) in COMP.items():
    d, M = compartment(meta, X, cts, thr, cname); Z, lc = prep(M, d)
    for mname, gl in MODS.items():
        r = ROLE[mname]
        if (r == "T" and cname not in TARGET_C) or (r == "E" and cname not in EFF_C) or (r == "C" and cname != "Lymphoid") or (r == "A" and cname not in ["VascStromal", "Myeloid"]):
            continue
        s, ng = modscore(Z, gl); s = (s - s.mean()) / s.std(); scores[(cname, mname)] = s
        cov.append(dict(compartment=cname, module=mname, n_genes=len(gl), n_measured=ng, n_donors=len(d)))
        dd = d.assign(score=s)
        for label, f in [("primary", "score ~ I(age/10) + female + C(study)"), ("ncells_adj", "score ~ I(age/10) + female + C(study) + np.log(n_cells)")]:
            fit = smf.ols(f, dd.assign(female=(dd.sex == "female").astype(float))).fit(cov_type="HC3")
            age_rows.append(dict(compartment=cname, module=mname, model=label, n=int(fit.nobs), beta_per_decade=fit.params["I(age / 10)"],
                                 se=fit.bse["I(age / 10)"], p=fit.pvalues["I(age / 10)"]))
        z40 = dd[dd.age >= 40]
        fit = smf.ols("score ~ I(age/10) + female + C(study)", z40.assign(female=(z40.sex == "female").astype(float))).fit(cov_type="HC3")
        age_rows.append(dict(compartment=cname, module=mname, model="age>=40", n=int(fit.nobs), beta_per_decade=fit.params["I(age / 10)"],
                             se=fit.bse["I(age / 10)"], p=fit.pvalues["I(age / 10)"]))
        zc, pc, b0, nm, nsd = competitive(Z, lc, d, gl, design(d))
        age_rows.append(dict(compartment=cname, module=mname, model="competitive_vs_1000_random_sets", n=len(d), beta_per_decade=b0, se=np.nan, p=pc, z=zc,
                             null_mean=nm, null_sd=nsd))
        b, se, ks = [], [], []
        for st, g in dd.groupby("study"):
            if len(g) >= 8 and g.age.std() >= 5:
                ff = smf.ols("score ~ I(age/10) + female", g.assign(female=(g.sex == "female").astype(float))).fit(cov_type="HC3")
                b.append(ff.params["I(age / 10)"]); se.append(ff.bse["I(age / 10)"]); ks.append(f"{st}(n={len(g)})")
        if len(b) >= 3:
            mu, seh, p, I2, tau2, k = hksj(np.array(b), np.array(se))
            meta_rows.append(dict(compartment=cname, module=mname, k_studies=k, studies=";".join(ks), beta_re=mu, se_hksj=seh, p_hksj=p, I2=I2, tau2=tau2,
                                  study_betas=";".join(f"{x:.3f}" for x in b)))
        if r in "TE" and mname in ["T_senescence_SenMayo", "E_apoptotic_cell_clearance"]:
            for st in dd.study.unique():
                g = dd[dd.study != st]
                ff = smf.ols("score ~ I(age/10) + female + C(study)", g.assign(female=(g.sex == "female").astype(float))).fit(cov_type="HC3")
                loso_rows.append(dict(compartment=cname, module=mname, left_out=st, n=int(ff.nobs), beta=ff.params["I(age / 10)"], p=ff.pvalues["I(age / 10)"]))
    d.to_csv(f"{OUT}/donors_{cname}.csv")

age = pd.DataFrame(age_rows)
prim = age.model == "primary"
age.loc[prim, "fdr_familyB"] = multipletests(age.loc[prim, "p"], method="fdr_bh")[1]
age.to_csv(f"{OUT}/age_effects.csv", index=False); pd.DataFrame(meta_rows).to_csv(f"{OUT}/within_study_meta_HKSJ.csv", index=False)
pd.DataFrame(loso_rows).to_csv(f"{OUT}/leave_one_study_out.csv", index=False); pd.DataFrame(cov).to_csv(f"{OUT}/module_coverage.csv", index=False)

# ---- coupling + mismatch (donor-level joins) ----
dm = pd.read_csv(f"{OUT}/donors_Myeloid.csv", index_col=0)
crows = []; per_donor = []
for tc in TARGET_C:
    for tm, em, ec in [("T_senescence_SenMayo", "E_apoptotic_cell_clearance", "Myeloid"), ("T_senescence_Fridman", "E_phagocytosis_engulfment", "Myeloid"),
                       ("T_senescence_SenMayo", "E_lysosome", "Myeloid"), ("T_senescence_SenMayo", "E_efferocytosis_receptors", "Myeloid"),
                       ("T_senescence_SenMayo", "E_apoptotic_cell_clearance", "Myeloid_Resident"), ("T_senescence_SenMayo", "E_apoptotic_cell_clearance", "Myeloid_MonoDerived"),
                       ("T_senescence_SenMayo", "E_myeloid_inhibitory_checkpoint", "Myeloid")]:
        if (tc, tm) not in scores or (ec, em) not in scores: continue
        j = pd.concat([scores[(tc, tm)].rename("T"), scores[(ec, em)].rename("E")], axis=1, join="inner")
        j = j.join(dm[["age", "sex", "study"]]).dropna()
        j["female"] = (j.sex == "female").astype(float)
        j["T"] = (j["T"] - j["T"].mean()) / j["T"].std(); j["E"] = (j["E"] - j["E"].mean()) / j["E"].std(); j["MM"] = j["T"] - j["E"]
        f1 = smf.ols("E ~ T + I(age/10) + female + C(study)", j).fit(cov_type="HC3")
        f2 = smf.ols("MM ~ I(age/10) + female + C(study)", j).fit(cov_type="HC3")
        f3 = smf.ols("E ~ T * I(age/10) + female + C(study)", j).fit(cov_type="HC3")
        rT, pT = stats.spearmanr(j["T"], j["E"])
        crows.append(dict(target_comp=tc, target=tm, effector_comp=ec, effector=em, n=len(j), spearman_TE=rT, p_spearman=pT,
                          coupling_beta=f1.params["T"], coupling_p=f1.pvalues["T"],
                          mismatch_beta_per_decade=f2.params["I(age / 10)"], mismatch_se=f2.bse["I(age / 10)"], mismatch_p=f2.pvalues["I(age / 10)"],
                          coupling_x_age_beta=f3.params["T:I(age / 10)"], coupling_x_age_p=f3.pvalues["T:I(age / 10)"]))
        if tc == "VascStromal" and tm == "T_senescence_SenMayo" and em == "E_apoptotic_cell_clearance" and ec == "Myeloid":
            j.to_csv(f"{OUT}/primary_TE_per_donor.csv")
cp = pd.DataFrame(crows); cp.to_csv(f"{OUT}/coupling_mismatch.csv", index=False)
pd.set_option("display.width", 250)
print(age[age.model.isin(["primary", "competitive_vs_1000_random_sets"])].round(4).to_string())
print(pd.DataFrame(meta_rows).drop(columns=["studies"]).round(4).to_string())
print(cp.round(4).to_string())
