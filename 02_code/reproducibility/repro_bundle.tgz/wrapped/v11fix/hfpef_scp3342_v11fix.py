#!/usr/bin/env python3
"""HFpEF vs non-failing controls in SCP3342 (septal biopsies; 19 vs 24 donors; 8 pools each containing both groups).
Same module definitions/scoring as the healthy-ageing analysis. Controls = reference (genes centred on control mean,
scaled by control SD); effects in control-SD units. Model: score ~ HFpEF + female + C(pool), HC3.
Per-donor ages are not public (group medians 65 vs 58.5 y), so age confounding is bounded with the healthy normative
slope from GSE290367: expected age contribution = beta_age(per decade) x 0.65 decade.
Sensitivities: CellRanger counts, TMM, >=50 myeloid nuclei, no pool term, leave-one-pool-out; myeloid composition;
gene-level HFpEF effects vs healthy-ageing gene effects."""
import os, sys, numpy as np, pandas as pd
from scipy import stats
sys.path.insert(0, os.path.join(os.environ["PROJ_ROOT"], "03_code/04_models")); import pbtools_v11 as pb   # [v12-v11fix B1,B6] was: import pbtools as pb
rng = np.random.default_rng(20261004)
ROOT = os.environ["PROJ_ROOT"]; os.chdir(ROOT)
PB = "02_data/processed/SCP3342_pseudobulk"; OUT = os.environ.get("V12_OUT", "04_results/hfpef_scp3342"); os.makedirs(OUT, exist_ok=True)
meta = pd.read_csv(f"{PB}/pseudobulk_meta.csv", dtype={"donor_id": str}); genes = pd.read_csv(f"{PB}/genes.csv").gene.astype(str).values
mods = pd.read_csv("01_config/modules/modules_v1.0.tsv", sep="\t"); MODS = {k: sorted(set(v)) for k, v in mods.groupby("module")["gene"]}
ageG = pd.read_csv(os.environ.get("V12_FIG2", "04_results/fig2_normative_coupling") + "/age_effects.csv"); ageG = ageG[ageG.model == "primary"].set_index(["compartment", "module"])
gaG = pd.read_csv(sys.argv[1]) if len(sys.argv) > 1 else None          # GSE290367 gene-level age effects
DAGE = 0.65                                                              # median age difference (65 - 58.5 y) in decades
COMP = {"Myeloid": (["Macrophage", "Proliferating_macrophage"], (20, 5000)), "VascStromal": (["Endothelial1", "Endothelial2", "Fibroblast", "Pericyte", "VSMC"], (50, 10000)),
        "Endothelial": (["Endothelial1", "Endothelial2"], (50, 10000)), "Fibroblast": (["Fibroblast"], (50, 10000)), "Pericyte": (["Pericyte"], (50, 10000))}
MODSET = {"Myeloid": ["E_apoptotic_cell_clearance", "E_phagocytosis_engulfment", "E_lysosome", "E_efferocytosis_receptors", "E_myeloid_inhibitory_checkpoint",
                      "ADJ_inflammation_hallmark", "ADJ_IFNG_hallmark"],
          "VascStromal": ["T_senescence_SenMayo", "T_senescence_Fridman", "V_dont_eat_me_evasion", "I_immune_visibility", "ADJ_inflammation_hallmark", "ADJ_IFNG_hallmark"],
          "Endothelial": ["T_senescence_SenMayo", "T_senescence_Fridman"], "Fibroblast": ["T_senescence_SenMayo", "T_senescence_Fridman"], "Pericyte": ["T_senescence_SenMayo", "T_senescence_Fridman"]}
AGEMAP = {"Myeloid": "Myeloid", "VascStromal": "VascStromal", "Endothelial": "Endothelial", "Fibroblast": "Fibroblast", "Pericyte": "Pericyte"}
CNT = {L: np.load(f"{PB}/pseudobulk_{L}.npy", mmap_mode="r") for L in ["raw_count_cellbender", "raw_count_cellranger"]}
def compartment(cts, thr, layer):
    s = meta[meta.cell_type.isin(cts)].copy(); s["row"] = s.index
    g = s.groupby("donor_id").agg(n_cells=("n_cells", "sum"), umi=(f"total_umi_{layer}", "sum"), disease=("disease", "first"), sex=("sex", "first"), pool=("pool", "first"))
    g = g[(g.n_cells >= thr[0]) & (g.umi >= thr[1])]
    M = np.stack([np.asarray(CNT[layer][s[s.donor_id == dn].row.values]).sum(0) for dn in g.index]).astype(float)
    g["hfpef"] = (g.disease == "hfpef").astype(float); g["female"] = (g.sex == "female").astype(float); g["ctrl"] = g.disease == "control"
    return g, M
rows, gene_tab, scores = [], [], {}
SPECS = [("primary", "raw_count_cellbender", "CPM", None, True), ("cellranger", "raw_count_cellranger", "CPM", None, True), ("TMM", "raw_count_cellbender", "TMM", None, True),
         ("no_pool_term", "raw_count_cellbender", "CPM", None, False), ("myeloid_ge50", "raw_count_cellbender", "CPM", (50, 10000), True)]
for spec, layer, norm, thr_over, use_pool in SPECS:
    for cname, (cts, thr) in COMP.items():
        if spec == "myeloid_ge50" and cname != "Myeloid": continue
        d, M = compartment(cts, thr_over or thr, layer); lc, gk = pb.lognorm(M, genes, norm)
        Z = pb.ref_z(lc, np.zeros(len(d)), d.ctrl.values); ok = ~np.isnan(Z).any(0); Z, gk, lcm = Z[:, ok], gk[ok], lc[:, ok].mean(0)
        D = pb.design(d, ["hfpef", "female"], ["pool"] if use_pool else [])
        for m in MODSET[cname]:
            y, ng = pb.module_score(Z, gk, MODS[m], d.ctrl.values); b, se, p = pb.ols_hc3(D.values, y)
            cp = pb.competitive(Z, gk, MODS[m], lcm, D.values, j=1, n=1000, rng=rng, is_ref=d.ctrl.values)
            ak = (AGEMAP[cname], m); ba = ageG.loc[ak, "beta_per_decade"] if ak in ageG.index else np.nan; sa = ageG.loc[ak, "se"] if ak in ageG.index else np.nan
            rows.append(dict(spec=spec, compartment=cname, module=m, n_hfpef=int(d.hfpef.sum()), n_ctrl=int(d.ctrl.sum()), n_genes=ng, beta=b, se=se, p=p,
                             healthy_age_beta=ba, expected_age_contrib=ba * DAGE, expected_age_contrib_hi=(ba - np.sign(ba) * 1.96 * sa) * DAGE if np.isfinite(ba) else np.nan,
                             decade_equiv=b / ba if np.isfinite(ba) and abs(ba) > 1e-6 else np.nan, **cp))
            if spec == "primary": scores[(cname, m)] = pd.Series(y, index=d.index)
        if spec == "primary":
            if cname == "Myeloid":
                for pool in d.pool.unique():
                    k = (d.pool != pool).values; Dk = pb.design(d[k], ["hfpef", "female"], ["pool"])
                    yk, _ = pb.module_score(Z[k], gk, MODS["E_apoptotic_cell_clearance"], d.ctrl.values[k]); b, se, p = pb.ols_hc3(Dk.values, yk)
                    rows.append(dict(spec=f"leave_out_{pool}", compartment=cname, module="E_apoptotic_cell_clearance", n_hfpef=int(d.hfpef[k].sum()), n_ctrl=int(d.ctrl[k].sum()), beta=b, se=se, p=p))
            B = np.linalg.lstsq(D.values, Z, rcond=None)[0]; res = Z - D.values @ B; XtXi = np.linalg.pinv(D.values.T @ D.values)
            se_g = np.sqrt((res ** 2).sum(0) / (len(d) - D.shape[1]) * XtXi[1, 1]); t = B[1] / se_g; pg = 2 * stats.t.sf(np.abs(t), len(d) - D.shape[1])
            gene_tab.append(pd.DataFrame({"compartment": cname, "gene": gk, "beta_hfpef_ctrlSD": B[1], "t": t, "p": pg, "mean_logcpm": lcm}))
    print(spec, "done", flush=True)
R_ = pd.DataFrame(rows); R_.to_csv(f"{OUT}/hfpef_module_effects.csv", index=False)
G = pd.concat(gene_tab); G.to_csv(f"{OUT}/hfpef_gene_effects.csv.gz", index=False)
# mismatch
j = pd.concat([scores[("VascStromal", "T_senescence_SenMayo")].rename("T"), scores[("Myeloid", "E_apoptotic_cell_clearance")].rename("E")], axis=1, join="inner")
dm, _ = compartment(*COMP["Myeloid"], "raw_count_cellbender"); j = j.join(dm[["hfpef", "female", "pool", "ctrl"]])
j["MM"] = j["T"] - j["E"]; j["MM"] = (j.MM - j.MM[j.ctrl].mean()) / j.MM[j.ctrl].std()
b, se, p = pb.ols_hc3(pb.design(j, ["hfpef", "female"], ["pool"]).values, j.MM.values)
r, pr = stats.spearmanr(j["T"], j["E"]); j.to_csv(f"{OUT}/TE_mismatch_per_donor.csv")
extra = [dict(test="mismatch_HFpEF_effect", beta=b, se=se, p=p, n=len(j)), dict(test="T_E_spearman_all", beta=r, p=pr, n=len(j))]
# composition: macrophage fraction of all nuclei
tot = meta.groupby("donor_id").n_cells.sum(); macn = meta[meta.cell_type.isin(COMP["Myeloid"][0])].groupby("donor_id").n_cells.sum().reindex(tot.index, fill_value=0)
cd = meta.groupby("donor_id").agg(disease=("disease", "first"), sex=("sex", "first"), pool=("pool", "first")); cd["frac"] = (macn / tot).values
cd["hfpef"] = (cd.disease == "hfpef").astype(float); cd["female"] = (cd.sex == "female").astype(float); cd["lg"] = np.log((cd.frac + 1e-3) / (1 - cd.frac + 1e-3))
b, se, p = pb.ols_hc3(pb.design(cd, ["hfpef", "female"], ["pool"]).values, cd.lg.values)
extra.append(dict(test="macrophage_fraction_logit", beta=b, se=se, p=p, n=len(cd), mean_hfpef=cd.frac[cd.hfpef == 1].mean(), mean_ctrl=cd.frac[cd.hfpef == 0].mean()))
cd.to_csv(f"{OUT}/macrophage_fraction_per_donor.csv")
# gene-level concordance with healthy ageing
if gaG is not None:
    for cname, agec in [("Myeloid", "Myeloid"), ("VascStromal", "VascStromal")]:
        a = gaG[gaG.compartment == agec].set_index("gene").beta_per_decade_SD; h = G[G.compartment == cname].set_index("gene").beta_hfpef_ctrlSD
        jj = pd.concat([a.rename("age"), h.rename("hf")], axis=1, join="inner").dropna()
        for m in [None] + MODSET[cname]:
            sub = jj if m is None else jj[jj.index.isin(MODS[m])]
            if len(sub) < 8: continue
            r, pr = stats.spearmanr(sub.age, sub.hf)
            extra.append(dict(test=f"gene_concordance_{cname}_{m or 'all_genes'}", beta=r, p=pr, n=len(sub), same_sign_frac=float((np.sign(sub.age) == np.sign(sub.hf)).mean())))
pd.DataFrame(extra).to_csv(f"{OUT}/hfpef_extra_tests.csv", index=False)
pd.set_option("display.width", 250)
print(R_[R_.spec == "primary"][["compartment", "module", "n_hfpef", "n_ctrl", "beta", "p", "expected_age_contrib", "decade_equiv", "z_comp", "p_comp"]].round(3).to_string())
print(R_[R_.module.eq("E_apoptotic_cell_clearance")][["spec", "compartment", "n_hfpef", "n_ctrl", "beta", "p", "z_comp"]].round(3).to_string())
print(pd.DataFrame(extra).round(4).to_string())
