#!/usr/bin/env python3
"""Synthesis v1.1 re-analyses (2026-10-03). Frozen modules v1.1 (sha256 checked). Unit = donor/sample. HC3 (pbtools_v11; HC2 on singleton leverage).
A1  H2 de-duplication in GSE290367: one record per individual (gse290367_duplicate_individuals.csv; 147 ND records -> 139 people).
    ND ageing slopes (study FE + HC3; HKSJ within-study meta; TOST +/-0.1 SD/decade) for pooled L2 myeloid, Resident, Monocyte_derived;
    RES_EFF_core, MHCII_core, EFF_MHCII_index (+ secondary modules). v1.0 primary E (GO apoptotic-cell clearance, L1 myeloid) and T (SenMayo,
    vascular-stromal) slopes/coupling/mismatch with random-pair nulls (CPM, DESeq2), all records vs dedup. DCM/HCM/ICM vs ND re-run dedup.
A2  Decade-equivalent contrast: |disease effect| / |ageing slope|, joint donor bootstrap (strata = study x group, B=2000), conservative minimum
    decades (disease CI bound nearest 0 / largest |slope 95% CI bound|) and decades at the TOST bound (|effect|/0.1). GSE290367 DCM/HCM; MAGNet DCM/HCM vs NF slope.
A3  GC-adjusted within-subset disease effects (GC_response = FKBP5 TSC22D3 ZBTB16 PER1 KLF9 DDIT4 KLF15 MT2A; post hoc, literature list) + GC-low controls.
Figure exports: bulk per-sample GC/module scores (Hahn, MAGNet), gene-level effects (discovery + bulk), SCP3342 query-only UMAP (same procedure as
scp_substates.py) with per-nucleus RES_EFF/MHCII scores, GC separability.
Does not modify any v1.0/v1.1 file. Writes only to 04_results/synthesis_v1.1/."""
import os, sys, json, hashlib, io, gzip, tarfile, time, numpy as np, pandas as pd
from scipy import stats
ROOT = os.environ["PROJ_ROOT"]  # [v12-wrap] was hard-coded "/home/weichangsheng/projects/cardiac_ageing_target_clearance"; os.chdir(ROOT)
sys.path.insert(0, f"{ROOT}/03_code/04_models"); import pbtools_v11 as pb
OUT = "04_results/synthesis_v1.1"; os.makedirs(OUT, exist_ok=True)
MODF = "01_config/modules/modules_v1.1.tsv"
assert hashlib.sha256(open(MODF, "rb").read()).hexdigest() == "3a2abdad2b609002752b4d4833d8219114fd305b2339c7ddf406da86448591be"
mods = pd.read_csv(MODF, sep="\t"); MODS = {k: sorted(set(v)) for k, v in mods.groupby("module")["gene"]}
GC = ["FKBP5", "TSC22D3", "ZBTB16", "PER1", "KLF9", "DDIT4", "KLF15", "MT2A"]; MODS["GC_response"] = GC
MLIST = ["RES_EFF_core", "MHCII_core", "RES_EFF_lit", "ISG_IFN", "MAC_PAN_ID", "GC_response"]
HEAT = sorted(set(MODS["RES_EFF_lit"]) | set(MODS["MHCII_core"]) | set(GC) | set(MODS["MAC_PAN_ID"]))
rng = np.random.default_rng(20261003); LOG = {}; T0 = time.time()
def tick(msg): print(f"[{time.time() - T0:7.1f}s] {msg}", flush=True)
dup = pd.read_csv("04_results/validation_v1.1/donor_overlap/gse290367_duplicate_individuals.csv"); DROP = set(dup.record_drop)
tq = lambda d_, a: stats.t.ppf(1 - a / 2, d_)

def fitD(df, ycol, term, covs, cats=("study",)):
    d = df.dropna(subset=[ycol, term] + list(covs)); D = pb.design(d, [term] + list(covs), cats)
    b, se, p, kind = pb.ols_hc3(D.values, d[ycol].values, j=1, return_kind=True); dfree = len(d) - D.shape[1]
    return dict(beta=b, se=se, ci_lo=b - tq(dfree, .05) * se, ci_hi=b + tq(dfree, .05) * se, p=p, df_resid=dfree, se_kind=kind, n=len(d)), d
def tost(b, se, dfree, bound=0.1):
    pl = stats.t.sf((b + bound) / se, dfree); pu = stats.t.cdf((b - bound) / se, dfree)
    return dict(ci90_lo=b - tq(dfree, .10) * se, ci90_hi=b + tq(dfree, .10) * se, p_tost=max(pl, pu), equivalent=bool(max(pl, pu) < .05))
def hksj(df, ycol, min_n=8):
    rows = []
    for st, d in df.dropna(subset=[ycol]).groupby("study"):
        if len(d) < min_n or d.age.std() < 5: continue
        cov = ["female"] if d.female.std() > 0 else []
        D = pb.design(d, ["age10"] + cov); b, se, p = pb.ols_hc3(D.values, d[ycol].values, 1); rows.append((st, len(d), b, se))
    if len(rows) < 2: return None, rows
    yb = np.array([r[2] for r in rows]); v = np.array([r[3] for r in rows]) ** 2; w = 1 / v; k = len(yb)
    mu_f = (w * yb).sum() / w.sum(); Q = (w * (yb - mu_f) ** 2).sum(); C = w.sum() - (w ** 2).sum() / w.sum(); tau2 = max(0, (Q - (k - 1)) / C)
    ws = 1 / (v + tau2); mu = (ws * yb).sum() / ws.sum(); q = (ws * (yb - mu) ** 2).sum() / (k - 1); se = np.sqrt(q / ws.sum())
    out = dict(beta=mu, se=se, ci_lo=mu - tq(k - 1, .05) * se, ci_hi=mu + tq(k - 1, .05) * se, p=2 * stats.t.sf(abs(mu / se), k - 1),
               df_resid=k - 1, n=int(sum(r[1] for r in rows)), k_studies=k, tau2=tau2, I2=max(0, (Q - (k - 1)) / Q) if Q > 0 else 0.0)
    out.update(tost(mu, se, k - 1)); return out, rows
def auc(x_case, x_ctrl):
    u = stats.mannwhitneyu(x_case, x_ctrl, alternative="two-sided"); return u.statistic / (len(x_case) * len(x_ctrl)), u.pvalue
def sep(x_case, x_ctrl):
    a, p = auc(np.asarray(x_case), np.asarray(x_ctrl))
    return dict(n_case=len(x_case), n_ctrl=len(x_ctrl), auc_case_gt_ctrl=a, mw_p=p, n_case_ge_min_ctrl=int((np.asarray(x_case) >= np.min(x_ctrl)).sum()),
                n_ctrl_le_max_case=int((np.asarray(x_ctrl) <= np.max(x_case)).sum()), max_case=float(np.max(x_case)), min_ctrl=float(np.min(x_ctrl)))
RES = []; GENE = []; SEP = []

# =====================================================================================================================
# A1/A3: GSE290367 L2 myeloid subsets, all records vs dedup
# =====================================================================================================================
PB = "02_data/processed/GSE290367_pseudobulk"
genes = pd.read_csv(f"{PB}/genes.csv").gene.astype(str).values
meta = pd.read_csv(f"{PB}/pseudobulk_L2_meta.csv"); meta["age"] = pd.to_numeric(meta.age, errors="coerce"); meta["row"] = np.arange(len(meta))
CNT = np.load(f"{PB}/pseudobulk_L2_counts.npy", mmap_mode="r"); assert CNT.shape == (len(meta), len(genes))
DIS = ["DCM", "HCM", "ICM"]
A = meta[(meta.region == "LV") & (meta.age_status == "postnatal") & (meta.age >= 20) & meta.disease.isin(["ND"] + DIS)].copy()
A["age10"] = A.age / 10; A["female"] = (A.sex == "female").astype(float); A["isND"] = A.disease == "ND"
DON = A.drop_duplicates("donor_id").set_index("donor_id")[["age", "age10", "female", "sex", "study", "disease", "isND"]]
LOG["dedup_dropped_records_present"] = sorted(DROP & set(DON.index))
LOG["adult_ND_records_all"] = int(DON.isND.sum()); LOG["adult_ND_records_dedup"] = int(DON[~DON.index.isin(DROP)].isND.sum())
LOG["adult_DCM_records_all"] = int((DON.disease == "DCM").sum()); LOG["adult_DCM_records_dedup"] = int((DON[~DON.index.isin(DROP)].disease == "DCM").sum())
MY = sorted(c for c in A.cell_type.unique() if c.startswith("Myeloid:"))
SUBSETS = {"Myeloid_pooled": MY, "Resident": ["Myeloid:Resident"], "Monocyte_derived": ["Myeloid:Monocyte_derived"]}
def subset_scores(Av, labels):
    s = Av[Av.cell_type.isin(labels)]
    g = s.groupby("donor_id").agg(n_cells=("n_cells", "sum"), umi=("total_umi", "sum"), rows=("row", list)); g = g[(g.n_cells >= 20) & (g.umi >= 5000)]
    M = np.stack([np.asarray(CNT[r]).astype(float).sum(0) for r in g.rows]); df = DON.loc[g.index].copy(); df["n_cells"] = g.n_cells.values
    nref = df[df.isND].groupby("study").size(); keep = df.study.isin(nref[nref >= 3].index).values; df, M = df[keep], M[keep]
    lc, gk = pb.lognorm(M, genes, "CPM"); Z = pb.ref_z(lc, df.study.values, df.isND.values)
    for m in MLIST: df[m] = pb.module_score(Z, gk, MODS[m], df.isND.values)[0]
    df["EFF_MHCII_index"] = df.RES_EFF_core - df.MHCII_core
    return df, Z, gk
YM = ["RES_EFF_core", "MHCII_core", "EFF_MHCII_index", "RES_EFF_lit", "ISG_IFN", "MAC_PAN_ID", "GC_response"]
SCORES = {}
for version in ["all_records", "dedup_individuals"]:
    Av = A if version == "all_records" else A[~A.donor_id.isin(DROP)]
    for sname, labs in SUBSETS.items():
        df, Z, gk = subset_scores(Av, labs); SCORES[(version, sname)] = df
        if version == "dedup_individuals": df.assign(subset=sname).reset_index().to_csv(f"{OUT}/A1_GSE290367_L2_donor_scores_{sname}_dedup.csv", index=False)
        base = dict(dataset="GSE290367", version=version, subset=sname)
        nd = df[df.isND]
        for m in YM:
            r, dd = fitD(nd, m, "age10", ["female"]); r.update(tost(r["beta"], r["se"], r["df_resid"]))
            RES.append(dict(base, track="A1_H2_ageing", module=m, contrast="per_decade_ND", model="study_FE_HC3", n_ref=r["n"], n_studies=dd.study.nunique(), **r))
            h, rows = hksj(nd, m)
            if h: RES.append(dict(base, track="A1_H2_ageing", module=m, contrast="per_decade_ND", model="HKSJ_within_study_meta", n_ref=h["n"], n_studies=h["k_studies"],
                                  studies=";".join(f"{x[0]}(n={x[1]})" for x in rows), **{k: v for k, v in h.items() if k not in ("n",)}))
        for dz in DIS:
            cnt = df.groupby("study").apply(lambda d: pd.Series({"nd": int(d.isND.sum()), "dz": int((d.disease == dz).sum())}))
            sts = cnt[(cnt.nd >= 3) & (cnt.dz >= 3)].index
            d = df[df.study.isin(sts) & df.disease.isin(["ND", dz])].assign(isD=lambda x: (x.disease == dz).astype(float))
            if d.isD.sum() < 3: continue
            trk = "A1_disease_dedup" if version == "dedup_individuals" else "A1_disease_allrecords"
            for m in YM:
                for mdl, covs in [("primary", ["age10", "female"]), ("adj_MAC_PAN_ID", ["age10", "female", "MAC_PAN_ID"]),
                                  ("adj_GC", ["age10", "female", "GC_response"]), ("adj_GC_MAC", ["age10", "female", "GC_response", "MAC_PAN_ID"])]:
                    if m in ("MAC_PAN_ID", "GC_response") and mdl != "primary": continue
                    r, dd = fitD(d, m, "isD", covs)
                    RES.append(dict(base, track=trk if mdl in ("primary", "adj_MAC_PAN_ID") else "A3_GC_adjusted", module=m, contrast=f"{dz}_vs_ND", model=mdl,
                                    n_disease=int(dd.isD.sum()), n_ref=int((dd.isD == 0).sum()), n_studies=dd.study.nunique(), studies=";".join(sorted(dd.study.unique())), **r))
                # GC-low controls: (a) ND GC <= ND median in this analysis set; (b) ND GC <= case median (MAGNet-style)
                for tag, thr in [("GClow_ctrl_le_ctrl_median", np.median(d.GC_response[d.isD == 0])), ("GClow_ctrl_le_case_median", np.median(d.GC_response[d.isD == 1]))]:
                    if m in ("GC_response", "MAC_PAN_ID"): pass
                    k = (d.isD == 1) | (d.GC_response <= thr)
                    dk = d[k]
                    if (dk.isD == 0).sum() < 3: continue
                    try:
                        r, dd = fitD(dk, m, "isD", ["age10", "female"])
                        RES.append(dict(base, track="A3_GC_adjusted", module=m, contrast=f"{dz}_vs_ND", model=tag, n_disease=int(dd.isD.sum()), n_ref=int((dd.isD == 0).sum()),
                                        n_studies=dd.study.nunique(), studies=";".join(sorted(dd.study.unique())), **r))
                    except Exception as e: LOG[f"fail_{version}_{sname}_{dz}_{m}_{tag}"] = str(e)
            for grp, msk in [("ND", d.isD == 0), (dz, d.isD == 1)]:
                for m in ["RES_EFF_core", "MHCII_core", "EFF_MHCII_index"]:
                    if msk.sum() >= 8:
                        rho, p = stats.spearmanr(d.GC_response[msk], d[m][msk])
                        RES.append(dict(base, track="A3_GC_correlation", module=m, contrast=f"{dz}_set_within_{grp}", model="spearman_vs_GC_response", n=int(msk.sum()), rho=rho, p=p))
            if sname == "Myeloid_pooled":
                SEP.append(dict(dataset="GSE290367 pooled myeloid", version=version, contrast=f"{dz}_vs_ND", score="GC_response",
                                **sep(d.GC_response[d.isD == 1].values, d.GC_response[d.isD == 0].values)))
                if version == "dedup_individuals":
                    gi = {g: i for i, g in enumerate(gk)}; Zd = pd.DataFrame(Z, index=df.index)
                    for g in HEAT + ["FOLR2", "TIMD4", "SIGLEC1"]:
                        if g not in gi: continue
                        dg = d.assign(_g=Zd.loc[d.index, gi[g]].values)
                        r, dd = fitD(dg, "_g", "isD", ["age10", "female"])
                        GENE.append(dict(dataset="GSE290367 pooled L2 myeloid (dedup)", contrast=f"{dz}_vs_ND", gene=g, role="discovery" if dz in ("DCM", "HCM") else "discovery-dataset (not selection contrast)",
                                         n_disease=int(dd.isD.sum()), n_ref=int((dd.isD == 0).sum()), **r))
    tick(f"L2 subsets done {version}")

# =====================================================================================================================
# A1 (Fig2): v1.0 primary T (SenMayo, vascular-stromal) and E (GO apoptotic-cell clearance, L1 myeloid), all vs dedup
# =====================================================================================================================
M10 = {k: sorted(set(v)) for k, v in pd.read_csv("01_config/modules/modules_v1.0.tsv", sep="\t").groupby("module")["gene"]}
CM_AMB = ["TTN","MYH7","MYH6","MYL2","MYL3","ACTC1","TNNT2","RYR2","MB","NPPA","NPPB","TNNI3","ACTA1","DES","CKM","COX6A2","MYL7","MYL4",
          "FHL2","PLN","SLC8A1","LDB3","RBM20","CMYA5","ATP2A2","FHOD3","MYOM1","OBSCN","XIRP2","NEBL","CORIN","MYBPC3","TNNC1","CSRP3"]
L1 = pd.read_csv(f"{PB}/pseudobulk_L1_meta.csv"); L1["age"] = pd.to_numeric(L1.age, errors="coerce"); L1["row"] = np.arange(len(L1))
X1 = np.load(f"{PB}/pseudobulk_L1_counts.npy", mmap_mode="r")
def zs(x): x = np.asarray(x, float); return (x - x.mean()) / x.std(ddof=1)
def comp(cts, drop):
    s = L1[(L1.region == "LV") & (L1.age_status == "postnatal") & (L1.disease == "ND") & (L1.age >= 20) & L1.cell_type.isin(cts) & ~L1.donor_id.isin(drop)]
    s = s[(s.n_cells >= 50) & (s.total_umi >= 10000)]; rows = s.groupby("donor_id").row.apply(list)
    M = np.stack([np.asarray(X1[r]).astype(np.float64).sum(0) for r in rows.values])
    d = s.groupby("donor_id").agg(age=("age", "first"), sex=("sex", "first"), study=("study", "first"), n_cells=("n_cells", "sum")).loc[rows.index]
    lib = M.sum(1); top = np.sort(M, 1)[:, -50:].sum(1)
    d["q_umi_nuc"] = np.log(lib / d.n_cells.values); d["q_top50"] = top / lib; d["q_cm"] = M[:, np.isin(genes, CM_AMB)].sum(1) / lib; d["q_ngenes"] = (M > 0).sum(1)
    return d, M
def prep(M, d, how="CPM"):
    cpm = M / M.sum(1, keepdims=True) * 1e6; keep = (cpm > 1).mean(0) >= 0.2
    if how == "DESeq2":
        Y = M[:, keep]; pos = (Y > 0).all(0); lg = np.log(Y[:, pos]); sf = np.exp(np.median(lg - lg.mean(0), 1)); lc = np.log2(Y / sf[:, None] / np.median(M.sum(1)) * 1e6 + 1)
    else: lc = np.log2(cpm[:, keep] + 1)
    lc = pd.DataFrame(lc, index=d.index, columns=genes[keep]); lcc = lc - lc.groupby(d.study.values).transform("mean")
    Z = ((lcc - lcc.mean()) / lcc.std().replace(0, np.nan)).dropna(axis=1); return Z, lc[Z.columns].mean()
def score(Z, gl): g = [x for x in gl if x in Z.columns]; return pd.Series(zs(Z[g].mean(1)), index=Z.index), g
def nullsets(Z, expr, g, n, rg):
    b = pd.qcut(expr.rank(method="first"), 20, labels=False).values; pool = {k: np.flatnonzero(b == k) for k in range(20)}
    gi = [Z.columns.get_loc(x) for x in g]; pick = np.column_stack([rg.choice(pool[b[i]], n) for i in gi]); Zv = Z.values
    return np.stack([Zv[:, pick[r]].mean(1) for r in range(n)], 1)
def design10(j, extra=()):
    return pd.concat([pd.Series(1.0, index=j.index, name="c"), (j.age / 10).rename("age10"), (j.sex == "female").astype(float).rename("f"),
                      pd.get_dummies(j.study, drop_first=True, dtype=float)] + [j[e] for e in extra], axis=1)
def hc(D, y, j):
    D = np.asarray(D, float); y = np.asarray(y, float); b, se, p = pb.ols_hc3(D, y, j); dfree = len(y) - D.shape[1]
    return dict(beta=b, se=se, ci_lo=b - tq(dfree, .05) * se, ci_hi=b + tq(dfree, .05) * se, p=p, df_resid=dfree, n=len(y))
L2m = meta[(meta.region == "LV") & meta.cell_type.str.startswith("Myeloid:")].pivot_table(index="donor_id", columns="cell_type", values="n_cells", aggfunc="sum", fill_value=0)
FR2 = L2m.div(L2m.sum(1), axis=0)
NULLS = []
for version, drop in [("all_records", set()), ("dedup_individuals", DROP)]:
    rg = np.random.default_rng(20261003)
    dV, MV = comp(["Endothelial", "Fibroblast", "Pericyte", "vSMC"], drop); dM, MM_ = comp(["Myeloid"], drop)
    for how in ["CPM", "DESeq2"]:
        ZV, eV = prep(MV, dV, how); ZM, eM = prep(MM_, dM, how)
        T, gT = score(ZV, M10["T_senescence_SenMayo"]); E, gE = score(ZM, M10["E_apoptotic_cell_clearance"])
        ids = T.index.intersection(E.index); j = dM.loc[ids].copy()
        for k in ["q_umi_nuc", "q_top50", "q_cm", "q_ngenes"]: j[k + "_V"] = zs(dV.loc[ids, k]); j[k + "_M"] = zs(dM.loc[ids, k])
        t, e = zs(T[ids]), zs(E[ids]); D0 = design10(j); Dc = pd.concat([D0, pd.Series(t, index=D0.index, name="T")], axis=1)
        base = dict(dataset="GSE290367", version=version, subset="v1.0 primary (T: vascular-stromal SenMayo; E: L1 myeloid GO apoptotic-cell clearance)", normalisation=how)
        rc = hc(Dc, e, Dc.shape[1] - 1); rm = hc(D0, zs(t) - zs(e), 1); rE = hc(D0, e, 1); rT = hc(D0, t, 1)
        NT = nullsets(ZV.loc[ids], eV, gT, 1000, rg); NE = nullsets(ZM.loc[ids], eM, gE, 1000, rg)
        Dv = D0.values.astype(float); P = np.linalg.pinv(Dv); resid = lambda Y: Y - Dv @ (P @ Y)
        sT, sE = np.apply_along_axis(zs, 0, NT), np.apply_along_axis(zs, 0, NE); rrT, rrE = resid(sT), resid(sE)
        null_pair = (rrT * rrE).sum(0) / (rrT ** 2).sum(0); null_mm = (P @ (sT - sE))[1]
        NULLS.append(pd.DataFrame({"version": version, "normalisation": how, "null_coupling_beta": null_pair, "null_mismatch_slope": null_mm}))
        RES.append(dict(base, track="A1_v10_TE", module="coupling_E_on_T", contrast="donor_level", model="E~T+age+sex+study HC3",
                        null_mean=float(null_pair.mean()), null_sd=float(null_pair.std()), p_null_upper=float((np.sum(null_pair >= rc["beta"]) + 1) / 1001), **rc))
        RES.append(dict(base, track="A1_v10_TE", module="mismatch_zT_minus_zE", contrast="per_decade_ND", model="study_FE_HC3", null_mean=float(null_mm.mean()), null_sd=float(null_mm.std()),
                        z_comp=float((rm["beta"] - null_mm.mean()) / null_mm.std()),
                        p_comp=float((np.sum(np.abs(null_mm - null_mm.mean()) >= abs(rm["beta"] - null_mm.mean())) + 1) / 1001), **rm))
        RES.append(dict(base, track="A1_v10_TE", module="E_apoptotic_cell_clearance", contrast="per_decade_ND", model="study_FE_HC3", **rE, **tost(rE["beta"], rE["se"], rE["df_resid"])))
        RES.append(dict(base, track="A1_v10_TE", module="T_senescence_SenMayo", contrast="per_decade_ND", model="study_FE_HC3", **rT, **tost(rT["beta"], rT["se"], rT["df_resid"])))
        if how == "CPM":
            jj = j.assign(T=t, E=e).join(FR2[["Myeloid:Resident", "Myeloid:Monocyte_derived"]].rename(columns={"Myeloid:Resident": "res", "Myeloid:Monocyte_derived": "mono"}))
            qM = ["q_umi_nuc_M", "q_top50_M", "q_cm_M", "q_ngenes_M"]
            for lab, ex in [("unadjusted", []), ("adj_composition", ["res", "mono"]), ("adj_QC", qM), ("adj_composition_QC", ["res", "mono"] + qM)]:
                RES.append(dict(base, track="A1_v10_TE", module="E_apoptotic_cell_clearance", contrast="per_decade_ND", model=f"attenuation:{lab}", **hc(design10(jj, ex), jj.E, 1)))
            # within-study HKSJ for E and T
            for nm, y in [("E_apoptotic_cell_clearance", e), ("T_senescence_SenMayo", t)]:
                h, rows = hksj(jj.assign(_y=y, age10=jj.age / 10, female=(jj.sex == "female").astype(float)), "_y")
                if h: RES.append(dict(base, track="A1_v10_TE", module=nm, contrast="per_decade_ND", model="HKSJ_within_study_meta", n_studies=h["k_studies"],
                                      studies=";".join(f"{x[0]}(n={x[1]})" for x in rows), **{k: v for k, v in h.items()}))
            jj.to_csv(f"{OUT}/A1_v10_TE_per_donor_{version}.csv")
    tick(f"v1.0 TE done {version}")
pd.concat(NULLS).to_csv(f"{OUT}/A1_v10_TE_null_distributions.csv", index=False)

# =====================================================================================================================
# Bulk: Hahn 2021 and MAGNet per-sample GC/module scores + gene effects (same loading as bulk_gc_diagnostic.py)
# =====================================================================================================================
GT = f"{ROOT}/02_data/raw/GTEx_v11"
lvh = pd.read_csv(f"{GT}/rerelease_2026-05/gene_reads_adult_gtex_v11_heart_left_ventricle.gct.gz", sep="\t", skiprows=2, usecols=["Name", "Description"])
E2S = pd.Series(lvh.Description.values, index=lvh.Name.str.split(".").str[0].values); E2S = E2S[~E2S.index.duplicated()]
def collapse(df):
    s = df.index.str.split(".").str[0].map(E2S); df = df[s.notna()]; return df.groupby(s[s.notna()].values).sum()
def bscores(lc, gk, is_ref):
    Z = pb.ref_z(lc, np.zeros(len(lc)), is_ref); out = pd.DataFrame({m: pb.module_score(Z, gk, MODS[m], is_ref)[0] for m in MLIST})
    out["EFF_MHCII_index"] = out.RES_EFF_core - out.MHCII_core; return out, Z
def ols(y, X):
    X = np.column_stack([np.ones(len(y))] + [np.asarray(x, float) for x in X]); y = np.asarray(y, float)
    ok = ~np.isnan(X).any(1) & ~np.isnan(y); X, y = X[ok], y[ok]; b, se, p = pb.ols_hc3(X, y, 1); df_ = len(y) - X.shape[1]; tc = stats.t.ppf(.975, df_)
    return dict(beta=b, se=se, ci_lo=b - tc * se, ci_hi=b + tc * se, p=p, n=len(y), df_resid=df_)
BS = []
HD = f"{ROOT}/02_data/raw/Hahn2021_HFpEF_EMB_bulk"
st = pd.read_csv(f"{HD}/SamplesTable_ALLpatients_sex_race_age.csv"); st["sample"] = st.samplenames.astype(str)
for tissue, fn in [("RVS", "RawReads_RVS_Ensembl_geneName.xlsx"), ("LVS", "RawReads_LVS_Ensembl_geneName.xlsx")]:
    raw = pd.read_excel(f"{HD}/{fn}", index_col=0); raw.columns = raw.columns.astype(str)
    mt = st[st.tissue == tissue].set_index("sample"); cnt = collapse(raw[mt.index])
    lc, gk = pb.lognorm(cnt.T.values.astype(float), cnt.index.values, how="TMM"); is_ref = (mt.disease == "Normal").values
    sc_, Z = bscores(lc, gk, is_ref); gi = {g: i for i, g in enumerate(gk)}
    out = mt[["disease", "sex", "age"]].reset_index().join(sc_)
    for g in ["FKBP5", "TSC22D3", "ZBTB16", "PER1", "CD163", "MERTK", "LYVE1", "C1QB", "HLA-DRA", "CD74"]:
        if g in gi: out[f"z_{g}"] = Z[:, gi[g]]
    out["dataset"] = f"Hahn2021_{tissue}"; BS.append(out.rename(columns={"index": "sample"}))
    for case_lab in ["HFpEF", "HFrEF"]:
        sub = mt.disease.isin(["Normal", case_lab]).values
        if (mt.disease[sub] == case_lab).sum() == 0: continue
        case = (mt.disease[sub] == case_lab).astype(float).values; cv = [mt.age[sub].values, (mt.sex[sub] == "Male").astype(float).values]
        for g in HEAT + ["FOLR2", "TIMD4", "SIGLEC1"]:
            if g in gi: GENE.append(dict(dataset=f"Hahn2021_{tissue} bulk", contrast=f"{case_lab}_vs_Control", gene=g, role="same-biobank (not independent)",
                                         n_disease=int(case.sum()), n_ref=int((case == 0).sum()), **ols(Z[sub][:, gi[g]], [case] + cv)))
        x = sc_.GC_response.values[sub]; SEP.append(dict(dataset=f"Hahn2021_{tissue} bulk", version="all", contrast=f"{case_lab}_vs_Control", score="GC_response", **sep(x[case == 1], x[case == 0])))
tick("Hahn done")
t_ = tarfile.open(f"{ROOT}/02_data/raw/GSE141910_MAGNet/GSE141910_RAW.tar")
X = pd.concat([pd.read_csv(io.BytesIO(gzip.decompress(t_.extractfile(m).read())), index_col=0) for m in t_.getmembers()], axis=1)
ph = pd.read_csv("03_code/05_validation/bulk/MAGNet_phenoData.csv").set_index("sample_name").loc[X.columns]
lin = collapse(2 ** X); Mm = lin.T.values; cpm = Mm / Mm.sum(1, keepdims=True) * 1e6; keep = (cpm > 1).mean(0) >= .2
lc = np.log2(cpm[:, keep] + 1); gk = lin.index.values[keep]; is_nf = (ph.etiology == "NF").values
sc_, Z = bscores(lc, gk, is_nf); gi = {g: i for i, g in enumerate(gk)}
flags = pd.read_csv("04_results/validation_v1.1/donor_overlap/magnet_overlap_flags.csv")
out = ph[["etiology", "gender", "race", "age"]].reset_index().rename(columns={"sample_name": "sample", "index": "sample"}).join(sc_)
for g in ["FKBP5", "TSC22D3", "ZBTB16", "PER1", "CD163", "MERTK", "LYVE1", "C1QB", "HLA-DRA", "CD74"]:
    if g in gi: out[f"z_{g}"] = Z[:, gi[g]]
out["dataset"] = "MAGNet"; BS.append(out); MAG = out.copy()
for case_lab in ["DCM", "HCM"]:
    sub = ph.etiology.isin(["NF", case_lab]).values; case = (ph.etiology[sub] == case_lab).astype(float).values
    cv = [ph.age[sub].values, (ph.gender[sub] == "Male").astype(float).values]
    for g in HEAT + ["FOLR2", "TIMD4", "SIGLEC1"]:
        if g in gi: GENE.append(dict(dataset="MAGNet bulk", contrast=f"{case_lab}_vs_NF", gene=g, role="same-biobank, partial overlap with GSE290367",
                                     n_disease=int(case.sum()), n_ref=int((case == 0).sum()), **ols(Z[sub][:, gi[g]], [case] + cv)))
    x = sc_.GC_response.values[sub]; SEP.append(dict(dataset="MAGNet bulk", version="all", contrast=f"{case_lab}_vs_NF", score="GC_response", **sep(x[case == 1], x[case == 0])))
pd.concat(BS, ignore_index=True).to_csv(f"{OUT}/bulk_sample_scores_GC.csv", index=False)
tick("MAGNet done")

# =====================================================================================================================
# A2: decade-equivalent contrasts with joint donor bootstrap
# =====================================================================================================================
def lsq_beta(D, y, j): return np.linalg.lstsq(D, y, rcond=None)[0][j]
def a2(label, Pdf, ycol, is_case, in_dis, dis_terms, dis_cats, age_mask, age_terms, age_cats, strata, B=2000):
    Pdf = Pdf.reset_index(drop=True).copy(); Pdf["isD"] = is_case.astype(float)
    Dd = pb.design(Pdf, ["isD"] + dis_terms, dis_cats).values; Da = pb.design(Pdf, age_terms, age_cats).values; y = Pdf[ycol].values
    idx_d = np.flatnonzero(in_dis); idx_a = np.flatnonzero(age_mask)
    rd, _ = fitD(Pdf.iloc[idx_d], ycol, "isD", dis_terms, dis_cats); ra, _ = fitD(Pdf.iloc[idx_a], ycol, age_terms[0], age_terms[1:], age_cats)
    groups = pd.Series(np.arange(len(Pdf))).groupby(np.asarray(strata)).apply(list).tolist(); bd, ba = [], []
    for _ in range(B):
        s = np.concatenate([rng.choice(g, len(g), replace=True) for g in groups])
        sd_ = s[np.isin(s, idx_d)]; sa_ = s[np.isin(s, idx_a)]
        bd.append(lsq_beta(Dd[sd_], y[sd_], 1)); ba.append(lsq_beta(Da[sa_], y[sa_], 1))
    bd, ba = np.array(bd), np.array(ba); ratio = np.abs(bd) / np.abs(ba)
    near0 = 0.0 if rd["ci_lo"] < 0 < rd["ci_hi"] else min(abs(rd["ci_lo"]), abs(rd["ci_hi"]))
    maxslope = max(abs(ra["ci_lo"]), abs(ra["ci_hi"]))
    return dict(track="A2_decade_equivalent", contrast=label, module=ycol, beta_disease=rd["beta"], disease_ci_lo=rd["ci_lo"], disease_ci_hi=rd["ci_hi"], p_disease=rd["p"],
                n_disease=int(Pdf.isD.iloc[idx_d].sum()), n_ref_disease_model=int((Pdf.isD.iloc[idx_d] == 0).sum()),
                beta_age_per_decade=ra["beta"], age_ci_lo=ra["ci_lo"], age_ci_hi=ra["ci_hi"], p_age=ra["p"], n_ageing=ra["n"],
                decades_point=abs(rd["beta"]) / abs(ra["beta"]), decades_boot_p2_5=float(np.percentile(ratio, 2.5)), decades_boot_median=float(np.median(ratio)),
                decades_boot_p97_5=float(np.percentile(ratio, 97.5)), frac_boot_slope_same_sign_as_disease=float(np.mean(np.sign(ba) == np.sign(bd))),
                decades_at_slope_CI_bound=abs(rd["beta"]) / maxslope, min_decades_conservative=near0 / maxslope, decades_at_TOST_bound_0_1=abs(rd["beta"]) / 0.1, B=B)
A2 = []
for sname in SUBSETS:
    df = SCORES[("dedup_individuals", sname)]
    for dz in ["DCM", "HCM"]:
        cnt = df.groupby("study").apply(lambda d: pd.Series({"nd": int(d.isND.sum()), "dz": int((d.disease == dz).sum())})); sts = cnt[(cnt.nd >= 3) & (cnt.dz >= 3)].index
        P_ = df[df.isND | ((df.disease == dz) & df.study.isin(sts))]
        for m in ["RES_EFF_core", "MHCII_core", "EFF_MHCII_index"]:
            r = a2(f"GSE290367 {sname} {dz}_vs_ND (dedup) / ND slope", P_, m, (P_.disease == dz).values, P_.study.isin(sts).values, ["age10", "female"], ["study"],
                   P_.isND.values, ["age10", "female"], ["study"], (P_.study + "|" + P_.isND.astype(str)).values)
            A2.append(dict(dataset="GSE290367", subset=sname, **r))
    tick(f"A2 {sname}")
MAG["age10"] = MAG.age / 10; MAG["male"] = (MAG.gender == "Male").astype(float); MAG["AA"] = (MAG.race == "AA").astype(float)
for dz in ["DCM", "HCM"]:
    P_ = MAG[MAG.etiology.isin(["NF", dz])].dropna(subset=["age"])
    for m in ["RES_EFF_core", "MHCII_core", "EFF_MHCII_index"]:
        r = a2(f"MAGNet {dz}_vs_NF / MAGNet NF slope", P_, m, (P_.etiology == dz).values, np.ones(len(P_), bool), ["age10", "male"], [],
               (P_.etiology == "NF").values, ["age10", "male", "AA"], [], P_.etiology.values)
        A2.append(dict(dataset="MAGNet", subset="bulk LV", **r))
A2 = pd.DataFrame(A2); A2.to_csv(f"{OUT}/A2_decade_equivalents.csv", index=False)
tick("A2 done")

# =====================================================================================================================
# SCP3342: macrophage pseudobulk gene effects + GC separability; query-only UMAP and per-nucleus scores
# =====================================================================================================================
S = "02_data/processed/SCP3342_pseudobulk"; sg = pd.read_csv(f"{S}/genes.csv").gene.astype(str).values
sm = pd.read_csv(f"{S}/pseudobulk_meta.csv", dtype={"donor_id": str}); Cs = np.load(f"{S}/pseudobulk_raw_count_cellbender.npy", mmap_mode="r")
ss = sm[sm.cell_type.isin(["Macrophage", "Proliferating_macrophage"])].copy(); ss["row"] = ss.index
g = ss.groupby("donor_id").agg(n=("n_cells", "sum"), umi=("total_umi_raw_count_cellbender", "sum"), disease=("disease", "first"), sex=("sex", "first"), pool=("pool", "first"))
g = g[(g.n >= 20) & (g.umi >= 5000)]; Ms = np.stack([np.asarray(Cs[ss[ss.donor_id == dn].row.values]).astype(float).sum(0) for dn in g.index])
g["case"] = (g.disease == "hfpef").astype(float); g["female"] = (g.sex == "female").astype(float)
lc, gk = pb.lognorm(Ms, sg, "CPM"); ref = (g.case == 0).values; Zs = pb.ref_z(lc, np.zeros(len(g)), ref); ok = ~np.isnan(Zs).any(0); Zs, gk = Zs[:, ok], gk[ok]
for m in MLIST: g[m] = pb.module_score(Zs, gk, MODS[m], ref)[0]
g["EFF_MHCII_index"] = g.RES_EFF_core - g.MHCII_core; gi = {x: i for i, x in enumerate(gk)}
for gg in HEAT + ["FOLR2", "TIMD4", "SIGLEC1"]:
    if gg in gi:
        r, dd = fitD(g.assign(_g=Zs[:, gi[gg]]), "_g", "case", ["female"], ["pool"])
        GENE.append(dict(dataset="SCP3342 macrophage pseudobulk (CellBender)", contrast="HFpEF_vs_Control", gene=gg, role="discovery", n_disease=int(dd.case.sum()), n_ref=int((dd.case == 0).sum()), **r))
for m in ["RES_EFF_core", "MHCII_core", "EFF_MHCII_index", "GC_response"]:
    for mdl, cv in [("primary", ["female"]), ("adj_GC", ["female", "GC_response"])]:
        if m == "GC_response" and mdl != "primary": continue
        r, dd = fitD(g, m, "case", cv, ["pool"]); RES.append(dict(dataset="SCP3342", version="all", subset="macrophage pseudobulk", track="A3_GC_adjusted", module=m, contrast="HFpEF_vs_Control",
                                                              model=mdl, n_disease=int(dd.case.sum()), n_ref=int((dd.case == 0).sum()), **r))
SEP.append(dict(dataset="SCP3342 macrophage pseudobulk", version="all", contrast="HFpEF_vs_Control", score="GC_response", **sep(g.GC_response[g.case == 1].values, g.GC_response[g.case == 0].values)))
g.reset_index().to_csv(f"{OUT}/SCP3342_macrophage_donor_scores_GC.csv", index=False)
tick("SCP pseudobulk done")
try:
    import h5py, scipy.sparse as sp, scanpy as sc, harmonypy as hm
    SCP = f"{ROOT}/02_data/raw/SCP3342/HFpEF_snRNAseq_single_cell_portal_withRawCounts_09.24.2026.h5ad"
    def dec(a): return np.array([x.decode() if isinstance(x, bytes) else x for x in a])
    def obs_col(gr, k):
        o = gr[k]
        if isinstance(o, h5py.Group): cats = dec(o["categories"][:]); codes = o["codes"][:]; return np.where(codes >= 0, cats[np.clip(codes, 0, None)], None)
        return dec(o[:])
    def read_rows(grp, rows, ncol):
        ip = grp["indptr"][:]; rows = np.sort(np.asarray(rows)); D, I, P = [], [], [0]
        for r in np.split(rows, np.flatnonzero(np.diff(rows) != 1) + 1):
            a, b = ip[r[0]], ip[r[-1] + 1]; D.append(grp["data"][a:b]); I.append(grp["indices"][a:b]); P.extend((ip[r[0] + 1:r[-1] + 2] - a + P[-1]).tolist())
        return sp.csr_matrix((np.concatenate(D), np.concatenate(I), np.array(P)), shape=(len(rows), ncol)), rows
    f = h5py.File(SCP, "r"); o = f["obs"]; oi = obs_col(o, "_index"); oc = obs_col(o, "original_cell_type")
    var = dec(f["var"]["_index"][:]); sel = np.flatnonzero(np.isin(oc, ["Macrophage", "Proliferating_macrophage"]))
    Xq, sel = read_rows(f["layers/raw_count_cellbender"], sel, len(var)); f.close()
    ann = pd.read_csv("04_results/validation_v1.1/substates/SCP3342_macrophage_nuclei_annotation.csv", index_col=0, dtype={"donor_id": str})
    q = sc.AnnData(Xq.astype(np.float32)); q.obs_names = oi[sel]; q.var_names = var; q.var_names_make_unique()
    assert set(q.obs_names) == set(ann.index), "nuclei mismatch"; q.obs = ann.loc[q.obs_names].copy()
    bad = lambda x: x.startswith("MT-") or x.startswith("RPL") or x.startswith("RPS"); EXCp = set(MODS["RES_EFF_core"]) | set(MODS["MHCII_core"])
    qn = q.copy(); sc.pp.normalize_total(qn, 1e4); sc.pp.log1p(qn); Ln = qn.X.copy()
    sc.pp.highly_variable_genes(qn, n_top_genes=2000, flavor="seurat", batch_key="pool")
    qn.var.loc[[x for x in qn.var_names if x in EXCp or bad(x)], "highly_variable"] = False
    qh = qn[:, qn.var.highly_variable].copy(); sc.pp.scale(qh, max_value=10); sc.tl.pca(qh, n_comps=30, random_state=0)
    Hq = hm.run_harmony(qh.obsm["X_pca"], qh.obs[["pool"]], ["pool"], random_state=0).Z_corr; Hq = Hq.T if Hq.shape[0] != qh.n_obs else Hq
    qn.obsm["X_harmony"] = Hq; sc.pp.neighbors(qn, use_rep="X_harmony", n_neighbors=15, random_state=0); sc.tl.umap(qn, random_state=0)
    U = q.obs[["donor_id", "pool", "hfpef", "female", "state_primary", "coarse_primary", "coarse_sens_excl_lit", "cluster"]].copy()
    U["UMAP1"], U["UMAP2"] = qn.obsm["X_umap"][:, 0], qn.obsm["X_umap"][:, 1]
    L = sp.csr_matrix(Ln); HF = []
    for k in ["Resident", "MonoDerived"]:
        msk = (q.obs.coarse_primary == k).values; ctl = msk & (q.obs.hfpef == 0).values
        for m in ["RES_EFF_core", "MHCII_core"]:
            gg = [x for x in MODS[m] if x in q.var_names]; G = L[:, q.var_names.get_indexer(gg)].toarray()
            mu, sd = G[ctl].mean(0), G[ctl].std(0); sd[sd == 0] = 1; s = ((G - mu) / sd).mean(1); thr = np.quantile(s[ctl], .75)
            U.loc[msk, f"cellscore_{m}"] = s[msk]; U.loc[msk, f"high_{m}"] = (s[msk] > thr).astype(float)
            t2 = pd.DataFrame({"donor_id": q.obs.donor_id.values[msk], "hi": s[msk] > thr}).groupby("donor_id").hi.agg(["sum", "size"]).reset_index()
            t2["substate"] = k; t2["module"] = m; t2["threshold_ctrl_Q75"] = thr; HF.append(t2)
    # all-nuclei module means for colouring
    for m in ["RES_EFF_core", "MHCII_core"]:
        gg = [x for x in MODS[m] if x in q.var_names]; U[f"meanlog_{m}"] = np.asarray(L[:, q.var_names.get_indexer(gg)].mean(1)).ravel()
    U.to_csv(f"{OUT}/SCP3342_umap_nuclei.csv")
    HFd = pd.concat(HF).merge(q.obs.groupby("donor_id")[["hfpef", "pool"]].first().reset_index(), on="donor_id"); HFd["frac_high"] = HFd["sum"] / HFd["size"]
    HFd.to_csv(f"{OUT}/SCP3342_highfrac_by_donor.csv", index=False); LOG["scp_umap"] = "ok"
except Exception as ex:
    import traceback; LOG["scp_umap_error"] = traceback.format_exc()
tick("SCP UMAP done")

# =====================================================================================================================
R_ = pd.DataFrame(RES)
def bh(p):
    p = np.asarray(p, float); o = np.argsort(p); q = p[o] * len(p) / np.arange(1, len(p) + 1); q = np.minimum.accumulate(q[::-1])[::-1]; out = np.empty_like(p); out[o] = np.minimum(q, 1); return out
R_["q_BH_family"] = np.nan; R_["q_TOST_BH_family"] = np.nan
fam = (R_.track == "A1_H2_ageing") & R_.subset.isin(["Resident", "Monocyte_derived", "Myeloid_pooled"]) & R_.module.isin(["RES_EFF_core", "MHCII_core", "EFF_MHCII_index"])
for (v, mdl), idx in R_[fam].groupby(["version", "model"]).groups.items():
    R_.loc[idx, "q_BH_family"] = bh(R_.loc[idx, "p"]); R_.loc[idx, "q_TOST_BH_family"] = bh(R_.loc[idx, "p_tost"])
fam = R_.track.isin(["A1_disease_dedup", "A3_GC_adjusted"]) & R_.subset.isin(["Resident", "Monocyte_derived"]) & R_.module.isin(["RES_EFF_core", "MHCII_core"])
for mdl, idx in R_[fam].groupby("model").groups.items(): R_.loc[idx, "q_BH_family"] = bh(R_.loc[idx, "p"])
R_.to_csv(f"{OUT}/synthesis_reanalysis_results_long.csv", index=False)
A2x = A2.copy(); A2x["version"] = "dedup_individuals"
allr = pd.concat([R_, A2x], ignore_index=True); allr.to_csv(f"{OUT}/synthesis_reanalysis_results.csv", index=False)
pd.DataFrame(GENE).to_csv(f"{OUT}/gene_level_effects_heatmap.csv", index=False)
pd.DataFrame(SEP).to_csv(f"{OUT}/GC_separability.csv", index=False)
json.dump(LOG, open(f"{OUT}/synthesis_run_log.json", "w"), indent=1, default=str)
tick("ALL DONE")
