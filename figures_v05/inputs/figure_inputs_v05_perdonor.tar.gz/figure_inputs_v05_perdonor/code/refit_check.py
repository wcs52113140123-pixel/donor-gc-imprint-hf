#!/usr/bin/env python3
"""v0.5 reproduction check: refit the locked summary models ONLY from the dumped per-donor / per-sample tables
(perdonor_scores_*.csv written by v13_revision_posthoc_dump.py and v12_G2_G5_dump.py), using the frozen pbtools_v11
design/ols_hc3 functions and the same terms/covariates as the frozen scripts. No new models.
usage: python refit_check.py <v13_rerun_dir> <v12_rerun_dir> <out_csv>"""
import sys, numpy as np, pandas as pd
from scipy import stats
ROOT = "/home/weichangsheng/projects/cardiac_ageing_target_clearance"; sys.path.insert(0, f"{ROOT}/03_code/04_models"); import pbtools_v11 as pb
V13, V12, OUTF = sys.argv[1:4]
ROWS = []
def fit(src, ds, test, ct, module, adj, d, y, terms, cats, contrast="", tost=False):
    D = pb.design(d, terms, cats); b, se, p, kind = pb.ols_hc3(D.values, y, 1, return_kind=True); df = len(y) - D.shape[1]; t = stats.t.ppf(.975, df)
    r = dict(src=src, dataset=ds, test=test, cell_type=ct, module=module, adjustment=adj, contrast=contrast, n=len(y), beta=b, ci_lo=b - t * se, ci_hi=b + t * se, p=p, se=se, se_kind=kind)
    if tost: r["p_tost"] = max(stats.t.sf((b + 0.1) / se, df), stats.t.cdf((b - 0.1) / se, df))
    ROWS.append(r); return r
def rd(f, **kw):
    x = pd.read_csv(f, low_memory=False, **kw); x.columns = [c[6:] if c.startswith("score_") else c for c in x.columns]; return x
def collin(ds, ct, d, terms, cats):
    D0 = pb.design(d, terms, cats).values.astype(float); D1 = pb.design(d, terms + ["GC3"], cats).values.astype(float)
    vif = np.linalg.pinv(D1.T @ D1)[1, 1] / np.linalg.pinv(D0.T @ D0)[1, 1]; g = d.GC3.values; cs = d.case.values.astype(bool)
    u = stats.mannwhitneyu(g[~cs], g[cs]); ROWS.append(dict(src="v13_collinearity_posthoc", dataset=ds, cell_type=ct, n=len(g), n_case=int(cs.sum()),
        AUC_GC3_ctrl_gt_case=u.statistic / ((~cs).sum() * cs.sum()), VIF_case_coef=vif, SE_inflation=np.sqrt(vif)))
def block(ds, ct, d, terms, cats, rest=True):
    ref = (d.case == 0).values
    for adj, extra in [("base", []), ("+CLOCK", ["CLOCK"]), ("+CAMP", ["CAMP"]), ("+CLOCK+CAMP", ["CLOCK", "CAMP"])]:
        fit("v13_score_tests", ds, "C/K" if ct != "bulk" else "C/K_bulk", ct, "GC3", adj, d, d.GC3.values, terms + extra, cats)
    for m in ["CLOCK", "CAMP", "GCR"]: fit("v13_score_tests", ds, "C1/descriptive", ct, m, "base", d, d[m].values, terms, cats)
    if ct != "bulk":
        for m in ["GC3", "CAMP", "CLOCK"]:
            xc, xk = d[m].values[ref], d[m].values[~ref]; u = stats.mannwhitneyu(xc, xk, alternative="two-sided")
            ROWS.append(dict(src="v13_score_tests", dataset=ds, test="K2_AUC", cell_type=ct, module=m, adjustment="none", n=len(d), beta=u.statistic / (len(xc) * len(xk)), p=u.pvalue))
        for m in ["CLOCK", "CAMP"]:
            ROWS.append(dict(src="v13_score_tests", dataset=ds, test="C3_rho_in_ref", cell_type=ct, module=f"GC3_vs_{m}", adjustment="none", n=int(ref.sum()), beta=stats.spearmanr(d.GC3[ref], d[m][ref])[0]))
CTS = ["Cardiomyocyte", "Fibroblast", "Endothelial", "Pericyte", "Myeloid"]
# ---- SCP3342
S = rd(f"{V13}/perdonor_scores_SCP3342_HFpEF.csv", dtype={"unit_id": str, "pool": str})
for ct in CTS + ["VascStromal"]:
    d = S[S.cell_type == ct].reset_index(drop=True)
    if ct != "VascStromal": block("SCP3342_HFpEF", ct, d, ["case", "female"], ["pool"])
    collin("SCP3342_HFpEF", ct, d, ["case", "female"], ["pool"])
# ---- GSE290367 L1
G = rd(f"{V13}/perdonor_scores_GSE290367_DCM.csv", dtype={"unit_id": str})
for ct in CTS:
    d = G[G.cell_type == ct].reset_index(drop=True); cats = ["study"] if d.study.nunique() > 1 else []
    block("GSE290367_DCM", ct, d, ["case", "age10", "female"], cats); collin("GSE290367_DCM", ct, d, ["case", "age10", "female"], cats)
    ref = (d.case == 0).values; r = d[ref]; fit("rev_posthoc_models", "GSE290367_DCM", "R3_GC3_age_in_reference", ct, "GC3", "sex+study", r, r.GC3.values, ["age10", "female"], ["study"] if r.study.nunique() > 1 else [])
    for stu, x in d.groupby("study"):
        if x.case.sum() >= 3 and (x.case == 0).sum() >= 3:
            for m in ["GC3", "GCR"]: fit("rev_posthoc_models", "GSE290367_DCM", "R5_per_study", ct + "|" + stu, m, "age+sex", x, -x[m].values, ["case", "age10", "female"], [])
# ---- GSE290367 L2 resident
d2 = rd(f"{V13}/perdonor_scores_GSE290367_Resident_DCM.csv", dtype={"unit_id": str}); c2 = ["study"] if d2.study.nunique() > 1 else []
for adj, extra in [("base", []), ("+CLOCK", ["CLOCK"]), ("+CAMP", ["CAMP"]), ("+CLOCK+CAMP", ["CLOCK", "CAMP"])]:
    fit("v13_score_tests", "GSE290367_Resident_DCM", "C/K_G4", "Myeloid:Resident", "G4", adj, d2, d2.G4.values, ["case", "age10", "female"] + extra, c2)
# ---- MAGNet
dM = rd(f"{V13}/perdonor_scores_MAGNet_exclOverlap_DCM.csv", dtype={"unit_id": str})
for adj, extra in [("base", []), ("+CLOCK", ["CLOCK"]), ("+CAMP", ["CAMP"]), ("+CLOCK+CAMP", ["CLOCK", "CAMP"])]:
    fit("v13_score_tests", "MAGNet_exclOverlap_DCM", "C/K_G4", "bulk", "G4", adj, dM, dM.G4.values, ["case", "age", "male"] + extra, [])
block("MAGNet_exclOverlap_DCM", "bulk", dM, ["case", "age", "male"], []); collin("MAGNet_exclOverlap_DCM", "bulk", dM, ["case", "age", "male"], [])
for ds, dd_, terms, cats, ct in [("GSE290367_Resident_DCM", d2, ["case", "age10", "female"], c2, "Myeloid:Resident"), ("MAGNet_exclOverlap_DCM", dM, ["case", "age", "male"], [], "bulk")]:
    for m in ["G3", "G4", "RES", "MHC"]:
        for adj, extra in [("base", []), ("+GC3", ["GC3"]), ("+GCR", ["GCR"]), ("+GC3+MAC", ["GC3", "MAC"])]:
            fit("rev_posthoc_models", ds, "R2_macrophage_GC3adj", ct, m, adj, dd_, dd_[m].values, terms + extra, cats)
rM = dM[dM.case == 0]; fit("rev_posthoc_models", "MAGNet_exclOverlap_DCM", "R3_GC3_age_in_reference", "bulk", "GC3", "sex", rM, rM.GC3.values, ["age", "male"], [])
# ---- Hahn
dH = rd(f"{V13}/perdonor_scores_Hahn2021_RVS_HFpEF.csv", dtype={"unit_id": str}); collin("Hahn2021_RVS_HFpEF", "bulk", dH, ["case", "age", "male"], [])
rH = dH[dH.case == 0]; fit("rev_posthoc_models", "Hahn2021_RVS_HFpEF", "R3_GC3_age_in_reference", "bulk", "GC3", "sex", rH, rH.GC3.values, ["age", "male"], [])
fit("rev_posthoc_models", "Hahn2021_RVS_HFpEF", "R2_GC3_case_adj_age", "bulk", "GC3", "age+sex", dH, -dH.GC3.values, ["case", "age", "male"], [])
cl = pd.read_csv(f"{ROOT}/02_data/raw/Hahn2021_HFpEF_EMB_bulk/ClinicalCharacteristicsRNAseqSamples.csv", encoding="latin1"); cl.columns = [c.replace("\ufeff", "").replace("ï»¿", "").strip() for c in cl.columns]
clr = cl[cl["Tissue Abbr"].astype(str).str.upper() == "RVS"].copy(); clr["sample"] = clr.SequenceRunId.astype(str)
hx = dH[dH.case == 1].set_index("unit_id").join(clr.set_index("sample")[["ACEi/ARB", "Beta Blocker", "Loop Diuretic"]], how="inner")
ROWS.append(dict(src="rev_posthoc_models", dataset="Hahn2021_RVS_HFpEF", test="R4_med_match", cell_type="bulk", module="n_matched_cases", n=len(hx)))
for med in ["ACEi/ARB", "Beta Blocker", "Loop Diuretic"]:
    x = hx.dropna(subset=[med]).copy(); x["med"] = (x[med].astype(str) == "Yes").astype(float)
    if 3 <= x.med.sum() <= len(x) - 3: fit("rev_posthoc_models", "Hahn2021_RVS_HFpEF", "R4_med_within_HFpEF", "bulk", "GC3", med, x, x.GC3.values, ["med", "age", "male"], [])
# ---- v1.2 G3/G4 (resident GSE290367, MAGNet excl) from the v1.2 rerun per-donor files
g12 = pd.read_csv(f"{V12}/GSE290367_Resident_DCM_scores.csv"); c12 = ["study"] if g12.study.nunique() > 1 else []; ref = (g12.case == 0).values
for m in ["G3", "G4", "RES_EFF_core", "MHCII_core", "GC_response"]:
    fit("G2_G5_results", "GSE290367_Resident", "G3/G4/MHCII", "", m, "age+sex+study", g12, g12[m].values, ["case", "age10", "female"], c12, contrast="DCM_vs_ND")
    if m != "GC_response":
        fit("G2_G5_results", "GSE290367_Resident", "G3/G4/MHCII", "", m, "age+sex+study+GC", g12, g12[m].values, ["case", "age10", "female", "GC_response"], c12, contrast="DCM_vs_ND")
        lowref = ref & (g12.GC_response.values <= np.median(g12.GC_response.values[ref])); kk = lowref | (g12.case.values == 1)
        fit("G2_G5_results", "GSE290367_Resident", "G3/G4/MHCII", "", m, "age+sex+study", g12[kk], g12[m].values[kk], ["case", "age10", "female"], c12, contrast="DCM_vs_ND_GClow_ref")
m12 = pd.read_csv(f"{V12}/MAGNet_exclOverlap_DCM_scores.csv")
for m in ["G3", "G4", "RES_EFF_core", "MHCII_core", "GC_response"]:
    fit("G2_G5_results", "MAGNet_excl_overlap", "G3/G4/MHCII", "", m, "age+sex", m12, m12[m].values, ["case", "age", "male"], [], contrast="DCM_vs_NF")
    if m != "GC_response":
        fit("G2_G5_results", "MAGNet_excl_overlap", "G3/G4/MHCII", "", m, "age+sex+GC+MAC", m12, m12[m].values, ["case", "age", "male", "GC_response", "MAC_PAN_ID"], [], contrast="DCM_vs_NF")
        fit("G2_G5_results", "MAGNet_excl_overlap", "G3/G4/MHCII", "", m, "age+sex+GC", m12, m12[m].values, ["case", "age", "male", "GC_response"], [], contrast="DCM_vs_NF")
# ---- GTEx G2 / G5
for tissue in ["LV", "AA"]:
    d = pd.read_csv(f"{V12}/perdonor_scores_GTEx_{tissue}.csv", low_memory=False); d["hardy"] = d.DTHHRDY.fillna(-1).astype(int).astype(str); d["SMCENTER"] = d.SMCENTER.astype(str)
    dd = d[d.analysis_ok.astype(bool)].copy()
    ROWS.append(dict(src="GTEx_n", dataset=f"GTEx_{tissue}", test="n_samples", n=len(d), n_case=int(dd.vent.sum()), beta=len(dd)))
    for m in ["GC_response", "RES_EFF_core", "MHCII_core"]:
        fit("G2_G5_results", f"GTEx_{tissue}", "G2", "", m, "age+sex+RIN+isch+center+MAC", dd, dd[m].values, ["vent", "age", "male", "SMRIN", "SMTSISCH", "MAC_PAN_ID"], ["SMCENTER"], contrast="ventilator_vs_other")
    for m in ["RES_EFF_core", "MHCII_core"]:
        fit("G2_G5_results", f"GTEx_{tissue}", "G2", "", m, "age+sex+RIN+isch+center+MAC", dd.assign(gcz=(dd.GC_response - dd.GC_response.mean()) / dd.GC_response.std()), dd[m].values,
            ["gcz", "age", "male", "SMRIN", "SMTSISCH", "MAC_PAN_ID"], ["SMCENTER"], contrast="per_SD_GC_response")
    for aset, kk in [("non_ventilator_DTHHRDY1-4", dd.DTHHRDY.isin([1, 2, 3, 4]).values), ("ventilator_only", (dd.DTHHRDY == 0).values)]:
        s2 = dd[kk]; cats = ["SMCENTER", "hardy"] if aset.startswith("non") else ["SMCENTER"]
        for m in ["RES_EFF_core", "MHCII_core"]:
            fit("G2_G5_results", f"GTEx_{tissue}", "G5", "", m, "sex+RIN+isch+center+hardy+MAC", s2, s2[m].values, ["age_dec", "male", "SMRIN", "SMTSISCH", "MAC_PAN_ID"], cats, contrast=f"age_per_decade_{aset}", tost=True)
pd.DataFrame(ROWS).to_csv(OUTF, index=False); print(len(ROWS))
