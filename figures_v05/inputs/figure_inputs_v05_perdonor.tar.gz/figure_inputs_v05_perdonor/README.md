# figure_inputs_v05_perdonor — README

Per-donor / per-sample display data regenerated on 2026-10-04 by re-running the FROZEN scoring scripts with added write-out lines only
(server folder `/home/weichangsheng/projects/cardiac_ageing_target_clearance/04_results/figure_inputs_v05`; created new, nothing overwritten). Inputs symlinked in `/home/weichangsheng/projects/cardiac_ageing_target_clearance/04_results/figure_inputs_v05/inp/` to the same files the frozen runs used:
gc_gene_classification.csv, meta_all_genes.csv.gz (validation_v1.2/steroid_reference), gse290367_duplicate_individuals.csv, MAGNet_phenoData.csv, magnet_overlap_flags.csv (validation_v1.1/donor_overlap).

## Reproduction outcome
- Re-running the frozen scripts reproduced every locked table exactly (v13_score_tests 163 rows, rev_posthoc_models 73, rev_posthoc_audit_null 17, G2_G5_results 122, G3_competitive 2, v1.2 per-donor files): max |difference| = 0.
- Refitting the locked summary models ONLY from the dumped per-donor tables reproduces them to floating-point precision (max |diff| ≤ 1e-13). All 39 manuscript claims checked match at reported precision, with two text-wording flags (see reproduction_check.csv):
  1. 'circadian score differed in 4 of 5 SCP3342 cell types (P≤0.005)': myeloid P = 0.0054, so strictly 3 of 5 meet P≤0.005 (4 of 5 at P≤0.006). Same wording in Supplement S-R3.
  2. 'GC score vs age within controls, all P≥0.32': minimum P = 0.3176 (rounds to 0.32).
- No table is flagged as not usable.
- Matched-null draws saved: frozen script uses fixed seed 20261003 and the rerun reproduces the locked 97.5th percentiles exactly.

## GTEx LV n
452 LV samples on file; the frozen G2/G5 code keeps samples with non-missing SMRIN, SMTSISCH, SMCENTER and DTHHRDY (`analysis_ok`), giving 450 (253 ventilator = Hardy 0). Excluded: GTEX-1211K-5003-SM-I9BPF (SMTSISCH missing; Hardy 0) and GTEX-P78B-0426-SM-2I5F5 (DTHHRDY missing). AA: 461 of 461 kept (215 ventilator). G5 uses the 197 analysis_ok LV samples with Hardy 1–4.

## Notes for figure builders
- Scores are in reference-group SD (reference = controls/ND/NF; centred within study for GSE290367 and overall for SCP3342, as in the frozen code; SCP3342 pool enters models as a covariate).
- Locked C/K estimates use beta = case − control; the manuscript reports control − case (= −beta).
- AUC = P(control > case) (Mann–Whitney U / (n_ctrl·n_case)).
- Two pipelines exist for macrophage modules: v1.2 (text numbers for G3/G4/RES/MHC-II; files in v12_rerun/) and v1.3 (GC3-adjusted post hoc, R2 rows; scores in v13_rerun/).

| file | content | server path | bytes | sha256 |
|---|---|---|---|---|
| refit_stdout.txt | Refit log. | /home/weichangsheng/projects/cardiac_ageing_target_clearance/04_results/figure_inputs_v05/refit_stdout.txt | 4 | 05cc4a987c45bfa0… |
| reproduced_estimates.csv | All model estimates refitted only from the dumped per-donor tables (refit_check.py). | /home/weichangsheng/projects/cardiac_ageing_target_clearance/04_results/figure_inputs_v05/reproduced_estimates.csv | 45061 | a4f17a296dc3599b… |
| reproduction_check.csv | Locked vs reproduced: 10 table-level checks + 39 manuscript claims. | (local only) | 10472 | a9867584b5e17ee2… |
| v13_rerun/matched_null_draws.csv.gz | Expression-matched null: 2,000 draws x 17 contrasts of the top-100 GC-induced share (seed 20261003; reproduces locked mean/q97.5/P exactly). | /home/weichangsheng/projects/cardiac_ageing_target_clearance/04_results/figure_inputs_v05/v13_rerun/matched_null_draws.csv.gz | 102439 | 8b5740a80538737e… |
| v13_rerun/perdonor_gene_expression_GC8_clock10.csv.gz | Long table: dataset, cell_type, unit_id, gene (FKBP5 TSC22D3 ZBTB16 PER1 KLF9 DDIT4 KLF15 MT2A + NR1D2 DBP TEF PER2 BHLHE41 CIART ARNTL NPAS2 CLOCK CRY1), z_ref (reference-standardised z used by the frozen scores) and log_expr (log2 CPM+1, TMM for Hahn). NaN = gene removed by the frozen expression filter. | /home/weichangsheng/projects/cardiac_ageing_target_clearance/04_results/figure_inputs_v05/v13_rerun/perdonor_gene_expression_GC8_clock10.csv.gz | 436555 | e56359bd814155fe… |
| v13_rerun/perdonor_scores_GSE290367_DCM.csv | GSE290367 L1 per donor x cell type (DCM vs ND, de-duplicated; studies with >=1 DCM and >=3 ND): age, age10, sex, study, disease, case + same scores. | /home/weichangsheng/projects/cardiac_ageing_target_clearance/04_results/figure_inputs_v05/v13_rerun/perdonor_scores_GSE290367_DCM.csv | 168826 | 97eb59daff0677c0… |
| v13_rerun/perdonor_scores_GSE290367_Resident_DCM.csv | GSE290367 L2 resident macrophages (109 donors), v1.3 pipeline scores incl. G3/G4/RES/MHC/MAC/GC3/GCR/CLOCK/CAMP. | /home/weichangsheng/projects/cardiac_ageing_target_clearance/04_results/figure_inputs_v05/v13_rerun/perdonor_scores_GSE290367_Resident_DCM.csv | 34784 | 6bfc50b2034462fa… |
| v13_rerun/perdonor_scores_Hahn2021_RVS_HFpEF.csv | Hahn RVS (24 control / 41 HFpEF) per sample (TMM) + same scores. Medication columns are in the raw clinical file (02_data/raw/Hahn2021_HFpEF_EMB_bulk/ClinicalCharacteristicsRNAseqSamples.csv), join on SequenceRunId = unit_id. | /home/weichangsheng/projects/cardiac_ageing_target_clearance/04_results/figure_inputs_v05/v13_rerun/perdonor_scores_Hahn2021_RVS_HFpEF.csv | 19689 | b2e07aa67491eaf9… |
| v13_rerun/perdonor_scores_MAGNet_exclOverlap_DCM.csv | MAGNet overlap-excluded (102 NF / 128 DCM) per sample with phenoData covariates + same scores. | /home/weichangsheng/projects/cardiac_ageing_target_clearance/04_results/figure_inputs_v05/v13_rerun/perdonor_scores_MAGNet_exclOverlap_DCM.csv | 90801 | bc50ea4f21aad354… |
| v13_rerun/perdonor_scores_SCP3342_HFpEF.csv | SCP3342 per donor x compartment (Cardiomyocyte, Fibroblast, Endothelial, Pericyte, Myeloid, VascStromal): disease, case, sex/female, pool, n nuclei, UMI; score_GC3, GCR (8-gene), CLOCK (CLOCK_PHASE), MORN, EVE, CAMP (CAMP_IEG), G3, G4, RES (resident efferocytic), MHC (MHC-II), MAC. Ages not public. | /home/weichangsheng/projects/cardiac_ageing_target_clearance/04_results/figure_inputs_v05/v13_rerun/perdonor_scores_SCP3342_HFpEF.csv | 70369 | b4b5aac2deaad3ae… |
| v13_rerun/rerun_v13_score_rows.csv | In-memory v1.3 score-test rows from the rerun (identical to locked v13_score_tests.csv). | /home/weichangsheng/projects/cardiac_ageing_target_clearance/04_results/figure_inputs_v05/v13_rerun/rerun_v13_score_rows.csv | 20210 | d5bccd6a30e103fd… |
| v13_rerun/rev_posthoc_audit_null.csv | Rerun output (identical to locked). | /home/weichangsheng/projects/cardiac_ageing_target_clearance/04_results/figure_inputs_v05/v13_rerun/rev_posthoc_audit_null.csv | 1792 | 815cd27f667141ff… |
| v13_rerun/rev_posthoc_models.csv | Rerun output (identical to locked). | /home/weichangsheng/projects/cardiac_ageing_target_clearance/04_results/figure_inputs_v05/v13_rerun/rev_posthoc_models.csv | 10646 | 2a9e729581eb9bdb… |
| v13_rerun/stdout.txt | Run log. | /home/weichangsheng/projects/cardiac_ageing_target_clearance/04_results/figure_inputs_v05/v13_rerun/stdout.txt | 13798 | ee7467c30b7b8312… |
| code/dump_patches.diff | Unified diff vs the frozen scripts. | /home/weichangsheng/projects/cardiac_ageing_target_clearance/04_results/figure_inputs_v05/code/dump_patches.diff | 8764 | 02f4ca2d3ef5e6ed… |
| code/refit_check.py | Refit script (frozen pbtools_v11 design/ols_hc3; same terms as frozen scripts). | /home/weichangsheng/projects/cardiac_ageing_target_clearance/04_results/figure_inputs_v05/code/refit_check.py | 10441 | 1771ab39c6d67ff5… |
| code/v12_G2_G5_dump.py | Frozen v12_G2_G5.py + 1 added write-out line. | /home/weichangsheng/projects/cardiac_ageing_target_clearance/04_results/figure_inputs_v05/code/v12_G2_G5_dump.py | 14387 | 6785d57863ac3d2b… |
| code/v13_revision_posthoc_dump.py | Frozen v13_revision_posthoc.py + 22 added write-out lines (tag [v05 dump]); no line removed or changed. | /home/weichangsheng/projects/cardiac_ageing_target_clearance/04_results/figure_inputs_v05/code/v13_revision_posthoc_dump.py | 23801 | 910af2c13b5c08ea… |
| v12_rerun/G2_G5_decisions.json | Rerun output. | /home/weichangsheng/projects/cardiac_ageing_target_clearance/04_results/figure_inputs_v05/v12_rerun/G2_G5_decisions.json | 4005 | ddfaf50868523daf… |
| v12_rerun/G2_G5_results.csv | Rerun output (identical to locked). | /home/weichangsheng/projects/cardiac_ageing_target_clearance/04_results/figure_inputs_v05/v12_rerun/G2_G5_results.csv | 22595 | 02d1b08e08086e8c… |
| v12_rerun/G3_competitive.csv | Rerun output (identical). | /home/weichangsheng/projects/cardiac_ageing_target_clearance/04_results/figure_inputs_v05/v12_rerun/G3_competitive.csv | 368 | 3e8ab2daebfce486… |
| v12_rerun/GSE290367_Resident_DCM_scores.csv | v1.2 per-donor (identical to locked validation_v1.2 file). | /home/weichangsheng/projects/cardiac_ageing_target_clearance/04_results/figure_inputs_v05/v12_rerun/GSE290367_Resident_DCM_scores.csv | 19756 | d2a9885f6b55a202… |
| v12_rerun/MAGNet_exclOverlap_DCM_scores.csv | v1.2 per-sample (identical to locked). | /home/weichangsheng/projects/cardiac_ageing_target_clearance/04_results/figure_inputs_v05/v12_rerun/MAGNet_exclOverlap_DCM_scores.csv | 61709 | 46daae094d9c39ac… |
| v12_rerun/perdonor_scores_GTEx_AA.csv | GTEx AA, 461 samples, same columns (all analysis_ok). | /home/weichangsheng/projects/cardiac_ageing_target_clearance/04_results/figure_inputs_v05/v12_rerun/perdonor_scores_GTEx_AA.csv | 93903 | 8621bfe4e94558c5… |
| v12_rerun/perdonor_scores_GTEx_LV.csv | GTEx LV, 452 samples: SAMPID, SUBJID, AGE bin, age_dec, SEX/male, DTHHRDY, hardy, vent (Hardy 0), SMCENTER, SMRIN, SMTSISCH; GC_response, RES_EFF_core, MHCII_core, MAC_PAN_ID, G3, G4; analysis_ok (450 TRUE). | /home/weichangsheng/projects/cardiac_ageing_target_clearance/04_results/figure_inputs_v05/v12_rerun/perdonor_scores_GTEx_LV.csv | 92058 | 872358e72d8368bd… |
| v12_rerun/stdout.txt | Run log. | /home/weichangsheng/projects/cardiac_ageing_target_clearance/04_results/figure_inputs_v05/v12_rerun/stdout.txt | 31066 | f1df501484040fc0… |
