Files written by sub-agent 26727468 (GC tests track), stopped 2026-10-03 as a duplicate of the lead agent pre-registered execution. NOT used in any decision or manuscript number.
