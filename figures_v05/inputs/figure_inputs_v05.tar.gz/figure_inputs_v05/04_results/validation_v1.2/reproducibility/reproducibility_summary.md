# 可重复性轨道（v1.2）：一键重跑与稿件数字溯源

日期：2026-10-03。计划：`01_config/ANALYSIS_PLAN_v1.2.md`（sha256 26db5075…602b2，已核对）。本轨道不涉及 G1–G5 检验，也未改动 `01_config`、`03_code/02–06`、任何已有 `04_results` 子目录。
代码：`03_code/07_v12/reproducibility/`；重跑结果：`04_results/rerun_v12/`；交付表：`04_results/validation_v1.2/reproducibility/`。

## 1. 主流程（Makefile + run_all.sh）

**做法。** 原脚本的输入/输出路径大多由 `PROJ_ROOT`、命令行参数或当前目录决定。流程在 `04_results/rerun_v12/root/` 下建一个"影子项目根"：`01_config`、`02_data`、`03_code` 以只读符号链接指向原目录，`04_results` 是新目录。原脚本不改一行，直接在影子根下运行。只有以下情况复制脚本，且只改路径（逐行 diff 见 `wrapped/WRAP_DIFFS.patch`）：

| 类别 | 文件 | 改动 |
|---|---|---|
| 硬编码项目根 | gse_substates.py、scp_substates.py、synthesis_reanalysis.py、synthesis_scp_umap.py | 仅 `ROOT = os.environ["PROJ_ROOT"]` 一行 |
| v1.0 + v1.1 修正 | fig2_normative_coupling / hfpef_scp3342 / fig4_disease_specificity `_v11fix.py` | B1（单例区组杠杆 ≥0.999 时改用 HC2）、B6（竞争性检验在表达分箱内无放回抽样并排除模块基因）、B2（髓系 ≥20 核且 ≥5k UMI，其余 ≥50 且 ≥10k）；可选 `V12_DEDUP=1` 去重 |
| 沙盒后处理（服务器上原本没有脚本） | `wrapped/sandbox_derived/` 下 10 个 derive_*.py | 代码取自 artifact 血缘，只把输入输出路径参数化。另修正了血缘重建中的 2 处错误：niche_by_section 中 HCA 切片的 patient 列；proteomics 中 num_NAs 的映射。修正后 10 个脚本都与存档逐字节一致 |
| 出图 | `wrapped/figures/figrun.py` | 原 fig1–6.py 和 figlib.py 不改。shim 提供 `apply_figure_style`，把 4 个 `host.artifact_path(uuid)` 映射到服务器文件，并按原样建立 data/ 和 data_syn/ |

解释器的选择沿用原始运行。SCP3342 亚群注释改用 venv（harmonypy 2.0.2）运行，原因是只有这个版本能逐字节复现存档：pylib 中的 harmonypy 0.0.10 在 8 线程和 1 线程下得到不同注释（uncertain 分别为 637 和 640，存档为 586）。

**运行。** 两次 `make -j4 NT=8`（≤32 线程），29 个目标全部完成。第二次为清空后重跑，以它为准。另做了伪 bulk 重建（`make pseudobulk_check`，从 103 GB h5ad 流式读取）。

**结果（rerun_diff_table.csv，140 个文件）。**

| 判定 | 文件数 |
|---|---|
| 逐字节一致 | 92 |
| 数值一致（所有数值 \|Δ\|<1e-6，文本相同；只有 gzip 头或浮点格式不同） | 17（最大 \|Δ\| = 2.9×10⁻¹³） |
| 仅展示层不同 | 14：12 个 PDF/PNG（渲染本身不稳定，改为比较 SourceData）；SCP3342_umap_nuclei.csv 和 SourceData_Fig3 的 e 页（6,100 个 UMAP 坐标不同，最大 \|Δ\|=13.6；注释、供体比例和统计量都一致） |
| 未重新生成 | 11：沙盒中写的叙述性 md 或预览图 8 个；donor_overlap_matrix.csv、encode_file_to_donor.csv；fig2_draft.png |
| 冻结输入 | 4 个（另有 qc_structure/* 和 gene_age_effects_GSE290367.csv.gz，见 FROZEN_INPUTS.tsv） |
| 新的中间文件 | 2 个（audit_out_*.csv，从未存档） |

- SourceData_Fig1、2、4、5、6 与存档数值一致（\|Δ\| ≤ 2.5×10⁻¹³）。Fig3 只有 UMAP 页不同。
- 置换和自助法都用固定种子（20261001/02/03/04；B=2000；1,000 个随机集），重跑后逐字节一致。
- 伪 bulk 重建：GSE290367 L1（3547×16115）、L2（15261×16115）以及 SCP3342 两层计数矩阵、meta、genes，共 9 个文件，与 `02_data/processed` 逐字节一致。

**v1.0 结果按 v1.1 修正重跑（v10_vs_v11fix_endpoints.csv：全部 5,332 个"终点×指标"；v10_vs_v11fix_key_endpoints.csv：20 个已报告终点）。** 修正后，含 P 值的指标中有 34 处跨越 0.05（再去重则为 44 处）。主要变化如下（v1.0 → 修正后 → 修正后再去重）：

- **T–E 耦合 β**（GSE290367 ND）：0.350（P=5.3×10⁻⁴，n=145）→ 0.272（P=0.031，n=146）→ 0.302（P=0.041，n=138）。失配年龄斜率：+0.156（P=0.025）→ +0.182（P=0.012）→ +0.159（P=0.032）。
- **E 年龄斜率**：−0.236（P=0.0018）→ −0.243（P=0.0010）→ −0.249（P=0.0012）。研究内 HKSJ：−0.209（P=0.026）→ −0.220（P=0.056）→ −0.221（P=0.054），**不再显著**。
- **T 竞争性检验**：P=0.007 → 0.013 → 0.064。
- **常驻巨噬 E**：n 从 131 增至 146（阈值统一的结果），β 变化不大（−0.129 → −0.128 → −0.141），三版都不显著。
- **SCP3342 HFpEF 预注册失配终点**：三版完全不变（β=0.767，SE=0.416，P=0.075，n=39）。原因是 SCP3342 本来就用 20/5k 阈值，且没有单例 pool。
- **SCP3342 ≥50 核敏感性分析**（含单例 pool）：v1.0 的 SE 和 P 是 NaN；用 HC2 后 β=−0.642，SE=0.316，P=0.057。
- **竞争性检验**：效应量不变，P_comp 随无放回抽样略有变化，例如胞葬受体 0.011 → 0.015，E 0.250 → 0.245。
- **GSE290367 DCM E 模块**：β −0.876 → −0.875 → −0.949，都是 P<10⁻⁶。竞争性 P：0.025 → 0.029 → 0.050。

稿件 v0.1 中 v1.0 部分的数字取自 synthesis A1，它沿用 v1.0 阈值（50/10k）和去重；上面这些变化不直接改动稿件数字，但"耦合不特异"的结论在统一阈值后更强了。

## 2. 稿件数字溯源（number_trace_audit.csv）

从 v0.1 正文（不含参考文献）和图注中抽出 537 个数字。其中 31 个不是数值声明（列表编号、路径或日期片段），其余 506 个逐一对应到结果文件的行和列，或代码中的常量，并按报告精度重新计算比较：

| 状态 | 数量 |
|---|---|
| match | 501（正文 379，图注 122） |
| rounding-issue | 1 |
| mismatch | 3 |
| no-source | 1（"成年寿命约六个十年"是作者的约定，不是数据结果） |

506 条按类别分：效应量 150、样本量和计数 133、方法参数 78、P/q 值 77、置信限 50、百分比 9、十年当量 7、外部常数 2。数字来源文件在重跑中的状态：逐字节一致 350 条，数值一致 51 条，代码常量 52 条，冻结输入 5 条；另有 6 条（34/42、19/19、20/24，正文和图注各 3 条）只出现在沙盒写的 donor_overlap_summary.md 中，无法由代码重新生成。

## 3. 需要修改的地方

1. **N122**（结果第一节）：E 斜率经 QC 和组成联合校正后，P = 0.052 应为 **0.051**（源值 0.0515）。
2. **N129、N130**（结果第一节和图 2g）：HFpEF 失配终点的 95 % CI −0.05 至 1.58 是按 β ± 1.96·SE 算的，而同一行的 P=0.075 用的是 t(29)，二者不一致。按 t 分布应为 **−0.08 至 1.62**；或者改报 z 分布的 P（0.065）。
3. **N039**（数据集）："eight pools of six" 应改为 "eight pools of five or six donors (43 donors)"。
4. **N030**（数据集）："ten adult studies" 这个数对，但后面只列了 9 个，缺 Sim et al. 2021。
5. **组成和分解**（N007、N008、N167–N178，含摘要中的 "76–89%"）：数字本身与源表一致，但源分析用的是全部记录。GSE290367_myeloid_fractions_by_donor.csv 和 decomposition_donor_scores.csv 里都有那 10 条重复记录，而文中写的是"每人一条记录"。要么改写为 all records，要么去重后重跑分解；在此之前这些数字只能算暂定。
6. **Software 和图 3e 图注**：方法只写了 harmonypy 0.0.10，实际上亚群注释用的是 2.0.2（venv），UMAP 重嵌入用的是 0.0.10。图注说"同一代码和种子重新生成"，但 UMAP 坐标不能逐位复现，只有供体层面的量可以。
7. **N015、N244**（ρ = 0.93）：这个数不在任何结果表里，只能由 SourceData_Fig4 的 f 页重新算出。应把它写入表 S8 或 synthesis 结果表。
8. **N001、N002**（摘要）：139 是去重后的 ND 人数，但耦合 β=0.41 用的是 n=137（两个组分都可用的供体）。建议写作 "139 (137 with both compartments)"。
9. **N118**："about halved by donor QC adjustment" 实际是 −0.241 → −0.140，下降 42 %。建议改为 "reduced by about 40 %"。
10. **N165**："Effects were unchanged by MAC_PAN_ID adjustment" 说得过满。常驻巨噬 DCM 中 MHCII 从 0.79 变为 1.03，RES 从 −1.15 变为 −1.03。建议改为"方向和显著性不变"。
11. **数据和代码可用性**：多项已报告的表格来自沙盒后处理，包括 substates/final/*、spatial_niche*、spatial_zone_tests、spatial_scores_by_sample、顶层 proteomics_effects.csv、A3_GSE290367_DCM_by_study_GC.csv 和合并版 synthesis_reanalysis_results.csv。所有主图也是在沙盒中渲染的。这些现在都可以由 `03_code/07_v12/reproducibility/` 重新生成，声明中应引用这个目录。供体重叠的计数（34/42 等）目前只出现在 md 中，应补一张可重新生成的表。

## 4. 偏离与局限（如实声明）

- **未重新生成的上游步骤**：重复个体表、MAGNet 重叠标记和 phenoData（沙盒产物）；qc_structure/*（由 02_inspect_structure 读取 103 GB h5ad 产生）；figdata/gene_age_effects_GSE290367.csv.gz（export_figdata）；prot_grep.txt（visium 任务中的内联脚本）。这些作为冻结输入复制进影子根，sha256 记录在 FROZEN_INPUTS.tsv。
- **不在流程范围内**：v1.0 的 GTEx/Age-OME 复制（fig3_replication_*）和 06_figures 的 v2 图，因为稿件 v0.1 没有使用；donor_overlap_matrix.csv 和 encode_file_to_donor.csv，因为生成代码没有包装。
- **B1 的实现细节**：在 fig2 的 statsmodels 公式拟合中，HC2 单例回退沿用 statsmodels robust 默认的正态参考分布；hfpef 和 fig4 直接调用 pbtools_v11（t 分布）。
- **溯源的范围**：只覆盖正文和图注的文字，图片中的面板文字没有逐一核对。比较对象是 2026-10-03 15:03 UTC 的服务器快照。"76–89%" 等组成和分解数字在去重重跑之前只能算暂定。
- 重建的伪 bulk（1.3 GB）保留在 `04_results/rerun_v12/pseudobulk/`，与 processed 完全相同，可以删除。
