# 模块冻结记录 v1.0（2026-10-01）

**冻结时间点**：GSE290367 已下载但尚未打开任何表达值；SCP3342（HFpEF）尚未下载。**在此之前没有查看过任何年龄效应或 HFpEF 组间结果。**
**文件**：`01_config/modules/modules_v1.0.tsv`（冻结后设为只读；任何修改都必须另存为 v1.1，并在此记录理由）

## 主终点（预先指定，只此一个）
- **Target（靶端）** = `T_senescence_SenMayo`（124 个基因，Saul 2022, PMID 35974106），在血管–间质区室（内皮、成纤维、周细胞、平滑肌）中按供体打分。
- **Effector（效应端）** = `E_apoptotic_cell_clearance`（GO:0043277，44 个基因），在巨噬/单核细胞中按供体打分。
- **Mismatch** = z(Target) − z(Effector)；z 值以各数据集内的健康参照组标准化。

## 次要终点
- `V_dont_eat_me_evasion`（9 个基因）、`I_immune_visibility`（15 个基因）、`E_myeloid_inhibitory_checkpoint`（4 个基因，SIRPA 只在髓系中计算）
- SSFI = mean[z(T), z(V), −z(I), −z(E)]

## 敏感性分析（替换主模块，方向应保持一致）
- 替换 Target：`T_senescence_Fridman`（PMID 18711403）
- 替换 Effector：`E_phagocytosis_engulfment`（GO:0006911）、`E_lysosome`（KEGG hsa04142）、`E_efferocytosis_receptors`（17 个基因）

## 探索性 / 调整用
- `C_cytotoxic_NK_CD8`：只在细胞数达到阈值时计算
- `ADJ_inflammation_hallmark` / `ADJ_IFNG_hallmark`：作为通用炎症协变量，用于检验失配是否只是炎症的副产物

## 相对 SAP v2.0 的变更（解盲前做出）
1. 主靶端由 SAP 的 `T+V−I` 复合分数改为**单一 SenMayo**。理由：减少研究者自由度；SenMayo 是公开、可引用的人类衰老共识集；V 和 I 基因数少（9/15），放进主终点会增加噪声。V 和 I 保留为次要终点。
2. 主效应端采用 GO 标准集 `GOBP_APOPTOTIC_CELL_CLEARANCE`，取代 SAP v0.1 的手工清单（手工清单降为敏感性分析）。
3. 删除足细胞相关模块（主线已不含肾脏）。

## 负对照（在代码中生成，不列入 tsv）
- 1,000 次按表达量和基因集大小匹配的随机基因集
- 在供体层面置换年龄或疾病标签
